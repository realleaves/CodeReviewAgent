# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`fb74e4816ccfa7fc6a7abd8c8aab1f415cfc1b13`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/69 个已索引 Python 文件
- 调用：7；耗时：13.79 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] configure() 在 asyncio 可用时对非字符串 impl 调用 issubclass 可能抛 TypeError

- 位置：`tornado/ioloop.py:191`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：configure() 在 asyncio 不为 None 时，先判断 impl 是否为字符串，若是则 import_object 解析；随后直接调用 issubclass(impl, BaseAsyncIOLoop)。若调用者传入的不是类对象（例如某个实例、函数或其它非类对象），issubclass 会抛出 TypeError 而非预期的 RuntimeError/明确错误。文档契约要求只允许 AsyncIOLoop 子类，非类输入应给出清晰错误。
- 触发条件：IOLoop.configure(impl) 且 asyncio 可用，impl 为非类对象（如 IOLoop.configure(42) 或传入实例）。
- 依据：第195-199行：isinstance 检查仅覆盖字符串分支，之后无条件 issubclass(impl, BaseAsyncIOLoop)；issubclass 对非类参数抛 TypeError。
- 修复建议：在 issubclass 前增加 isinstance(impl, type) 检查，非类时抛出明确的 RuntimeError/TypeError 提示只允许 AsyncIOLoop 子类。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
189: 
190:     @classmethod
191:     def configure(cls, impl, **kwargs):
192:         if asyncio is not None:
193:             from tornado.platform.asyncio import BaseAsyncIOLoop
194: 
195:             if isinstance(impl, (str, unicode_type)):
196:                 impl = import_object(impl)
197:             if not issubclass(impl, BaseAsyncIOLoop):
198:                 raise RuntimeError(
199:                     "only AsyncIOLoop is allowed when asyncio is available")
200:         super(IOLoop, cls).configure(impl, **kwargs)
201: 
202:     @staticmethod
```

- 复现状态：not_reproduced
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/5f6ea6a814c0/evidence.json)

复现测试：

```python
import unittest
import asyncio

from tornado.ioloop import IOLoop


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # asyncio 可用时，传入非类对象应给出明确错误，而非 issubclass 的 TypeError
        with self.assertRaises((RuntimeError, TypeError)) as ctx:
            IOLoop.configure(42)
        # 若抛出的是 TypeError，其消息应来自 issubclass 参数类型检查，
        # 说明未做 isinstance(impl, type) 防护。
        if isinstance(ctx.exception, TypeError):
            self.assertIn("issubclass", str(ctx.exception).lower())

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `not_reproduced`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 0, "skipped": 0, "load_error": null, "observations": [], "target_lines": [31, 33, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 52, 53, 54, 55, 56, 61, 62, 66, 67, 71, 72, 76, 77, 82, 85, 167, 169, 170, 171, 172, 173, 174, 175, 176, 179, 180, 181, 182, 185, 188, 190, 192, 193, 195, 197, 202, 224, 238, 254, 255, 298, 321, 336, 343, 347, 354, 365, 392, 411, 420, 429, 448, 462, 471, 479, 495, 519, 584, 599, 633, 646, 662, 671, 686, 698, 711, 723, 747, 754, 779, 783, 795, 816, 837, 843, 844, 870, 874, 886, 899, 904, 908, 917, 927, 1088, 1093, 1096, 1104, 1113, 1129, 1134, 1135, 1138, 1140, 1151, 1154, 1158, 1172, 1173, 1181, 1191, 1198, 1205, 1215], "target_calls": [["<module>", 31], ["IOLoop", 85], ["PeriodicCallback", 1158], ["PollIOLoop", 837], ["_Timeout", 1134], ["configure", 190]]}

```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/ioloop.py | completed | window_completed | 2/2 |
| tornado/platform/asyncio.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 191, "sensitive_file": 1, "benchmark_tests_hidden": 51}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
