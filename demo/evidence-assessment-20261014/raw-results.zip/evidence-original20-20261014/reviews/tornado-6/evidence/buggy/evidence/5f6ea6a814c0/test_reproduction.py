import unittest
import asyncio

from tornado.ioloop import IOLoop


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # asyncio 可用时，传入非类对象应给出明确错误，而非 issubclass 的 TypeError
        with self.assertRaises((RuntimeError, TypeError)) as ctx:
            IOLoop.configure(42)
        # 若抛出的是 TypeError，其消息应来自 issubclass 参数类型检查，
        # 说明未做 isinstance(impl, type) 防护。
        if isinstance(ctx.exception, TypeError):
            self.assertIn("issubclass", str(ctx.exception).lower())
