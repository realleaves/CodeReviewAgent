import asyncio
import unittest

from tornado.platform.asyncio import AsyncIOLoop


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        loop = asyncio.new_event_loop()
        io_loop = AsyncIOLoop(loop)
        io_loop.close()
        # 第二次 close 不应因映射项已被删除而抛 KeyError
        io_loop.close()
