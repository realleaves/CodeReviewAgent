import unittest

from youtube_dl.utils import dfxp2srt


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        dfxp_data = (
            '<?xml version="1.0" encoding="utf-8"?>'
            '<tt xmlns="http://www.w3.org/ns/ttml">'
            '<body><div>'
            '<p begin="00:00:01.000">text</p>'
            '</div></body></tt>'
        )
        try:
            dfxp2srt(dfxp_data)
        except KeyError as e:
            self.fail('dfxp2srt raised KeyError for paragraph without end/dur: %r' % (e,))
