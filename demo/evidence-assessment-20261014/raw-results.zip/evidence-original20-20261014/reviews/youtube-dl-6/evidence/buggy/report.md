# GitHub 仓库代码审查报告

- 仓库：https://github.com/ytdl-org/youtube-dl
- 分支：blinded-snapshot
- Commit：`4f29fa99069760dc47ef9ca5dbf607a567d2982f`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/588 个已索引 Python 文件
- 调用：12；耗时：30.556 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] srt_subtitles_timecode 在 Python 3 下使用浮点除法导致 %d 格式化报错

- 位置：`youtube_dl/utils.py:1991`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：该函数用 '%02d:%02d:%02d,%03d' 格式化 seconds/3600 等表达式。在 Python 3 中 '/' 是浮点除法，seconds/3600 返回 float，而 %d 需要整数，会抛出 TypeError: %d format: a number is required, not float。dfxp2srt 在解析 TTML 字幕时调用此函数（第2029-2030行），因此任何含 begin/end 时间的 TTML 字幕在 Python 3 下都会崩溃。
- 触发条件：调用 srt_subtitles_timecode(1.5) 或通过 dfxp2srt 解析任意有效 TTML 字幕（如 <p begin="00:00:01.000" end="00:00:02.000">x</p>）。
- 依据：第1991行：'%02d:%02d:%02d,%03d' % (seconds / 3600, (seconds % 3600) / 60, seconds % 60, (seconds % 1) * 1000)。Python 3 中 seconds/3600 为 float，%d 不接受 float。
- 修复建议：改用整数除法 // 或先 int() 转换，例如 int(seconds // 3600) 等，确保传给 %d 的是整数。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
1989: 
1990: def srt_subtitles_timecode(seconds):
1991:     return '%02d:%02d:%02d,%03d' % (seconds / 3600, (seconds % 3600) / 60, seconds % 60, (seconds % 1) * 1000)
1992: 
1993: 
```

- 复现状态：not_reproduced
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/9ca55c806e9e/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.utils import srt_subtitles_timecode


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        self.assertEqual(srt_subtitles_timecode(1.5), '00:00:01,500')

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `not_reproduced`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 0, "skipped": 0, "load_error": null, "observations": [], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 36, 56, 59, 60, 61, 62, 63, 67, 70, 71, 74, 89, 143, 144, 169, 181, 206, 221, 234, 239, 262, 279, 311, 320, 358, 378, 383, 392, 416, 425, 437, 457, 468, 477, 481, 491, 500, 525, 536, 537, 539, 559, 565, 566, 572, 573, 574, 577, 583, 585, 591, 596, 597, 600, 605, 607, 611, 612, 613, 616, 621, 622, 625, 631, 633, 639, 666, 676, 692, 694, 698, 703, 710, 718, 754, 795, 796, 799, 800, 805, 816, 817, 820, 836, 837, 840, 871, 937, 962, 966, 995, 1005, 1006, 1008, 1021, 1026, 1032, 1036, 1046, 1121, 1143, 1152, 1159, 1214, 1216, 1219, 1223, 1224, 1229, 1238, 1244, 1247, 1250, 1254, 1259, 1270, 1278, 1287, 1301, 1355, 1364, 1374, 1382, 1397, 1403, 1409, 1418, 1423, 1424, 1428, 1442, 1446, 1454, 1463, 1509, 1517, 1524, 1534, 1535, 1549, 1560, 1561, 1566, 1567, 1571, 1609, 1610, 1615, 1638, 1646, 1654, 1661, 1671, 1672, 1685, 1686, 1689, 1705, 1709, 1716, 1717, 1718, 1719, 1720, 1724, 1731, 1736, 1761, 1771, 1774, 1784, 1788, 1797, 1804, 1809, 1819, 1837, 1841, 1851, 1871, 1893, 1901, 1960, 1967, 1977, 1990, 1991, 1994, 2036, 2041, 2049, 2054, 2062, 2065, 2066, 2067, 2068, 2069, 2070, 2071, 2072, 2073, 2074, 2075, 2076, 2077, 2078, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2101, 2102, 2103, 2104, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2112, 2113, 2114, 2115, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2124, 2125, 2126, 2127, 2128, 2129, 2130, 2131, 2132, 2133, 2134, 2135, 2136, 2137, 2138, 2139, 2140, 2141, 2142, 2143, 2144, 2145, 2146, 2147, 2148, 2149, 2150, 2151, 2152, 2153, 2154, 2155, 2156, 2157, 2158, 2159, 2160, 2161, 2162, 2163, 2164, 2165, 2166, 2167, 2168, 2169, 2170, 2171, 2172, 2173, 2174, 2175, 2176, 2177, 2178, 2179, 2180, 2181, 2182, 2183, 2184, 2185, 2186, 2187, 2188, 2189, 2190, 2191, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2236, 2237, 2238, 2239, 2240, 2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2251, 2256, 2264, 2267, 2268, 2269, 2270, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2283, 2284, 2285, 2286, 2287, 2288, 2289, 2290, 2291, 2292, 2293, 2294, 2295, 2296, 2297, 2298, 2299, 2300, 2301, 2302, 2303, 2304, 2305, 2306, 2307, 2308, 2309, 2310, 2311, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337, 2338, 2339, 2340, 2341, 2342, 2343, 2344, 2345, 2346, 2347, 2348, 2349, 2350, 2351, 2352, 2353, 2354, 2355, 2356, 2357, 2358, 2359, 2360, 2361, 2362, 2363, 2364, 2365, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2384, 2385, 2386, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2394, 2395, 2396, 2397, 2398, 2399, 2400, 2401, 2402, 2403, 2404, 2405, 2406, 2407, 2408, 2409, 2410, 2411, 2412, 2413, 2414, 2415, 2416, 2417, 2418, 2419, 2420, 2421, 2422, 2423, 2424, 2425, 2426, 2427, 2428, 2429, 2430, 2431, 2432, 2433, 2434, 2435, 2436, 2437, 2438, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450, 2451, 2452, 2453, 2454, 2455, 2456, 2457, 2458, 2459, 2460, 2461, 2462, 2463, 2464, 2465, 2466, 2467, 2468, 2469, 2470, 2471, 2472, 2473, 2474, 2475, 2476, 2477, 2478, 2479, 2480, 2481, 2482, 2483, 2484, 2485, 2486, 2487, 2488, 2489, 2490, 2491, 2492, 2493, 2494, 2495, 2496, 2497, 2498, 2499, 2500, 2501, 2502, 2503, 2504, 2505, 2506, 2507, 2508, 2509, 2510, 2511, 2512, 2513, 2514, 2515, 2518, 2524, 2525, 2533], "target_calls": [["<module>", 4], ["ContentTooShortError", 625], ["DateRange", 1005], ["DownloadError", 577], ["ExtractorError", 536], ["HEADRequest", 1423], ["ISO3166Utils", 2264], ["ISO639Utils", 2062], ["InAdvancePagedList", 1609], ["MaxDownloadsReached", 611], ["OnDemandPagedList", 1566], ["PagedList", 1560], ["PerRequestProxyHandler", 2524], ["PostProcessingError", 600], ["RegexNotFoundError", 572], ["SameFileError", 591], ["UnavailableVideoError", 616], ["UnsupportedError", 565], ["YoutubeDLCookieProcessor", 816], ["YoutubeDLHTTPSHandler", 799], ["YoutubeDLHandler", 676], ["locked_file", 1223], ["srt_subtitles_timecode", 1990]]}

```

### [中] dfxp2srt 对缺少 end 且缺少 dur 的段落抛出 KeyError

- 位置：`youtube_dl/utils.py:2024`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第2024行用 para.attrib.get('end') 取结束时间，若为 None 或 0 则第2026行用 para.attrib['dur'] 直接索引。当段落既无 end 也无 dur 属性时，会抛出 KeyError: 'dur'，而非给出可理解的错误。TTML 规范允许段落通过 begin+end 或 begin+dur 指定时间，但缺少两者时属于无效输入，当前实现以未捕获的 KeyError 崩溃。
- 触发条件：解析含 <p begin="00:00:01.000">text</p>（无 end、无 dur）的 TTML 字幕。
- 依据：第2024行 end_time = parse_dfxp_time_expr(para.attrib.get('end'))；第2025-2026行 if not end_time: end_time = begin_time + parse_dfxp_time_expr(para.attrib['dur'])。
- 修复建议：使用 para.attrib.get('dur') 并在缺失时抛出明确的 ValueError，说明段落缺少时间信息。
- 验证方式：1 validation error for ReproductionPlan
contract.expected_behavior
  Extra inputs are not permitted [type=extra_forbidden, input_value="对既无 end 也无 dur...捕获的 KeyError。", input_type=str]
    For further information visit https://errors.pydantic.dev/2.14/v/extra_forbidden

```python
2022:     for para, index in zip(paras, itertools.count(1)):
2023:         begin_time = parse_dfxp_time_expr(para.attrib['begin'])
2024:         end_time = parse_dfxp_time_expr(para.attrib.get('end'))
2025:         if not end_time:
2026:             end_time = begin_time + parse_dfxp_time_expr(para.attrib['dur'])
2027:         out.append('%d\n%s --> %s\n%s\n\n' % (
2028:             index,
```

- 复现状态：invalid_plan
- 证据说明：1 validation error for ReproductionPlan
contract.expected_behavior
  Extra inputs are not permitted [type=extra_forbidden, input_value="对既无 end 也无 dur...捕获的 KeyError。", input_type=str]
    For further information visit https://errors.pydantic.dev/2.14/v/extra_forbidden

[运行证据](evidence/b16c1ed38deb/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.utils import dfxp2srt


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        dfxp_data = (
            '<?xml version="1.0" encoding="utf-8"?>'
            '<tt xmlns="http://www.w3.org/ns/ttml">'
            '<body><div>'
            '<p begin="00:00:01.000">text</p>'
            '</div></body></tt>'
        )
        try:
            dfxp2srt(dfxp_data)
        except KeyError as e:
            self.fail('dfxp2srt raised KeyError for paragraph without end/dur: %r' % (e,))

```

### [低] dfxp2srt 对缺少 begin 属性的段落抛出 KeyError

- 位置：`youtube_dl/utils.py:2023`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第2023行用 para.attrib['begin'] 直接索引。若段落没有 begin 属性（例如仅有 end 或 dur），会抛出 KeyError: 'begin'，而不是给出明确错误信息。
- 触发条件：解析含 <p end="00:00:02.000">text</p>（无 begin）的 TTML 字幕。
- 依据：第2023行 begin_time = parse_dfxp_time_expr(para.attrib['begin'])。
- 修复建议：使用 para.attrib.get('begin') 并在缺失时抛出明确的 ValueError。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
2021: 
2022:     for para, index in zip(paras, itertools.count(1)):
2023:         begin_time = parse_dfxp_time_expr(para.attrib['begin'])
2024:         end_time = parse_dfxp_time_expr(para.attrib.get('end'))
2025:         if not end_time:
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 dfxp2srt 对缺少 begin 属性的段落抛出 KeyError。但仓库中没有任何文档、测试或契约规定缺少 begin 属性时的预期行为（例如应返回0、应抛 ValueError、还是应跳过该段落）。TTML 规范中 begin 属性本身是可选的，但本仓库并未声明其解析策略。仅凭 Python 的 dict 索引规则只能证明会抛 KeyError，无法证明这是 bug——抛出 KeyError 本身也是对该非法/不完整输入的一种合理失败方式。缺少可定位的契约来断言“正确行为”，因此无法构造有依据的复现测试。

[运行证据](evidence/32a91644c156/evidence.json)

### [低] B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling

- 位置：`youtube_dl/utils.py:1935`
- 来源：ruff B904
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1933:                     comparison_value = parse_filesize(m.group('intval') + 'B')
1934:                 if comparison_value is None:
1935:                     raise ValueError(
1936:                         'Invalid integer value %r in filter part %r' % (
1937:                             m.group('intval'), filter_part))
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/utils.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 44, "sensitive_file": 1, "benchmark_tests_hidden": 23}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
