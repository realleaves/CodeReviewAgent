import unittest

from youtube_dl.utils import srt_subtitles_timecode


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        self.assertEqual(srt_subtitles_timecode(1.5), '00:00:01,500')
