import unittest

from youtube_dl.utils import srt_subtitles_timecode


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        self.assertEqual(srt_subtitles_timecode(59.9999), '00:01:00,000')
