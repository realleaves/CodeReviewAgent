import unittest
from youtube_dl.utils import _match_one


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        result = _match_one('duration>10 ?', {'duration': None})
        self.assertIsInstance(result, bool)
        self.assertTrue(result)
