# GitHub 仓库代码审查报告

- 仓库：https://github.com/ytdl-org/youtube-dl
- 分支：blinded-snapshot
- Commit：`b02b960c6bba834d9e7199ac53430c7933079dc8`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/691 个已索引 Python 文件
- 调用：7；耗时：19.595 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] unified_strdate 循环未在匹配后 break，可能被后续格式覆盖

- 位置：`youtube_dl/utils.py:1082`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：循环遍历所有 date_formats，每次成功解析都会覆盖 upload_date，且不 break。若某个日期字符串能被多个格式解析（例如同时匹配 day-first 与 month-first 的格式，或 DATE_FORMATS 中多个格式对同一字符串都成立），最终结果取决于列表中最后一个匹配的格式，而非第一个（通常更精确）的匹配。这会导致返回与预期不同的日期。
- 触发条件：传入一个可被多个格式解析的日期字符串，例如 '01-02-2003'（在 day_first=True 下既可能匹配 '%d-%m-%Y' 也可能匹配其他格式），或任何同时满足多个 DATE_FORMATS 条目的输入。
- 依据：1082-1086 行：for expression in date_formats(day_first): try: upload_date = datetime.datetime.strptime(...).strftime('%Y%m%d') except ValueError: pass —— 无 break，成功解析后继续循环并覆盖 upload_date。
- 修复建议：在成功解析后立即 break，保留第一个匹配的格式结果，避免被后续格式覆盖。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
1080:     _, date_str = extract_timezone(date_str)
1081: 
1082:     for expression in date_formats(day_first):
1083:         try:
1084:             upload_date = datetime.datetime.strptime(date_str, expression).strftime('%Y%m%d')
1085:         except ValueError:
1086:             pass
1087:     if upload_date is None:
1088:         timetuple = email.utils.parsedate_tz(date_str)
```

- 复现状态：not_reproduced
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/27b2f7f11e32/evidence.json)

复现测试：

```python
import unittest
from youtube_dl.utils import unified_strdate


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # '01.02.03' 可被 '%d.%m.%y' 解析为 2003-02-01，
        # 也可被 '%d.%m.%Y' 解析为 0003-02-01（%Y 接受 2 位年份）。
        # 循环未 break，最后一个匹配格式会覆盖先前结果。
        result = unified_strdate('01.02.03')
        self.assertEqual(result, '20030201')

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `not_reproduced`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 0, "skipped": 0, "load_error": null, "observations": [], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 36, 60, 66, 76, 79, 80, 81, 82, 83, 87, 90, 91, 94, 109, 110, 111, 114, 137, 138, 139, 140, 141, 142, 143, 144, 147, 148, 149, 150, 151, 152, 153, 157, 163, 164, 165, 169, 172, 226, 227, 245, 257, 280, 295, 308, 313, 319, 344, 345, 346, 350, 354, 376, 393, 425, 434, 474, 494, 498, 502, 511, 542, 551, 563, 587, 598, 607, 611, 621, 630, 655, 666, 667, 669, 689, 695, 696, 702, 703, 704, 707, 713, 715, 721, 726, 727, 730, 735, 737, 741, 742, 743, 746, 751, 752, 755, 761, 763, 769, 796, 806, 822, 824, 828, 840, 847, 855, 886, 933, 934, 937, 980, 981, 986, 1005, 1006, 1009, 1025, 1026, 1029, 1030, 1031, 1032, 1033, 1034, 1044, 1047, 1066, 1067, 1070, 1073, 1075, 1077, 1079, 1080, 1082, 1083, 1084, 1085, 1086, 1087, 1094, 1095, 1098, 1121, 1134, 1138, 1167, 1177, 1178, 1180, 1193, 1198, 1204, 1208, 1218, 1293, 1315, 1324, 1331, 1387, 1388, 1390, 1393, 1405, 1406, 1411, 1420, 1426, 1429, 1432, 1436, 1441, 1452, 1462, 1471, 1485, 1496, 1542, 1563, 1572, 1582, 1590, 1611, 1615, 1619, 1628, 1633, 1634, 1638, 1639, 1643, 1657, 1661, 1669, 1678, 1682, 1730, 1738, 1745, 1755, 1756, 1770, 1781, 1782, 1787, 1788, 1795, 1839, 1840, 1845, 1868, 1876, 1884, 1891, 1903, 1919, 1923, 1933, 1953, 1963, 1973, 1978, 1979, 1980, 1981, 1982, 1986, 1993, 1998, 2037, 2047, 2050, 2060, 2064, 2073, 2080, 2085, 2094, 2131, 2167, 2181, 2185, 2195, 2215, 2237, 2245, 2304, 2311, 2321, 2334, 2338, 2393, 2398, 2406, 2411, 2419, 2422, 2423, 2424, 2425, 2426, 2427, 2428, 2429, 2430, 2431, 2432, 2433, 2434, 2435, 2436, 2437, 2438, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450, 2451, 2452, 2453, 2454, 2455, 2456, 2457, 2458, 2459, 2460, 2461, 2462, 2463, 2464, 2465, 2466, 2467, 2468, 2469, 2470, 2471, 2472, 2473, 2474, 2475, 2476, 2477, 2478, 2479, 2480, 2481, 2482, 2483, 2484, 2485, 2486, 2487, 2488, 2489, 2490, 2491, 2492, 2493, 2494, 2495, 2496, 2497, 2498, 2499, 2500, 2501, 2502, 2503, 2504, 2505, 2506, 2507, 2508, 2509, 2510, 2511, 2512, 2513, 2514, 2515, 2516, 2517, 2518, 2519, 2520, 2521, 2522, 2523, 2524, 2525, 2526, 2527, 2528, 2529, 2530, 2531, 2532, 2533, 2534, 2535, 2536, 2537, 2538, 2539, 2540, 2541, 2542, 2543, 2544, 2545, 2546, 2547, 2548, 2549, 2550, 2551, 2552, 2553, 2554, 2555, 2556, 2557, 2558, 2559, 2560, 2561, 2562, 2563, 2564, 2565, 2566, 2567, 2568, 2569, 2570, 2571, 2572, 2573, 2574, 2575, 2576, 2577, 2578, 2579, 2580, 2581, 2582, 2583, 2584, 2585, 2586, 2587, 2588, 2589, 2590, 2591, 2592, 2593, 2594, 2595, 2596, 2597, 2598, 2599, 2600, 2601, 2602, 2603, 2604, 2605, 2608, 2613, 2621, 2624, 2625, 2626, 2627, 2628, 2629, 2630, 2631, 2632, 2633, 2634, 2635, 2636, 2637, 2638, 2639, 2640, 2641, 2642, 2643, 2644, 2645, 2646, 2647, 2648, 2649, 2650, 2651, 2652, 2653, 2654, 2655, 2656, 2657, 2658, 2659, 2660, 2661, 2662, 2663, 2664, 2665, 2666, 2667, 2668, 2669, 2670, 2671, 2672, 2673, 2674, 2675, 2676, 2677, 2678, 2679, 2680, 2681, 2682, 2683, 2684, 2685, 2686, 2687, 2688, 2689, 2690, 2691, 2692, 2693, 2694, 2695, 2696, 2697, 2698, 2699, 2700, 2701, 2702, 2703, 2704, 2705, 2706, 2707, 2708, 2709, 2710, 2711, 2712, 2713, 2714, 2715, 2716, 2717, 2718, 2719, 2720, 2721, 2722, 2723, 2724, 2725, 2726, 2727, 2728, 2729, 2730, 2731, 2732, 2733, 2734, 2735, 2736, 2737, 2738, 2739, 2740, 2741, 2742, 2743, 2744, 2745, 2746, 2747, 2748, 2749, 2750, 2751, 2752, 2753, 2754, 2755, 2756, 2757, 2758, 2759, 2760, 2761, 2762, 2763, 2764, 2765, 2766, 2767, 2768, 2769, 2770, 2771, 2772, 2773, 2774, 2775, 2776, 2777, 2778, 2779, 2780, 2781, 2782, 2783, 2784, 2785, 2786, 2787, 2788, 2789, 2790, 2791, 2792, 2793, 2794, 2795, 2796, 2797, 2798, 2799, 2800, 2801, 2802, 2803, 2804, 2805, 2806, 2807, 2808, 2809, 2810, 2811, 2812, 2813, 2814, 2815, 2816, 2817, 2818, 2819, 2820, 2821, 2822, 2823, 2824, 2825, 2826, 2827, 2828, 2829, 2830, 2831, 2832, 2833, 2834, 2835, 2836, 2837, 2838, 2839, 2840, 2841, 2842, 2843, 2844, 2845, 2846, 2847, 2848, 2849, 2850, 2851, 2852, 2853, 2854, 2855, 2856, 2857, 2858, 2859, 2860, 2861, 2862, 2863, 2864, 2865, 2866, 2867, 2868, 2869, 2870, 2871, 2872, 2875, 2881, 2882, 2890, 2906, 2923, 2941, 2961, 2970], "target_calls": [["<module>", 4], ["ContentTooShortError", 755], ["DateRange", 1177], ["DownloadError", 707], ["ExtractorError", 666], ["HEADRequest", 1633], ["HTMLAttributeParser", 344], ["ISO3166Utils", 2621], ["ISO639Utils", 2419], ["InAdvancePagedList", 1839], ["MaxDownloadsReached", 741], ["OnDemandPagedList", 1787], ["PUTRequest", 1638], ["PagedList", 1781], ["PerRequestProxyHandler", 2881], ["PostProcessingError", 730], ["RegexNotFoundError", 702], ["SameFileError", 721], ["UnavailableVideoError", 746], ["UnsupportedError", 695], ["YoutubeDLCookieProcessor", 1005], ["YoutubeDLHTTPSHandler", 980], ["YoutubeDLHandler", 806], ["date_formats", 1066], ["extract_timezone", 1029], ["locked_file", 1405], ["preferredencoding", 157], ["unified_strdate", 1070]]}

```

### [低] unified_timestamp 在循环内 return，但异常路径下可能返回 None 而非回退

- 位置：`youtube_dl/utils.py:1110`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：unified_timestamp 在第一个成功解析的格式处 return，行为与 unified_strdate 不同（后者不 break）。这本身是合理的，但需注意：若所有格式都失败且 email.utils.parsedate_tz 返回 None，函数隐式返回 None，与 date_str 为 None 时返回 None 一致，属预期。此处未发现明确缺陷，仅记录两函数行为不一致可能引发调用方混淆。
- 触发条件：无具体可构造的错误输入；仅为行为一致性观察。
- 依据：1110-1118 行：循环内成功即 return；失败则尝试 parsedate_tz，若为 None 则函数末尾无 return，隐式返回 None。
- 修复建议：如无实际缺陷可忽略；若需一致性可显式 return None。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1108:     date_str = re.sub(r'(?i)\s*(?:AM|PM)(?:\s+[A-Z]+)?', '', date_str)
1109: 
1110:     for expression in date_formats(day_first):
1111:         try:
1112:             dt = datetime.datetime.strptime(date_str, expression) - timezone + pm_delta
1113:             return calendar.timegm(dt.timetuple())
1114:         except ValueError:
1115:             pass
1116:     timetuple = email.utils.parsedate_tz(date_str)
1117:     if timetuple:
```

- 复现状态：unsupported
- 证据说明：候选缺陷本身承认未发现明确缺陷，仅为行为一致性观察。unified_timestamp 在所有格式解析失败且 email.utils.parsedate_tz 返回 None 时隐式返回 None，这与 date_str 为 None 时返回 None 一致，属于合理设计。没有可定位的契约（文档/测试/语言规则）规定该函数在解析失败时必须返回特定值而非 None，因此无法构造有来源的预期行为断言。

[运行证据](evidence/9b981bcc1b1c/evidence.json)

### [低] subtitles_filename 对无扩展名文件名处理不当

- 位置：`youtube_dl/utils.py:1134`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：subtitles_filename 使用 filename.rsplit('.', 1)[0] 去掉扩展名。若 filename 不含 '.'，rsplit 返回整个字符串作为 [0]，结果仍为 filename + '.' + sub_lang + '.' + sub_format，行为可接受。但若 filename 以 '.' 开头（如 '.hidden'），rsplit('.',1)[0] 返回空字符串，导致生成 '.sub_lang.sub_format'，丢失原文件名。
- 触发条件：subtitles_filename('.hidden', 'en', 'srt')
- 依据：1135 行：return filename.rsplit('.', 1)[0] + '.' + sub_lang + '.' + sub_format；对 '.hidden'，rsplit('.',1) 得 ['', 'hidden']，[0] 为空串。
- 修复建议：使用 os.path.splitext 或判断 rsplit 结果，避免以点开头的文件名被截断为空。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1132: 
1133: 
1134: def subtitles_filename(filename, sub_lang, sub_format):
1135:     return filename.rsplit('.', 1)[0] + '.' + sub_lang + '.' + sub_format
1136: 
1137: 
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 subtitles_filename('.hidden', 'en', 'srt') 会丢失原文件名。但该函数没有文档、测试或语言规则约定以点开头的隐藏文件名必须保留原文件名。函数契约仅从实现推断，无法定位到任何权威契约（文档/测试/语言规则）来证明期望行为。此外，该函数在仓库中的实际调用者传入的是已确定扩展名的视频文件名（如 'video.mp4'），'.hidden' 这类输入并非有效业务输入。缺少可定位的契约，无法构造有依据的复现测试。

[运行证据](evidence/6224d710111e/evidence.json)

### [低] date_from_str 对非法输入抛出未捕获异常

- 位置：`youtube_dl/utils.py:1147`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：date_from_str 在既非 'now'/'today'/'yesterday' 也不匹配相对日期正则时，直接调用 datetime.datetime.strptime(date_str, '%Y%m%d').date()。若 date_str 不是合法的 YYYYMMDD（如 'abc' 或 '2013-01-01'），会抛出 ValueError 而非返回 None 或友好错误。文档字符串声称支持 YYYYMMDD 或相对格式，但未说明非法输入行为。
- 触发条件：date_from_str('2013-01-01') 或 date_from_str('invalid')
- 依据：1164 行：return datetime.datetime.strptime(date_str, '%Y%m%d').date()，无 try/except 包裹。
- 修复建议：根据契约决定是否捕获 ValueError 并返回 None，或在文档中明确非法输入会抛异常。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1145:     if date_str == 'yesterday':
1146:         return today - datetime.timedelta(days=1)
1147:     match = re.match('(now|today)(?P<sign>[+-])(?P<time>\d+)(?P<unit>day|week|month|year)(s)?', date_str)
1148:     if match is not None:
1149:         sign = match.group('sign')
1150:         time = int(match.group('time'))
1151:         if sign == '-':
1152:             time = -time
1153:         unit = match.group('unit')
1154:         # A bad approximation?
1155:         if unit == 'month':
1156:             unit = 'day'
1157:             time *= 30
1158:         elif unit == 'year':
1159:             unit = 'day'
1160:             time *= 365
1161:         unit += 's'
1162:         delta = datetime.timedelta(**{unit: time})
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/utils.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 49, "sensitive_file": 1, "benchmark_tests_hidden": 27}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
