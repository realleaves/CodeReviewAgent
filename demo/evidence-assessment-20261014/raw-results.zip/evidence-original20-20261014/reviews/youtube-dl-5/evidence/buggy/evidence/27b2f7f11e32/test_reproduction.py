import unittest
from youtube_dl.utils import unified_strdate


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # '01.02.03' 可被 '%d.%m.%y' 解析为 2003-02-01，
        # 也可被 '%d.%m.%Y' 解析为 0003-02-01（%Y 接受 2 位年份）。
        # 循环未 break，最后一个匹配格式会覆盖先前结果。
        result = unified_strdate('01.02.03')
        self.assertEqual(result, '20030201')
