import unittest
import calendar
import datetime
from youtube_dl.utils import unified_timestamp


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # 2014-01-02 15:04:05 UTC 的正确时间戳
        expected = calendar.timegm(datetime.datetime(2014, 1, 2, 15, 4, 5).timetuple())
        result = unified_timestamp('01/02/2014 03:04:05 PM')
        self.assertEqual(result, expected)
