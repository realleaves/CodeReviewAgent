# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`bc40b3a5ba44006c23daf7fe0ed872af5e33bdc5`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/726 个已索引 Python 文件
- 调用：7；耗时：20.537 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（1）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

### [低] isdigit 对 Unicode 数字返回 True 但 int() 可能失败或语义不符

- 位置：`youtube_dl/jsinterp.py:109`
- 来源：llm
- 复核：已复现 — 测试确实调用了目标代码 interpret_expression('²', {}, 100)，输入有效（公开入口接受任意表达式字符串），Python 语言规则明确：'²'.isdigit() 为 True 但 int('²') 抛 ValueError。运行证据显示在 jsinterp.py:110 处抛出未捕获的 ValueError，与候选描述一致。该路径可达且无前置条件假设，失败与候选相同，证据充分支持正式缺陷报告。
- 问题：expr.isdigit() 对某些 Unicode 数字字符（如上标 '²'、'٣' 阿拉伯数字）返回 True，但 int(expr) 对 '²' 会抛 ValueError，导致未捕获异常而非预期的 ExtractorError。
- 触发条件：interpret_expression('²', {}, 100)
- 依据：'²'.isdigit() 为 True，但 int('²') 抛 ValueError: invalid literal for int()。
- 修复建议：改用 expr.isascii() and expr.isdigit() 或正则 ^\d+$ 判断。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
107:                 return val
108: 
109:         if expr.isdigit():
110:             return int(expr)
111: 
112:         var_m = re.match(
```

- 复现状态：reproduced
- 证据说明：测试确实调用了目标代码 interpret_expression('²', {}, 100)，输入有效（公开入口接受任意表达式字符串），Python 语言规则明确：'²'.isdigit() 为 True 但 int('²') 抛 ValueError。运行证据显示在 jsinterp.py:110 处抛出未捕获的 ValueError，与候选描述一致。该路径可达且无前置条件假设，失败与候选相同，证据充分支持正式缺陷报告。

[运行证据](evidence/791eec547d5f/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.jsinterp import JSInterpreter
from youtube_dl.utils import ExtractorError


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        interp = JSInterpreter('')
        # '²' 的 isdigit() 为 True，但 int('²') 抛 ValueError
        with self.assertRaises(ExtractorError):
            interp.interpret_expression('\u00b2', {}, 100)

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "ValueError", "message": "invalid literal for int() with base 10: '\u00b2'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 12, in test_reproduction\n    interp.interpret_expression('\\u00b2', {}, 100)\n  File \"/work/youtube_dl/jsinterp.py\", line 110, in interpret_expression\n    return int(expr)\nValueError: invalid literal for int() with base 10: '\u00b2'\n"}], "target_lines": [1, 3, 4, 5, 7, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 26, 29, 30, 31, 32, 33, 34, 35, 37, 58, 59, 61, 64, 84, 85, 88, 89, 90, 109, 110, 213, 232, 246, 250], "target_calls": [["<listcomp>", 23], ["<module>", 1], ["JSInterpreter", 29], ["__init__", 30], ["interpret_expression", 58]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "ValueError", "message": "invalid literal for int() with base 10: '\u00b2'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 12, in test_reproduction\n    interp.interpret_expression('\\u00b2', {}, 100)\n  File \"/work/youtube_dl/jsinterp.py\", line 110, in interpret_expression\n    return int(expr)\nValueError: invalid literal for int() with base 10: '\u00b2'\n"}], "target_lines": [1, 3, 4, 5, 7, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 26, 29, 30, 31, 32, 33, 34, 35, 37, 58, 59, 61, 64, 84, 85, 88, 89, 90, 109, 110, 213, 232, 246, 250], "target_calls": [["<listcomp>", 23], ["<module>", 1], ["JSInterpreter", 29], ["__init__", 30], ["interpret_expression", 58]]}

```

## 待验证候选与静态建议

### [中] 索引赋值断言 idx 为 int 在 -O 下失效并可能产生错误行为

- 位置：`youtube_dl/jsinterp.py:98`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：assert isinstance(idx, int) 在优化模式下被移除；若索引表达式返回非 int（如字符串），lvar[idx] 可能对 dict 生效或对 list 抛 TypeError，行为不一致。
- 触发条件：interpret_expression('a["x"] = 1', {'a': {}}, 100)
- 依据：idx 由 interpret_expression 返回，可为字符串；assert 在 -O 下不执行。
- 修复建议：显式检查类型并抛出 ExtractorError。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
96:                 idx = self.interpret_expression(
97:                     m.group('index'), local_vars, allow_recursion)
98:                 assert isinstance(idx, int)
99:                 cur = lvar[idx]
100:                 val = opfunc(cur, right_val)
101:                 lvar[idx] = val
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 assert isinstance(idx, int) 在 -O 优化模式下被移除会导致不一致行为。但该断言在正常（非 -O）Python 下会执行，且测试环境为 python:3.7.17 默认未启用 -O。要复现该问题需以 -O 运行解释器，而测试框架无法在单个 unittest 内改变当前进程的优化标志（sys.flags.optimize 只读，且 -O 影响的是字节码生成阶段）。因此无法在给定环境下构造有效复现。此外，即便在 -O 下，'a["x"] = 1' 对 dict 赋值本身是合法且语义合理的 JS 行为（对象属性赋值），并非明确契约所禁止；仓库文档与测试均未规定索引赋值必须为 int 或必须抛 ExtractorError，缺少可定位的契约依据。

[运行证据](evidence/e7c921485397/evidence.json)

### [中] splice 实现使用 pop(index) 导致结果顺序与 JS 语义不符

- 位置：`youtube_dl/jsinterp.py:166`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：JS 的 splice 返回被删除元素按原顺序排列的数组。此处循环 pop(index) 每次删除同一位置，返回的是逆序（且当 howMany 超过剩余长度时行为仍为逆序）。
- 触发条件：interpret_expression('a.splice(0,2)', {'a':[1,2,3]}, 100)
- 依据：循环 i in range(0,2): res.append(obj.pop(0)) 得到 [1,2] 顺序正确；但 index=1,howMany=2 时 pop(1) 两次得到 [2,3] 顺序正确。实际 pop(index) 每次删除后后续元素前移，返回顺序仍为原顺序，故此处并非逆序。
- 修复建议：无实质问题，撤回。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
164:                 assert len(argvals) == 1
165:                 return obj[argvals[0]:]
166:             if member == 'splice':
167:                 assert isinstance(obj, list)
168:                 index, howMany = argvals
169:                 res = []
170:                 for i in range(index, min(index + howMany, len(obj))):
171:                     res.append(obj.pop(index))
172:                 return res
173: 
174:             return obj[member](argvals)
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 splice 使用 pop(index) 导致返回顺序与 JS 语义不符（逆序）。但静态分析表明该实现是正确的：循环每次 pop(index) 删除同一位置，后续元素前移，因此依次取出的是原数组中 index, index+1, ... 位置的元素，返回顺序与原顺序一致。例如 a=[1,2,3], splice(1,2)：pop(1)=2，数组变[1,3]；pop(1)=3，返回[2,3]，与 JS 语义一致。候选自身的 evidence 字段也承认顺序正确并建议撤回。因此不存在可复现的真实缺陷，无法构造会失败的测试。

[运行证据](evidence/1bdebf495255/evidence.json)

### [低] 成员函数调用将参数作为单个元组传递

- 位置：`youtube_dl/jsinterp.py:174`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：obj[member](argvals) 把整个元组作为单一参数传入，而 JS 语义应为展开参数。对于自定义对象方法可能产生错误调用。
- 触发条件：interpret_expression('obj.foo(1,2)', {'obj': SomeObj()}, 100)
- 依据：argvals 是 tuple，obj[member](argvals) 传入一个元组参数而非两个参数。
- 修复建议：改为 obj[member](*argvals)。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
172:                 return res
173: 
174:             return obj[member](argvals)
175: 
176:         m = re.match(
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] B007: Loop control variable `i` not used within loop body

- 位置：`youtube_dl/jsinterp.py:170`
- 来源：ruff B007
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Loop control variable `i` not used within loop body
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B007: Loop control variable `i` not used within loop body
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
168:                 index, howMany = argvals
169:                 res = []
170:                 for i in range(index, min(index + howMany, len(obj))):
171:                     res.append(obj.pop(index))
172:                 return res
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:98`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
96:                 idx = self.interpret_expression(
97:                     m.group('index'), local_vars, allow_recursion)
98:                 assert isinstance(idx, int)
99:                 cur = lvar[idx]
100:                 val = opfunc(cur, right_val)
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:144`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
142:                 return obj[member]
143: 
144:             assert expr.endswith(')')
145:             # Function call
146:             if arg_str == '':
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:154`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
152: 
153:             if member == 'split':
154:                 assert argvals == ('',)
155:                 return list(obj)
156:             if member == 'join':
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:157`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
155:                 return list(obj)
156:             if member == 'join':
157:                 assert len(argvals) == 1
158:                 return argvals[0].join(obj)
159:             if member == 'reverse':
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:160`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
158:                 return argvals[0].join(obj)
159:             if member == 'reverse':
160:                 assert len(argvals) == 0
161:                 obj.reverse()
162:                 return obj
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:164`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
162:                 return obj
163:             if member == 'slice':
164:                 assert len(argvals) == 1
165:                 return obj[argvals[0]:]
166:             if member == 'splice':
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:167`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
165:                 return obj[argvals[0]:]
166:             if member == 'splice':
167:                 assert isinstance(obj, list)
168:                 index, howMany = argvals
169:                 res = []
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/jsinterp.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 49, "sensitive_file": 1, "benchmark_tests_hidden": 27}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
