# GitHub 仓库代码审查报告

- 仓库：https://github.com/ytdl-org/youtube-dl
- 分支：blinded-snapshot
- Commit：`bc40b3a5ba44006c23daf7fe0ed872af5e33bdc5`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/726 个已索引 Python 文件
- 调用：8；耗时：18.2 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] splice 循环中 pop(index) 使用固定索引导致结果错误

- 位置：`youtube_dl/jsinterp.py:170`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：splice 实现中循环体为 obj.pop(index)，索引始终为初始 index，未随迭代递增。当 howMany > 1 时，每次 pop 都删除同一位置元素，但该位置元素被删除后后续元素前移，导致删除的元素集合与 JS 语义不符。例如 obj=[0,1,2,3], index=1, howMany=2：JS 应删除 [1,2] 返回 [1,2]，而此处第一次 pop(1) 得 1，列表变为 [0,2,3]，第二次 pop(1) 得 2，列表变为 [0,3]，返回 [1,2] 恰好正确；但当 index 非 0 且 howMany 较大时仍可能正确，因为每次删除后 index 位置即为下一个待删元素。实际该实现对于连续删除是等价的，因此不构成缺陷。
- 触发条件：obj=[0,1,2,3], index=1, howMany=2
- 依据：第170-171行 for i in range(index, min(index + howMany, len(obj))): res.append(obj.pop(index))
- 修复建议：无需修改，连续 pop(index) 对 splice 语义等价。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
168:                 index, howMany = argvals
169:                 res = []
170:                 for i in range(index, min(index + howMany, len(obj))):
171:                     res.append(obj.pop(index))
172:                 return res
173: 
174:             return obj[member](argvals)
```

- 复现状态：unsupported
- 证据说明：候选缺陷本身在 explanation 中已自我否定：连续 pop(index) 对 splice 语义是等价的。分析：循环 range(index, min(index+howMany, len(obj))) 执行 howMany 次（受长度限制），每次 pop(index) 删除当前 index 位置元素，删除后后续元素前移，因此下一次 pop(index) 正好删除原序列的下一个待删元素。返回的 res 顺序也与 JS splice 返回的被删元素顺序一致。例如 obj=[0,1,2,3], index=1, howMany=2：pop(1)=1，列表变 [0,2,3]；pop(1)=2，列表变 [0,3]；返回 [1,2]，与 JS 一致。因此不存在可复现的真实缺陷，无法构造会失败的测试。

[运行证据](evidence/c85369cd2e2d/evidence.json)

### [中] 索引赋值断言 isinstance(idx, int) 在 -O 下失效且类型不匹配时崩溃

- 位置：`youtube_dl/jsinterp.py:98`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第98行 assert isinstance(idx, int) 用于校验索引表达式结果为整数。当索引表达式返回非 int（如字符串或 None）时，assert 会抛出 AssertionError 而非 ExtractorError，且该 assert 在 python -O 下被移除，导致后续 lvar[idx] 可能抛出 TypeError 或产生错误行为。不过这是内部解释器对受控 JS 代码的约束，触发需要构造特定 JS 输入。
- 触发条件：JS 代码中形如 a['x'] = 1 或 a[someString] = 1 的赋值
- 依据：第96-99行 idx = self.interpret_expression(...); assert isinstance(idx, int); cur = lvar[idx]
- 修复建议：将 assert 替换为显式类型检查并抛出 ExtractorError。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
96:                 idx = self.interpret_expression(
97:                     m.group('index'), local_vars, allow_recursion)
98:                 assert isinstance(idx, int)
99:                 cur = lvar[idx]
100:                 val = opfunc(cur, right_val)
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称第98行 assert isinstance(idx, int) 在索引表达式返回非 int 时会崩溃，且 -O 下失效。但该 assert 是解释器对受控 JS 代码的内部约束，触发需要构造特定 JS 输入（如 a['x']=1）。仓库中没有任何文档、测试或语言规则约定索引赋值遇到非 int 索引时应抛出 ExtractorError 而非 AssertionError。代码中的现有实现（assert）不能单独证明期望行为，且候选本身也承认这是内部约束。缺少可定位的契约来断言正确返回值/异常类型，因此无法构造有来源依据的复现测试。

[运行证据](evidence/c4194cfe7884/evidence.json)

### [低] split 断言 argvals == ('',) 对无参 split() 调用失败

- 位置：`youtube_dl/jsinterp.py:154`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第153-154行处理 member == 'split' 时断言 argvals 必须等于 ('',)。但 JS 中 split() 可无参数调用，此时 arg_str 为 ''，argvals 为 tuple()，断言失败抛出 AssertionError。此外 split(',') 等带分隔符调用也会触发断言失败。这是解释器对特定 JS 模式的限制，但断言失败会以 AssertionError 而非 ExtractorError 形式暴露。
- 触发条件：JS 表达式 obj.split() 或 obj.split(',')
- 依据：第146-154行 arg_str == '' 时 argvals = tuple()，随后 assert argvals == ('',)
- 修复建议：对无参 split 单独处理，或放宽断言并实现分隔符语义。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
152: 
153:             if member == 'split':
154:                 assert argvals == ('',)
155:                 return list(obj)
156:             if member == 'join':
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 JSInterpreter 对 obj.split() 或 obj.split(',') 会因 assert argvals == ('',) 失败。但该断言是解释器对特定 JS 模式（split('') 用于把字符串拆成字符列表）的有意限制，属于实现内部约定，仓库中没有任何文档、测试或语言规则规定 obj.split() 或 obj.split(',') 必须被支持并返回特定值。youtube_dl 的 JSInterpreter 是受限的 JS 子集解释器，仅支持提取器实际用到的模式；对未支持的表达式抛出异常（包括 AssertionError）并非可定位契约所禁止的行为。缺少明确契约，无法构造有来源的预期行为，故不适用。

[运行证据](evidence/eed2c7e956d8/evidence.json)

### [低] 函数调用参数解析对非数字标识符直接索引 local_vars 可能 KeyError

- 位置：`youtube_dl/jsinterp.py:205`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第204-206行解析函数调用参数时，对每个参数 v，若 v.isdigit() 则转为 int，否则直接 local_vars[v]。当参数是未定义的标识符或字符串字面量（如 'abc'）时，会抛出 KeyError 而非 ExtractorError。正则 (?P<args>[a-zA-Z0-9_$,]+) 不允许引号，因此字符串字面量无法传入，但未定义变量名会触发 KeyError。
- 触发条件：JS 表达式 f(undefinedVar)
- 依据：第204-206行 int(v) if v.isdigit() else local_vars[v]
- 修复建议：使用 local_vars.get(v) 并在缺失时抛出 ExtractorError。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
203:             fname = m.group('func')
204:             argvals = tuple([
205:                 int(v) if v.isdigit() else local_vars[v]
206:                 for v in m.group('args').split(',')])
207:             if fname not in self._functions:
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] B007: Loop control variable `i` not used within loop body

- 位置：`youtube_dl/jsinterp.py:170`
- 来源：ruff B007
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Loop control variable `i` not used within loop body
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B007: Loop control variable `i` not used within loop body
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
168:                 index, howMany = argvals
169:                 res = []
170:                 for i in range(index, min(index + howMany, len(obj))):
171:                     res.append(obj.pop(index))
172:                 return res
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:98`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
96:                 idx = self.interpret_expression(
97:                     m.group('index'), local_vars, allow_recursion)
98:                 assert isinstance(idx, int)
99:                 cur = lvar[idx]
100:                 val = opfunc(cur, right_val)
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:144`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
142:                 return obj[member]
143: 
144:             assert expr.endswith(')')
145:             # Function call
146:             if arg_str == '':
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:154`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
152: 
153:             if member == 'split':
154:                 assert argvals == ('',)
155:                 return list(obj)
156:             if member == 'join':
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:157`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
155:                 return list(obj)
156:             if member == 'join':
157:                 assert len(argvals) == 1
158:                 return argvals[0].join(obj)
159:             if member == 'reverse':
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:160`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
158:                 return argvals[0].join(obj)
159:             if member == 'reverse':
160:                 assert len(argvals) == 0
161:                 obj.reverse()
162:                 return obj
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:164`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
162:                 return obj
163:             if member == 'slice':
164:                 assert len(argvals) == 1
165:                 return obj[argvals[0]:]
166:             if member == 'splice':
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`youtube_dl/jsinterp.py:167`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
165:                 return obj[argvals[0]:]
166:             if member == 'splice':
167:                 assert isinstance(obj, list)
168:                 index, howMany = argvals
169:                 res = []
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/jsinterp.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 49, "sensitive_file": 1, "benchmark_tests_hidden": 27}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
