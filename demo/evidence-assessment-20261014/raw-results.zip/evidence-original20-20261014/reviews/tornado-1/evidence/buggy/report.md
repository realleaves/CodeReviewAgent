# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`6a5a0bfa370b6c0d3dbbf9589a560a98202d2baa`
- 状态：**completed**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/62 个已索引 Python 文件
- 调用：8；耗时：14.974 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（1）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

### [低] ValueError 使用 %r 占位符但未做格式化

- 位置：`tornado/websocket.py:729`
- 来源：llm
- 复核：已复现 — 证据充分。测试直接调用原目标代码 _PerMessageDeflateCompressor(persistent=False, max_wbits=7)，输入有效（7 超出 [8,15] 范围，触发校验分支）。Python 语言规则明确：raise 后多个逗号分隔表达式作为独立位置参数传给异常构造函数，不做 % 格式化，因此 e.args 为三元组、str(e) 保留 %r/%d 占位符。运行观测到的失败消息 "('Invalid max_wbits value %r; allowed range 8-%d', 7, 15)" 与候选描述完全一致，且断言未假设未约定语义（仅要求占位符被替换、包含实际值），非无条件失败。缺陷成立。
- 问题：raise ValueError("Invalid max_wbits value %r; allowed range 8-%d", max_wbits, zlib.MAX_WBITS) 把参数作为独立参数传给 ValueError，而不是用 % 运算符格式化字符串。结果异常消息是元组形式（args 为三个元素），str(e) 会显示为 "('Invalid max_wbits value %r; allowed range 8-%d', <value>, 15)"，占位符未被替换，错误信息对用户不可读。
- 触发条件：构造 _PerMessageDeflateCompressor(persistent=False, max_wbits=7) 触发校验分支。
- 依据：第 729-733 行：raise ValueError("Invalid max_wbits value %r; allowed range 8-%d", max_wbits, zlib.MAX_WBITS)，缺少 % (max_wbits, zlib.MAX_WBITS)。
- 修复建议：改为 raise ValueError("Invalid max_wbits value %r; allowed range 8-%d" % (max_wbits, zlib.MAX_WBITS))。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
727:         # There is no symbolic constant for the minimum wbits value.
728:         if not (8 <= max_wbits <= zlib.MAX_WBITS):
729:             raise ValueError(
730:                 "Invalid max_wbits value %r; allowed range 8-%d",
731:                 max_wbits,
732:                 zlib.MAX_WBITS,
733:             )
734:         self._max_wbits = max_wbits
735: 
```

- 复现状态：reproduced
- 证据说明：证据充分。测试直接调用原目标代码 _PerMessageDeflateCompressor(persistent=False, max_wbits=7)，输入有效（7 超出 [8,15] 范围，触发校验分支）。Python 语言规则明确：raise 后多个逗号分隔表达式作为独立位置参数传给异常构造函数，不做 % 格式化，因此 e.args 为三元组、str(e) 保留 %r/%d 占位符。运行观测到的失败消息 "('Invalid max_wbits value %r; allowed range 8-%d', 7, 15)" 与候选描述完全一致，且断言未假设未约定语义（仅要求占位符被替换、包含实际值），非无条件失败。缺陷成立。

[运行证据](evidence/9c3894d4b559/evidence.json)

复现测试：

```python
import unittest

from tornado.websocket import _PerMessageDeflateCompressor


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        with self.assertRaises(ValueError) as ctx:
            _PerMessageDeflateCompressor(persistent=False, max_wbits=7)
        message = str(ctx.exception)
        self.assertNotIn("%r", message)
        self.assertNotIn("%d", message)
        self.assertIn("7", message)
        self.assertIn("15", message)

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 1, "errors": 0, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "failure", "exception_type": "AssertionError", "message": "'%r' unexpectedly found in \"('Invalid max_wbits value %r; allowed range 8-%d', 7, 15)\"", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    self.assertNotIn(\"%r\", message)\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 1126, in assertNotIn\n    self.fail(self._formatMessage(msg, standardMsg))\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 693, in fail\n    raise self.failureException(msg)\nAssertionError: '%r' unexpectedly found in \"('Invalid max_wbits value %r; allowed range 8-%d', 7, 15)\"\n"}], "target_lines": [17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 42, 55, 57, 102, 105, 106, 109, 113, 115, 118, 119, 122, 125, 126, 127, 128, 129, 136, 216, 220, 221, 222, 223, 231, 283, 285, 286, 293, 294, 301, 302, 315, 316, 344, 369, 370, 378, 402, 418, 429, 450, 454, 458, 471, 491, 547, 564, 574, 575, 580, 589, 599, 611, 626, 630, 632, 634, 641, 642, 661, 664, 672, 673, 676, 677, 680, 681, 684, 686, 687, 690, 691, 692, 695, 696, 703, 705, 706, 709, 710, 713, 714, 718, 723, 724, 725, 728, 729, 730, 731, 732, 754, 759, 766, 772, 773, 791, 794, 804, 809, 812, 813, 814, 815, 816, 817, 819, 823, 824, 825, 826, 858, 859, 862, 863, 866, 886, 896, 897, 906, 911, 963, 964, 971, 972, 995, 996, 1015, 1016, 1041, 1042, 1074, 1075, 1106, 1111, 1119, 1124, 1207, 1258, 1287, 1296, 1297, 1303, 1304, 1311, 1321, 1349, 1354, 1356, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1416, 1432, 1440, 1441, 1446, 1457, 1458, 1459, 1488, 1489, 1502, 1503, 1520, 1524, 1525, 1532, 1551, 1554, 1557, 1560, 1561, 1570, 1571, 1572, 1573, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589], "target_calls": [["<module>", 17], ["WebSocketClientConnection", 1349], ["WebSocketClosedError", 109], ["WebSocketError", 105], ["WebSocketHandler", 136], ["WebSocketProtocol", 630], ["WebSocketProtocol13", 804], ["_DecompressTooLargeError", 118], ["_PerMessageDeflateCompressor", 718], ["_PerMessageDeflateDecompressor", 766], ["_WebSocketParams", 122], ["__init__", 719]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 1, "errors": 0, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "failure", "exception_type": "AssertionError", "message": "'%r' unexpectedly found in \"('Invalid max_wbits value %r; allowed range 8-%d', 7, 15)\"", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    self.assertNotIn(\"%r\", message)\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 1126, in assertNotIn\n    self.fail(self._formatMessage(msg, standardMsg))\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 693, in fail\n    raise self.failureException(msg)\nAssertionError: '%r' unexpectedly found in \"('Invalid max_wbits value %r; allowed range 8-%d', 7, 15)\"\n"}], "target_lines": [17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 42, 55, 57, 102, 105, 106, 109, 113, 115, 118, 119, 122, 125, 126, 127, 128, 129, 136, 216, 220, 221, 222, 223, 231, 283, 285, 286, 293, 294, 301, 302, 315, 316, 344, 369, 370, 378, 402, 418, 429, 450, 454, 458, 471, 491, 547, 564, 574, 575, 580, 589, 599, 611, 626, 630, 632, 634, 641, 642, 661, 664, 672, 673, 676, 677, 680, 681, 684, 686, 687, 690, 691, 692, 695, 696, 703, 705, 706, 709, 710, 713, 714, 718, 723, 724, 725, 728, 729, 730, 731, 732, 754, 759, 766, 772, 773, 791, 794, 804, 809, 812, 813, 814, 815, 816, 817, 819, 823, 824, 825, 826, 858, 859, 862, 863, 866, 886, 896, 897, 906, 911, 963, 964, 971, 972, 995, 996, 1015, 1016, 1041, 1042, 1074, 1075, 1106, 1111, 1119, 1124, 1207, 1258, 1287, 1296, 1297, 1303, 1304, 1311, 1321, 1349, 1354, 1356, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1416, 1432, 1440, 1441, 1446, 1457, 1458, 1459, 1488, 1489, 1502, 1503, 1520, 1524, 1525, 1532, 1551, 1554, 1557, 1560, 1561, 1570, 1571, 1572, 1573, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589], "target_calls": [["<module>", 17], ["WebSocketClientConnection", 1349], ["WebSocketClosedError", 109], ["WebSocketError", 105], ["WebSocketHandler", 136], ["WebSocketProtocol", 630], ["WebSocketProtocol13", 804], ["_DecompressTooLargeError", 118], ["_PerMessageDeflateCompressor", 718], ["_PerMessageDeflateDecompressor", 766], ["_WebSocketParams", 122], ["__init__", 719]]}

```

## 待验证候选与静态建议

### [中] B006: Do not use mutable data structures for argument defaults

- 位置：`tornado/websocket.py:1366`
- 来源：ruff B006
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Do not use mutable data structures for argument defaults
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B006: Do not use mutable data structures for argument defaults
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1364:         ping_timeout: float = None,
1365:         max_message_size: int = _default_max_message_size,
1366:         subprotocols: Optional[List[str]] = [],
1367:     ) -> None:
1368:         self.connect_future = Future()  # type: Future[WebSocketClientConnection]
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:561`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
559:         .. versionadded:: 3.1
560:         """
561:         assert self.stream is not None
562:         self.stream.set_nodelay(value)
563: 
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:762`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
760:         compressor = self._compressor or self._create_compressor()
761:         data = compressor.compress(data) + compressor.flush(zlib.Z_SYNC_FLUSH)
762:         assert data.endswith(b"\x00\x00\xff\xff")
763:         return data[:-4]
764: 
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:1308`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1306:         if timeout is not None:
1307:             return timeout
1308:         assert self.ping_interval is not None
1309:         return max(3 * self.ping_interval, 30)
1310: 
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:1313`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1311:     def start_pinging(self) -> None:
1312:         """Start sending periodic pings to keep the connection alive"""
1313:         assert self.ping_interval is not None
1314:         if self.ping_interval > 0:
1315:             self.last_ping = self.last_pong = IOLoop.current().time()
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:1336`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1334:         since_last_pong = now - self.last_pong
1335:         since_last_ping = now - self.last_ping
1336:         assert self.ping_interval is not None
1337:         assert self.ping_timeout is not None
1338:         if (
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:1337`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1335:         since_last_ping = now - self.last_ping
1336:         assert self.ping_interval is not None
1337:         assert self.ping_timeout is not None
1338:         if (
1339:             since_last_ping < 2 * self.ping_interval
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/websocket.py | completed | window_completed | 3/3 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 188, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
