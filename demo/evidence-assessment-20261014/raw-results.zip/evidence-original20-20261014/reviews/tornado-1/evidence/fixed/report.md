# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`6a5a0bfa370b6c0d3dbbf9589a560a98202d2baa`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/62 个已索引 Python 文件
- 调用：11；耗时：24.006 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（1）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

### [中] 非 ws/wss 协议 URL 触发 KeyError

- 位置：`tornado/websocket.py:1389`
- 来源：llm
- 复核：已复现 — 测试确实调用了目标代码 WebSocketClientConnection.__init__，输入 HTTPRequest("http://example.com/") 有效且可达（websocket_connect 文档接受 url 或 HTTPRequest，未限制必须为 ws/wss）。第1388-1389行用 partition(":") 取 scheme 后直接以 scheme 为键访问 {"ws":"http","wss":"https"}，对 "http" 必然抛 KeyError，这是 Python 语言规则。运行观测到的 KeyError: 'http' 与候选描述一致。候选主张的是应给出清晰参数错误而非 KeyError，属于合理的健壮性缺陷，证据充分。
- 问题：第1388-1389行用 request.url.partition(":") 取 scheme，然后直接以 scheme 为键访问字典 {"ws": "http", "wss": "https"}。若传入的 URL 协议不是 ws 或 wss（例如 http、https 或缺少冒号），会抛出 KeyError 而非给出清晰的参数错误。
- 触发条件：WebSocketClientConnection(HTTPRequest("http://example.com/")) 或任何非 ws/wss 前缀的 URL。
- 依据：第1389行：scheme = {"ws": "http", "wss": "https"}[scheme]，对未知 scheme 直接 KeyError。
- 修复建议：使用 dict.get 并在缺失时抛出带有明确信息的 ValueError，或先校验 scheme 属于 {ws, wss}。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
1387: 
1388:         scheme, sep, rest = request.url.partition(":")
1389:         scheme = {"ws": "http", "wss": "https"}[scheme]
1390:         request.url = scheme + sep + rest
1391:         request.headers.update(
```

- 复现状态：reproduced
- 证据说明：测试确实调用了目标代码 WebSocketClientConnection.__init__，输入 HTTPRequest("http://example.com/") 有效且可达（websocket_connect 文档接受 url 或 HTTPRequest，未限制必须为 ws/wss）。第1388-1389行用 partition(":") 取 scheme 后直接以 scheme 为键访问 {"ws":"http","wss":"https"}，对 "http" 必然抛 KeyError，这是 Python 语言规则。运行观测到的 KeyError: 'http' 与候选描述一致。候选主张的是应给出清晰参数错误而非 KeyError，属于合理的健壮性缺陷，证据充分。

[运行证据](evidence/2cd97d34b1a2/evidence.json)

复现测试：

```python
import unittest

from tornado.httpclient import HTTPRequest
from tornado.websocket import WebSocketClientConnection


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        request = HTTPRequest("http://example.com/")
        with self.assertRaises(ValueError):
            WebSocketClientConnection(request)

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "KeyError", "message": "'http'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    WebSocketClientConnection(request)\n  File \"/work/tornado/websocket.py\", line 1389, in __init__\n    scheme = {\"ws\": \"http\", \"wss\": \"https\"}[scheme]\nKeyError: 'http'\n"}], "target_lines": [17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 42, 55, 57, 102, 105, 106, 109, 113, 115, 118, 119, 122, 125, 126, 127, 128, 129, 130, 131, 132, 133, 136, 216, 220, 221, 222, 223, 231, 283, 285, 286, 293, 294, 301, 302, 315, 316, 344, 369, 370, 378, 402, 418, 429, 450, 454, 458, 471, 491, 547, 564, 574, 575, 580, 589, 599, 611, 626, 630, 632, 634, 641, 642, 661, 664, 672, 673, 676, 677, 680, 681, 684, 686, 687, 690, 691, 692, 695, 696, 703, 705, 706, 709, 710, 713, 714, 717, 718, 722, 727, 728, 758, 763, 770, 776, 777, 795, 798, 808, 813, 816, 817, 818, 819, 820, 821, 823, 827, 828, 829, 830, 862, 863, 866, 867, 870, 890, 900, 901, 910, 915, 967, 968, 975, 976, 999, 1000, 1019, 1020, 1045, 1046, 1078, 1079, 1110, 1115, 1123, 1128, 1211, 1262, 1291, 1300, 1301, 1307, 1308, 1315, 1325, 1352, 1356, 1361, 1363, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1388, 1389, 1423, 1439, 1447, 1448, 1453, 1464, 1465, 1466, 1495, 1496, 1509, 1510, 1527, 1531, 1532, 1539, 1558, 1561, 1564, 1567, 1568, 1577, 1578, 1579, 1580, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596], "target_calls": [["<module>", 17], ["WebSocketClientConnection", 1356], ["WebSocketClosedError", 109], ["WebSocketError", 105], ["WebSocketHandler", 136], ["WebSocketProtocol", 630], ["WebSocketProtocol13", 808], ["_DecompressTooLargeError", 118], ["_PerMessageDeflateCompressor", 722], ["_PerMessageDeflateDecompressor", 770], ["_WebSocketParams", 122], ["__init__", 123], ["__init__", 1365]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "KeyError", "message": "'http'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    WebSocketClientConnection(request)\n  File \"/work/tornado/websocket.py\", line 1389, in __init__\n    scheme = {\"ws\": \"http\", \"wss\": \"https\"}[scheme]\nKeyError: 'http'\n"}], "target_lines": [17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 42, 55, 57, 102, 105, 106, 109, 113, 115, 118, 119, 122, 125, 126, 127, 128, 129, 130, 131, 132, 133, 136, 216, 220, 221, 222, 223, 231, 283, 285, 286, 293, 294, 301, 302, 315, 316, 344, 369, 370, 378, 402, 418, 429, 450, 454, 458, 471, 491, 547, 564, 574, 575, 580, 589, 599, 611, 626, 630, 632, 634, 641, 642, 661, 664, 672, 673, 676, 677, 680, 681, 684, 686, 687, 690, 691, 692, 695, 696, 703, 705, 706, 709, 710, 713, 714, 717, 718, 722, 727, 728, 758, 763, 770, 776, 777, 795, 798, 808, 813, 816, 817, 818, 819, 820, 821, 823, 827, 828, 829, 830, 862, 863, 866, 867, 870, 890, 900, 901, 910, 915, 967, 968, 975, 976, 999, 1000, 1019, 1020, 1045, 1046, 1078, 1079, 1110, 1115, 1123, 1128, 1211, 1262, 1291, 1300, 1301, 1307, 1308, 1315, 1325, 1352, 1356, 1361, 1363, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1388, 1389, 1423, 1439, 1447, 1448, 1453, 1464, 1465, 1466, 1495, 1496, 1509, 1510, 1527, 1531, 1532, 1539, 1558, 1561, 1564, 1567, 1568, 1577, 1578, 1579, 1580, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596], "target_calls": [["<module>", 17], ["WebSocketClientConnection", 1356], ["WebSocketClosedError", 109], ["WebSocketError", 105], ["WebSocketHandler", 136], ["WebSocketProtocol", 630], ["WebSocketProtocol13", 808], ["_DecompressTooLargeError", 118], ["_PerMessageDeflateCompressor", 722], ["_PerMessageDeflateDecompressor", 770], ["_WebSocketParams", 122], ["__init__", 123], ["__init__", 1365]]}

```

## 待验证候选与静态建议

### [低] ValueError 使用 %r 格式化占位符但未做 % 格式化

- 位置：`tornado/websocket.py:733`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：raise ValueError("Invalid max_wbits value %r; allowed range 8-%d", max_wbits, zlib.MAX_WBITS) 把格式字符串和参数作为多个位置参数传给 ValueError，而不是先做 % 格式化。结果是异常消息为字面量 "Invalid max_wbits value %r; allowed range 8-%d"，且 args 为三元组，用户看不到实际的 max_wbits 值。预期应使用 % (max_wbits, zlib.MAX_WBITS) 生成可读消息。
- 触发条件：构造 _PerMessageDeflateCompressor(persistent=False, max_wbits=4)（或任何 <8 或 >zlib.MAX_WBITS 的值）。
- 依据：第 733-737 行：raise ValueError("Invalid max_wbits value %r; allowed range 8-%d", max_wbits, zlib.MAX_WBITS)。对比第 782-786 行 _PerMessageDeflateDecompressor 中同样的写法，属同一模式。
- 修复建议：改为 raise ValueError("Invalid max_wbits value %r; allowed range 8-%d" % (max_wbits, zlib.MAX_WBITS))。
- 验证方式：测试导入不在目标模块/受支持标准库集合中。

```python
731:         # There is no symbolic constant for the minimum wbits value.
732:         if not (8 <= max_wbits <= zlib.MAX_WBITS):
733:             raise ValueError(
734:                 "Invalid max_wbits value %r; allowed range 8-%d",
735:                 max_wbits,
736:                 zlib.MAX_WBITS,
737:             )
738:         self._max_wbits = max_wbits
739: 
```

- 复现状态：invalid_plan
- 证据说明：测试导入不在目标模块/受支持标准库集合中。

[运行证据](evidence/53ebe93cb238/evidence.json)

复现测试：

```python
import unittest
import zlib
from tornado.websocket import _PerMessageDeflateCompressor


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        with self.assertRaises(ValueError) as ctx:
            _PerMessageDeflateCompressor(persistent=False, max_wbits=4)
        msg = str(ctx.exception)
        self.assertNotIn("%r", msg)
        self.assertNotIn("%d", msg)
        self.assertIn("4", msg)
        self.assertIn(str(zlib.MAX_WBITS), msg)

```

### [中] 可变默认参数 subprotocols=[] 在实例间共享

- 位置：`tornado/websocket.py:1373`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：WebSocketClientConnection.__init__ 使用可变列表 [] 作为 subprotocols 的默认值。虽然当前代码只读取该列表（第1399-1400行 join），未直接修改，但默认对象在多次调用间共享，任何后续对 subprotocols 的原地修改都会污染其他实例的默认值。这是 Python 中典型的可变默认参数缺陷。
- 触发条件：调用 WebSocketClientConnection(request) 不传 subprotocols，随后（或未来代码）对 self.subprotocols 或该默认列表执行 append 等原地修改，则下一次不传 subprotocols 的实例会看到被修改的列表。
- 依据：第1373行：subprotocols: Optional[List[str]] = []，默认值为可变列表字面量。
- 修复建议：将默认值改为 None，并在函数体内按需初始化为 []，例如 subprotocols: Optional[List[str]] = None，然后 if subprotocols is None: subprotocols = []。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1371:         ping_timeout: float = None,
1372:         max_message_size: int = _default_max_message_size,
1373:         subprotocols: Optional[List[str]] = [],
1374:     ) -> None:
1375:         self.connect_future = Future()  # type: Future[WebSocketClientConnection]
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称可变默认参数 subprotocols=[] 会在实例间共享，但当前实现只读取该列表（第1399-1400行 join），从未原地修改它，也没有任何代码路径会修改它。要触发该缺陷需要假设未来代码对 self.subprotocols 或默认列表执行 append 等原地修改，这属于推测性场景，无法在当前代码上构造真实失败的最小复现。此外，WebSocketClientConnection 的 __init__ 会创建 TCPClient 并调用父类 _HTTPConnection.__init__，需要有效的 HTTPRequest 和事件循环，难以在只读环境下构造有效输入。因此不适用。

[运行证据](evidence/31cc9f2d1709/evidence.json)

### [中] B006: Do not use mutable data structures for argument defaults

- 位置：`tornado/websocket.py:1373`
- 来源：ruff B006
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Do not use mutable data structures for argument defaults
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B006: Do not use mutable data structures for argument defaults
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1371:         ping_timeout: float = None,
1372:         max_message_size: int = _default_max_message_size,
1373:         subprotocols: Optional[List[str]] = [],
1374:     ) -> None:
1375:         self.connect_future = Future()  # type: Future[WebSocketClientConnection]
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:561`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
559:         .. versionadded:: 3.1
560:         """
561:         assert self.ws_connection is not None
562:         self.ws_connection.set_nodelay(value)
563: 
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:766`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
764:         compressor = self._compressor or self._create_compressor()
765:         data = compressor.compress(data) + compressor.flush(zlib.Z_SYNC_FLUSH)
766:         assert data.endswith(b"\x00\x00\xff\xff")
767:         return data[:-4]
768: 
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:1312`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1310:         if timeout is not None:
1311:             return timeout
1312:         assert self.ping_interval is not None
1313:         return max(3 * self.ping_interval, 30)
1314: 
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:1317`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1315:     def start_pinging(self) -> None:
1316:         """Start sending periodic pings to keep the connection alive"""
1317:         assert self.ping_interval is not None
1318:         if self.ping_interval > 0:
1319:             self.last_ping = self.last_pong = IOLoop.current().time()
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:1340`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1338:         since_last_pong = now - self.last_pong
1339:         since_last_ping = now - self.last_ping
1340:         assert self.ping_interval is not None
1341:         assert self.ping_timeout is not None
1342:         if (
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/websocket.py:1341`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1339:         since_last_ping = now - self.last_ping
1340:         assert self.ping_interval is not None
1341:         assert self.ping_timeout is not None
1342:         if (
1343:             since_last_ping < 2 * self.ping_interval
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/websocket.py | completed | window_completed | 3/3 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 188, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
