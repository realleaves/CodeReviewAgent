import unittest
import zlib
from tornado.websocket import _PerMessageDeflateCompressor


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        with self.assertRaises(ValueError) as ctx:
            _PerMessageDeflateCompressor(persistent=False, max_wbits=4)
        msg = str(ctx.exception)
        self.assertNotIn("%r", msg)
        self.assertNotIn("%d", msg)
        self.assertIn("4", msg)
        self.assertIn(str(zlib.MAX_WBITS), msg)
