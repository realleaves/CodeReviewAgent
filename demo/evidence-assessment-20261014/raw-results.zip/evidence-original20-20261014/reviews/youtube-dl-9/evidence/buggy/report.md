# GitHub 仓库代码审查报告

- 仓库：https://github.com/ytdl-org/youtube-dl
- 分支：blinded-snapshot
- Commit：`0130afb76e5cb6f470f39f127c8d09eea3e82d0d`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/563 个已索引 Python 文件
- 调用：16；耗时：38.913 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（1）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

### [低] best/worst 在 formats 为空时索引越界

- 位置：`youtube_dl/YoutubeDL.py:1015`
- 来源：llm
- 复核：已复现 — 测试确实调用了原目标代码：通过 YoutubeDL.build_format_selector('best') 构造 selector 并迭代 selector([])，traceback 显示执行到 YoutubeDL.py:1017 的 yield formats[format_idx] 并抛出 IndexError。输入为空列表 formats 有效，代码路径经静态复核确认：audiovideo_formats 为空进入 elif，all() 对空可迭代返回 True，随后 formats[-1] 越界。该行为由 Python 语言规则（空列表索引抛 IndexError）支持，不依赖仓库未约定语义。观察到的失败与候选描述一致，测试未复制实现或制造无条件失败。因此证据充分，可支持正式缺陷报告。
- 问题：当 format_spec 为 'best'/'worst' 且 formats 为空列表时，audiovideo_formats 为空，进入 elif 分支，all(...) 对空列表返回 True，于是执行 yield formats[format_idx]，即 formats[-1] 或 formats[0]，对空列表索引会抛 IndexError。
- 触发条件：formats 为空列表且 format_spec 为 'best' 或 'worst'
- 依据：第 1015-1017 行：all(f.get('acodec') != 'none' for f in formats) 对空列表为 True，随后 formats[format_idx] 越界。
- 修复建议：在索引前检查 formats 非空。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
1013:                             yield audiovideo_formats[format_idx]
1014:                         # for audio only (soundcloud) or video only (imgur) urls, select the best/worst audio format
1015:                         elif (all(f.get('acodec') != 'none' for f in formats) or
1016:                               all(f.get('vcodec') != 'none' for f in formats)):
1017:                             yield formats[format_idx]
1018:                     elif format_spec == 'bestaudio':
1019:                         audio_formats = [
```

- 复现状态：reproduced
- 证据说明：测试确实调用了原目标代码：通过 YoutubeDL.build_format_selector('best') 构造 selector 并迭代 selector([])，traceback 显示执行到 YoutubeDL.py:1017 的 yield formats[format_idx] 并抛出 IndexError。输入为空列表 formats 有效，代码路径经静态复核确认：audiovideo_formats 为空进入 elif，all() 对空可迭代返回 True，随后 formats[-1] 越界。该行为由 Python 语言规则（空列表索引抛 IndexError）支持，不依赖仓库未约定语义。观察到的失败与候选描述一致，测试未复制实现或制造无条件失败。因此证据充分，可支持正式缺陷报告。

[运行证据](evidence/9f669fbbebd2/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        selector = ydl.build_format_selector('best')
        # formats 为空列表时，迭代 selector 不应抛出 IndexError
        result = list(selector([]))
        self.assertEqual(result, [])

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "IndexError", "message": "list index out of range", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    result = list(selector([]))\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in selector_function\n    for format in f(formats):\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1017, in selector_function\n    yield formats[format_idx]\nIndexError: list index out of range\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 974, 975, 976, 977, 978, 980, 981, 982, 984, 985, 986, 988, 989, 991, 1000, 1001, 1003, 1004, 1007, 1008, 1010, 1012, 1015, 1017, 1089, 1091, 1092, 1094, 1095, 1097, 1098, 1099, 1103, 1104, 1105, 1106, 1108, 1109, 1111, 1112, 1114, 1115, 1116, 1118, 1120, 1123, 1124, 1126, 1139, 1144, 1284, 1333, 1597, 1621, 1638, 1644, 1666, 1677, 1696, 1705, 1706, 1722, 1772, 1786, 1803, 1814, 1839, 1840, 1841, 1904, 1905, 1906, 1908, 1909, 1911, 1912, 1919, 1920, 1921, 1927, 1929, 1931, 1933, 1934, 1935, 1936, 1937, 1942, 1943, 1945, 1955, 1961], "target_calls": [["<genexpr>", 1015], ["<listcomp>", 982], ["<listcomp>", 1010], ["<listcomp>", 1089], ["<module>", 4], ["TokenIterator", 1103], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1104], ["__iter__", 1108], ["__next__", 1111], ["_build_selector_function", 980], ["_parse_format_selection", 934], ["_setup_opener", 1904], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["final_selector", 1091], ["print_debug_header", 1839], ["selector_function", 984], ["selector_function", 1003]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "IndexError", "message": "list index out of range", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    result = list(selector([]))\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in selector_function\n    for format in f(formats):\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1017, in selector_function\n    yield formats[format_idx]\nIndexError: list index out of range\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 974, 975, 976, 977, 978, 980, 981, 982, 984, 985, 986, 988, 989, 991, 1000, 1001, 1003, 1004, 1007, 1008, 1010, 1012, 1015, 1017, 1089, 1091, 1092, 1094, 1095, 1097, 1098, 1099, 1103, 1104, 1105, 1106, 1108, 1109, 1111, 1112, 1114, 1115, 1116, 1118, 1120, 1123, 1124, 1126, 1139, 1144, 1284, 1333, 1597, 1621, 1638, 1644, 1666, 1677, 1696, 1705, 1706, 1722, 1772, 1786, 1803, 1814, 1839, 1840, 1841, 1904, 1905, 1906, 1908, 1909, 1911, 1912, 1919, 1920, 1921, 1927, 1929, 1931, 1933, 1934, 1935, 1936, 1937, 1942, 1943, 1945, 1955, 1961], "target_calls": [["<genexpr>", 1015], ["<listcomp>", 982], ["<listcomp>", 1010], ["<listcomp>", 1089], ["<module>", 4], ["TokenIterator", 1103], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1104], ["__iter__", 1108], ["__next__", 1111], ["_build_selector_function", 980], ["_parse_format_selection", 934], ["_setup_opener", 1904], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["final_selector", 1091], ["print_debug_header", 1839], ["selector_function", 984], ["selector_function", 1003]]}

```

## 待验证候选与静态建议

### [中] none_inclusive 返回字符串而非布尔值，导致过滤结果错误

- 位置：`youtube_dl/YoutubeDL.py:909`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：_filter 在 actual_value 为 None 时返回 m.group('none_inclusive')，该值是正则捕获组 (?P<none_inclusive>\s*\?)? 匹配到的字符串（如 '?' 或 None），而不是布尔值。filter() 会把非空字符串 '?' 视为真值，从而保留该格式；但语义上 none_inclusive 表示“当字段缺失时是否包含”，应返回布尔。返回字符串 '?' 与返回 True 在 filter 中效果相同，但返回 None 时 filter 视为假，行为正确。真正的问题在于：当 none_inclusive 匹配到 '?' 时返回的是字符串 '?'，虽然 filter 中为真，但若该函数被用于其他需要布尔语义的上下文（如直接比较）会出错。更关键的是，当 actual_value 为 None 且 none_inclusive 未匹配（返回 None）时，filter 会丢弃该格式，这是预期行为。因此该处返回类型不一致（有时 bool，有时 str/None），属于契约不一致。
- 触发条件：format_spec 形如 'height>720?'，且某格式的 height 字段为 None
- 依据：第 906-910 行：_filter 返回 m.group('none_inclusive')，该组为可选字符串捕获，返回 '?' 或 None，而非布尔值。
- 修复建议：改为 return m.group('none_inclusive') is not None，保证返回布尔值。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
907:             actual_value = f.get(m.group('key'))
908:             if actual_value is None:
909:                 return m.group('none_inclusive')
910:             return op(actual_value, comparison_value)
911:         return _filter
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 _filter 在 actual_value 为 None 时返回字符串 '?' 而非布尔值，导致类型不一致。但该返回值仅被用作 filter() 的谓词：非空字符串 '?' 在布尔上下文中为真，None 为假，恰好实现了 none_inclusive 的语义（字段缺失时是否包含）。仓库中 utils.py 的 _match_one 存在完全相同的实现模式，表明这是有意设计。候选描述本身也承认在 filter 上下文中行为正确，仅推测其他上下文会出错，但没有任何调用者以布尔语义直接比较该返回值。因此不存在可定位的契约要求返回布尔值，也无法构造出真实 bug 导致失败的复现测试。

[运行证据](evidence/d57750f84115/evidence.json)

### [中] _merge 解包 formats_info 假定恰好两个元素，且 report_error 后返回 None 导致下游崩溃

- 位置：`youtube_dl/YoutubeDL.py:1053`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：_merge 中 format_1, format_2 = [f['format_id'] for f in formats_info] 假定 formats_info 恰好有两个元素。当 MERGE 选择器通过 itertools.product 生成 pair 时通常为两个，但若 video_selector 或 audio_selector 返回空，product 不产生 pair，不会调用 _merge。然而当第一个格式 vcodec 为 'none' 时，report_error 被调用后 return None，selector_function 会 yield None，下游消费该 None 作为格式字典会触发 AttributeError/TypeError。
- 触发条件：使用 -f 'bestvideo+bestaudio' 且第一个选中格式的 vcodec 为 'none'
- 依据：第 1056-1060 行：report_error 后 return（返回 None），第 1087 行 yield _merge(pair) 将 None 产出。
- 修复建议：report_error 后应 raise 或跳过该 pair，避免 yield None。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1051:             elif selector.type == MERGE:
1052:                 def _merge(formats_info):
1053:                     format_1, format_2 = [f['format_id'] for f in formats_info]
1054:                     # The first format must contain the video and the
1055:                     # second the audio
1056:                     if formats_info[0].get('vcodec') == 'none':
1057:                         self.report_error('The first format must '
1058:                                           'contain the video, try using '
1059:                                           '"-f %s+%s"' % (format_2, format_1))
1060:                         return
1061:                     output_ext = (
1062:                         formats_info[0]['ext']
```

- 复现状态：unsupported
- 证据说明：候选缺陷依赖 report_error 在 ignoreerrors=True 时返回 None 并被 yield 的路径，但仓库中无文档或测试明确约定该路径的返回值或行为；同时构造触发条件需要伪造 formats 列表使 video_selector 选中 vcodec=='none' 的格式，并设置 ignoreerrors=True，这属于对内部实现细节的推断而非可定位契约。缺少明确预期行为，无法生成有来源断言的复现测试。

[运行证据](evidence/63d9e0aab170/evidence.json)

### [低] 按扩展名或 format_id 过滤时使用 f['ext']/f['format_id'] 直接下标，缺失键会 KeyError

- 位置：`youtube_dl/YoutubeDL.py:1045`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：filter_f 使用 f['ext'] == format_spec 或 f['format_id'] == format_spec 直接下标访问。若某个格式字典缺少 'ext' 或 'format_id' 键，会抛 KeyError 而非跳过该格式。其他分支使用 f.get(...) 更安全，此处不一致。
- 触发条件：format_spec 为 'mp4' 等扩展名，且某格式字典无 'ext' 键
- 依据：第 1045-1047 行：filter_f = lambda f: f['ext'] == format_spec / f['format_id'] == format_spec。
- 修复建议：改用 f.get('ext') / f.get('format_id')。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1043:                         extensions = ['mp4', 'flv', 'webm', '3gp', 'm4a', 'mp3', 'ogg', 'aac', 'wav']
1044:                         if format_spec in extensions:
1045:                             filter_f = lambda f: f['ext'] == format_spec
1046:                         else:
1047:                             filter_f = lambda f: f['format_id'] == format_spec
1048:                         matches = list(filter(filter_f, formats))
1049:                         if matches:
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] B007: Loop control variable `start` not used within loop body

- 位置：`youtube_dl/YoutubeDL.py:928`
- 来源：ruff B007
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Loop control variable `start` not used within loop body
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B007: Loop control variable `start` not used within loop body
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
926:         def _parse_filter(tokens):
927:             filter_parts = []
928:             for type, string, start, _, _ in tokens:
929:                 if type == tokenize.OP and string == ']':
930:                     return ''.join(filter_parts)
```

### [中] B006: Do not use mutable data structures for argument defaults

- 位置：`youtube_dl/YoutubeDL.py:934`
- 来源：ruff B006
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Do not use mutable data structures for argument defaults
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B006: Do not use mutable data structures for argument defaults
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
932:                     filter_parts.append(string)
933: 
934:         def _parse_format_selection(tokens, endwith=[]):
935:             selectors = []
936:             current_selector = None
```

### [低] B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling

- 位置：`youtube_dl/YoutubeDL.py:1101`
- 来源：ruff B904
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1099:             tokens = list(compat_tokenize_tokenize(stream.readline))
1100:         except tokenize.TokenError:
1101:             raise syntax_error('Missing closing/opening brackets or parenthesis', (0, len(format_spec)))
1102: 
1103:         class TokenIterator(object):
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/YoutubeDL.py | completed | partial | 1/2 |

## 失败记录

```json
[
  {
    "stage": "review_or_verify",
    "path": "youtube_dl/YoutubeDL.py",
    "reason": "模型调用失败（APIStatusError），检查配置、额度或网络。"
  }
]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 44, "sensitive_file": 1, "benchmark_tests_hidden": 23}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
