# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`2ca8821d006f6693f920a4b183a3a7c985a5c8ad`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/62 个已索引 Python 文件
- 调用：9；耗时：18.031 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] HEAD 响应仍可能设置 _expected_content_remaining 为 Content-Length 值

- 位置：`tornado/http1connection.py:431`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：在 write_headers 中，当非客户端且请求方法为 HEAD 或响应码为 304 时，_expected_content_remaining 被设为 0（第 431-435 行）。但该分支仅在 self.is_client 为 False 时生效。对于 HEAD 请求，应用通常仍会设置 Content-Length 头以描述资源大小，此时 _expected_content_remaining 被强制为 0，后续 write() 调用任何非空 chunk 都会触发 _format_chunk 中的负值检查并抛出 HTTPOutputError。这是有意的行为（HEAD 不应有 body），但需注意：若应用在 HEAD 响应中写入 body，会得到 HTTPOutputError 而非静默丢弃。此行为符合 HTTP 规范，但错误信息 'Tried to write more data than Content-Length' 对 HEAD 场景具有误导性。
- 触发条件：服务端处理 HEAD 请求，应用调用 write_headers 设置 Content-Length: 100，随后调用 write(b'x')。
- 依据：第 431-435 行：if not self.is_client and (self._request_start_line.method == 'HEAD' or ...code == 304): self._expected_content_remaining = 0。第 465-472 行：_format_chunk 中 _expected_content_remaining 减 len(chunk) 后 < 0 则抛 HTTPOutputError。
- 修复建议：若认为该行为正确，可保留；否则在 HEAD/304 分支中区分处理，或在错误信息中说明 HEAD 响应不应包含 body。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
429:         if self._chunking_output:
430:             headers["Transfer-Encoding"] = "chunked"
431:         if not self.is_client and (
432:             self._request_start_line.method == "HEAD"
433:             or cast(httputil.ResponseStartLine, start_line).code == 304
434:         ):
435:             self._expected_content_remaining = 0
436:         elif "Content-Length" in headers:
437:             self._expected_content_remaining = int(headers["Content-Length"])
438:         else:
439:             self._expected_content_remaining = None
```

- 复现状态：unsupported
- 证据说明：候选缺陷描述的行为（HEAD/304 响应中 _expected_content_remaining 被设为 0，随后写入非空 body 触发 HTTPOutputError）实际上是符合 HTTP 规范的有意设计：HEAD 响应和 304 响应不应包含消息体。候选本身也承认“这是有意的行为（HEAD 不应有 body）”“此行为符合 HTTP 规范”，其唯一抱怨是错误信息措辞对 HEAD 场景“具有误导性”，这属于文案/可用性建议，而非可定位契约下的功能缺陷。

要构造复现测试，需要断言一个“正确行为”。但仓库中没有任何文档或测试约定：HEAD 响应中应用写入 body 时应被静默丢弃、或应返回特定错误信息。代码现有实现（抛 HTTPOutputError）不能单独作为期望值的依据。因此不存在可准确定位的契约来判定当前行为是 bug。

此外，构造该测试需要实例化 HTTP1Connection 并驱动 write_headers/write，涉及 IOStream、请求起始行等内部状态，在只读源码、无网络环境下难以构造有效输入，且断言目标（错误信息文本）无契约支撑。故 applicable=false，不编造测试。

[运行证据](evidence/ebdd75b655fd/evidence.json)

### [中] Content-Length 头值非数字时 int() 抛出未捕获的 ValueError

- 位置：`tornado/http1connection.py:437`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 437 行直接执行 int(headers['Content-Length'])。若应用传入非数字的 Content-Length（例如空字符串、'abc'、带空格的 ' 100 ' 或负数 '-1'），int() 会抛出 ValueError，该异常从 write_headers 传播出去，而非转换为 HTTPOutputError 或返回失败的 Future。调用方（如 web.py 的响应处理）可能未预期此异常类型，导致连接状态不一致。
- 触发条件：应用调用 write_headers 并设置 headers['Content-Length'] = 'abc' 或 ''。
- 依据：第 436-437 行：elif 'Content-Length' in headers: self._expected_content_remaining = int(headers['Content-Length'])。int('abc') 抛 ValueError。
- 修复建议：使用 try/except 包裹 int() 转换，或在转换失败时抛出 HTTPOutputError 并关闭流。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
435:             self._expected_content_remaining = 0
436:         elif "Content-Length" in headers:
437:             self._expected_content_remaining = int(headers["Content-Length"])
438:         else:
439:             self._expected_content_remaining = None
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 int(headers['Content-Length']) 在非数字值时会抛出未捕获的 ValueError，但无法定位到任何明确契约要求该输入必须被转换为 HTTPOutputError 或返回失败 Future。write_headers 的文档字符串仅说明 'Implements .HTTPConnection.write_headers'，未规定对非法 Content-Length 的处理方式；仓库中也没有相关测试或文档约定。代码中确实存在对换行符抛 ValueError 的先例（第449行），说明对非法头部值直接抛 ValueError 是既有设计模式，而非缺陷。因此无法构造有契约依据的复现测试，applicable=false。

[运行证据](evidence/4d06a2fd2469/evidence.json)

### [低] write_headers 中 chunk 参数在 chunking 关闭时仍被 _format_chunk 处理

- 位置：`tornado/http1connection.py:458`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 458-459 行：if chunk: data += self._format_chunk(chunk)。当 _chunking_output 为 False 且 _expected_content_remaining 为 None 时，_format_chunk 直接返回 chunk 原样，行为正确。但当 _expected_content_remaining 为 0（如 HEAD 响应）且 chunk 非空时，_format_chunk 会抛出 HTTPOutputError，而此时 write_headers 尚未返回 Future，异常直接抛出。这与 write() 的行为一致，但 write_headers 的文档未说明可能抛出 HTTPOutputError。
- 触发条件：服务端 HEAD 请求，write_headers(start_line, headers, chunk=b'data')。
- 依据：第 458-459 行调用 _format_chunk(chunk)，第 465-472 行在 _expected_content_remaining < 0 时抛 HTTPOutputError。
- 修复建议：在 write_headers 文档中说明可能抛出 HTTPOutputError，或统一异常处理路径。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
456:             future = self._write_future = Future()
457:             data = b"\r\n".join(lines) + b"\r\n\r\n"
458:             if chunk:
459:                 data += self._format_chunk(chunk)
460:             self._pending_write = self.stream.write(data)
461:             future_add_done_callback(self._pending_write, self._on_write_complete)
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 write_headers 在 HEAD 响应且 chunk 非空时会抛出 HTTPOutputError，但未找到任何文档或测试契约规定 write_headers 在 HEAD 响应中传入非空 chunk 的预期行为。httputil.HTTPConnection.write_headers 的文档（tornado/httputil.py 第596-611行）仅说明 chunk 是可选的首个数据块优化，未约定 HEAD 响应下传入非空 chunk 的返回值或异常。代码中 _expected_content_remaining=0 时 _format_chunk 抛 HTTPOutputError 属于对超量写入的防护，是合理默认行为，而非可定位契约所要求的返回值。缺少明确契约，无法构造有来源的断言，故不适用。

[运行证据](evidence/20341ca22690/evidence.json)

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/http1connection.py:385`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
383:         lines = []
384:         if self.is_client:
385:             assert isinstance(start_line, httputil.RequestStartLine)
386:             self._request_start_line = start_line
387:             lines.append(utf8("%s %s HTTP/1.1" % (start_line[0], start_line[1])))
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/http1connection.py:396`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
394:             )
395:         else:
396:             assert isinstance(start_line, httputil.ResponseStartLine)
397:             assert self._request_start_line is not None
398:             assert self._request_headers is not None
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/http1connection.py:397`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
395:         else:
396:             assert isinstance(start_line, httputil.ResponseStartLine)
397:             assert self._request_start_line is not None
398:             assert self._request_headers is not None
399:             self._response_start_line = start_line
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/http1connection.py:398`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
396:             assert isinstance(start_line, httputil.ResponseStartLine)
397:             assert self._request_start_line is not None
398:             assert self._request_headers is not None
399:             self._response_start_line = start_line
400:             lines.append(utf8("HTTP/1.1 %d %s" % (start_line[1], start_line[2])))
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/http1connection.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 187, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
