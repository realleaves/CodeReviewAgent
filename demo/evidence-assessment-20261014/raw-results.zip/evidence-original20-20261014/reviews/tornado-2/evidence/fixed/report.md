# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`2ca8821d006f6693f920a4b183a3a7c985a5c8ad`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/62 个已索引 Python 文件
- 调用：7；耗时：13.469 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] Content-Length 头解析未捕获非法值导致 ValueError 崩溃

- 位置：`tornado/http1connection.py:439`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：write_headers 在响应/请求头包含 Content-Length 时直接执行 int(headers["Content-Length"])。若应用传入非数字（如空字符串、'abc'、带逗号的多值 '10, 20'）或非 ASCII 字节串，int() 会抛出 ValueError，该异常从 write_headers 直接冒泡，而不是被转换为 HTTPOutputError 或产生明确的协议错误。相比 _format_chunk 中对超长写入会关闭流并抛 HTTPOutputError 的处理，这里缺少对非法 Content-Length 的防御，导致调用方（如 web 框架）在构造响应时崩溃。
- 触发条件：调用 write_headers(start_line, headers)，其中 headers 含 Content-Length: 'abc'（或 ''、'10, 20'）。
- 依据：第 439-440 行：elif "Content-Length" in headers: self._expected_content_remaining = int(headers["Content-Length"])，无 try/except 或校验。
- 修复建议：在解析前校验 Content-Length 是否为合法非负整数，非法时抛出 httputil.HTTPOutputError 或关闭流，避免裸 ValueError 冒泡。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
437:         ):
438:             self._expected_content_remaining = 0
439:         elif "Content-Length" in headers:
440:             self._expected_content_remaining = int(headers["Content-Length"])
441:         else:
442:             self._expected_content_remaining = None
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 write_headers 对非法 Content-Length 值（如 'abc'、''、'10, 20'）会抛出裸 ValueError 而非 HTTPOutputError。但仓库中没有任何文档、测试或语言规则约定 write_headers 必须把非法 Content-Length 转换为 HTTPOutputError。int() 对非数字字符串抛 ValueError 是 Python 语言规则，属于调用方传入非法输入时的正常行为，而非可定位的契约违反。_format_chunk 中抛 HTTPOutputError 是针对'写入超过 Content-Length'这一不同场景的既有约定，不能据此推断非法 Content-Length 也必须抛 HTTPOutputError。缺少明确的期望行为契约，无法构造有来源的断言，故不适用。

[运行证据](evidence/06f5d9c1e9d4/evidence.json)

### [低] HEAD/304 分支忽略显式 Content-Length 导致后续写入被误判

- 位置：`tornado/http1connection.py:434`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：当请求方法为 HEAD 或响应码为 304 时，_expected_content_remaining 被强制设为 0，即使 headers 中显式提供了 Content-Length（HEAD 响应常带 Content-Length 表示实体长度）。随后若应用对 HEAD 请求调用 write() 写入非空 body（某些框架会复用 GET 处理逻辑），_format_chunk 会因 _expected_content_remaining 从 0 减为负而关闭流并抛 HTTPOutputError。虽然 HEAD 不应有 body，但该分支使显式 Content-Length 被静默忽略，行为与头部声明不一致。
- 触发条件：服务器收到 HEAD 请求，write_headers 传入含 Content-Length: 100 的响应头，随后调用 write(b'x')。
- 依据：第 434-438 行：if not self.is_client and (method == 'HEAD' or code == 304): self._expected_content_remaining = 0，优先于第 439 行的 Content-Length 解析。
- 修复建议：确认 HEAD/304 场景下是否应保留 Content-Length 语义；若需允许头部声明长度，应调整分支顺序或单独记录声明长度。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
432:         if self._chunking_output:
433:             headers["Transfer-Encoding"] = "chunked"
434:         if not self.is_client and (
435:             self._request_start_line.method == "HEAD"
436:             or cast(httputil.ResponseStartLine, start_line).code == 304
437:         ):
438:             self._expected_content_remaining = 0
439:         elif "Content-Length" in headers:
440:             self._expected_content_remaining = int(headers["Content-Length"])
441:         else:
442:             self._expected_content_remaining = None
443:         # TODO: headers are supposed to be of type str, but we still have some
444:         # cases that let bytes slip through. Remove these native_str calls when those
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 HEAD/304 分支忽略显式 Content-Length 导致后续 write() 被误判为超长。但代码注释（第152-153行、第233-236行、第409-411行）明确说明 HEAD 与 304 响应“有 content-length 但没有 body”，且 RFC 7230 §3.3 规定 304 不得有消息体。因此将 _expected_content_remaining 置 0 是符合协议的有意行为，而非缺陷。候选描述中“某些框架会复用 GET 处理逻辑对 HEAD 写入非空 body”属于假设场景，仓库内 web.py 第1077-1079行明确对 HEAD 请求将 chunk 置空，未发现任何调用者会对 HEAD/304 写入非空 body。缺少可定位的契约（文档/测试/语言规则）证明期望保留 Content-Length 语义，无法构造有效复现，故不适用。

[运行证据](evidence/5c773d539ff2/evidence.json)

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/http1connection.py:385`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
383:         lines = []
384:         if self.is_client:
385:             assert isinstance(start_line, httputil.RequestStartLine)
386:             self._request_start_line = start_line
387:             lines.append(utf8("%s %s HTTP/1.1" % (start_line[0], start_line[1])))
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/http1connection.py:399`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
397:             )
398:         else:
399:             assert isinstance(start_line, httputil.ResponseStartLine)
400:             assert self._request_start_line is not None
401:             assert self._request_headers is not None
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/http1connection.py:400`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
398:         else:
399:             assert isinstance(start_line, httputil.ResponseStartLine)
400:             assert self._request_start_line is not None
401:             assert self._request_headers is not None
402:             self._response_start_line = start_line
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/http1connection.py:401`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
399:             assert isinstance(start_line, httputil.ResponseStartLine)
400:             assert self._request_start_line is not None
401:             assert self._request_headers is not None
402:             self._response_start_line = start_line
403:             lines.append(utf8("HTTP/1.1 %d %s" % (start_line[1], start_line[2])))
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/http1connection.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 187, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
