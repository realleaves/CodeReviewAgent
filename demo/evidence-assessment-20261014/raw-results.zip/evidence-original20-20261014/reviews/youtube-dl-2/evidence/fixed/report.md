# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`84f085d4bdb66ee025fb337bcd571eab7469da97`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/801 个已索引 Python 文件
- 调用：11；耗时：26.718 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] segment_urls 与 SegmentTimeline 数量不匹配时 IndexError

- 位置：`youtube_dl/extractor/common.py:1973`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：在 'segment_urls' 与 's' 同时存在的分支中，代码按 SegmentTimeline 的 s 列表（含 r 重复次数）展开片段，并用递增的 segment_index 直接索引 representation_ms_info['segment_urls']。segment_urls 来自 SegmentList 的 SegmentURL 元素列表，其长度由清单决定，并不保证等于 s 展开后的片段总数。当 SegmentTimeline 声明的片段数多于 SegmentURL 元素数时，索引越界抛出 IndexError，导致整个 DASH 清单解析失败（异常向上传播，而非降级为警告）。
- 触发条件：构造 MPD：SegmentList 含 1 个 SegmentURL，但 SegmentTimeline 含 2 个 <S> 元素（或一个 r=1 的 S），使展开片段数为 2 > segment_urls 长度 1。
- 依据：1970-1978 行：for s in representation_ms_info['s']: ... for r in range(s.get('r', 0) + 1): segment_uri = representation_ms_info['segment_urls'][segment_index]。segment_urls 在 1815 行由 SegmentURL 元素列表构建，长度与 s 展开数无绑定关系。
- 修复建议：在索引前检查 segment_index < len(representation_ms_info['segment_urls'])，越界时 report_warning 并 break/跳过，或对缺失片段使用占位处理，避免抛 IndexError。
- 验证方式：测试必须有且仅有一个 ReproductionTest。

```python
1971:                                 duration = float_or_none(s['d'], timescale)
1972:                                 for r in range(s.get('r', 0) + 1):
1973:                                     segment_uri = representation_ms_info['segment_urls'][segment_index]
1974:                                     fragments.append({
1975:                                         location_key(segment_uri): segment_uri,
1976:                                         'duration': duration,
1977:                                     })
1978:                                     segment_index += 1
1979:                             representation_ms_info['fragments'] = fragments
1980:                         elif 'segment_urls' in representation_ms_info:
```

- 复现状态：invalid_plan
- 证据说明：测试必须有且仅有一个 ReproductionTest。

[运行证据](evidence/19280bb13146/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.extractor.common import InfoExtractor


class _DummyIE(InfoExtractor):
    IE_NAME = 'dummy'

    def _download_webpage_handle(self, *args, **kwargs):
        raise AssertionError('should not download')

    def report_warning(self, msg, video_id=None):
        pass


MPD = '''<?xml version="1.0" encoding="utf-8"?>
<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" mediaPresentationDuration="PT30S" type="static">
  <Period>
    <AdaptationSet mimeType="video/mp4">
      <Representation id="1" bandwidth="100000" width="640" height="360">
        <SegmentList timescale="1000" duration="5000">
          <SegmentTimeline>
            <S t="0" d="5000" r="1"/>
          </SegmentTimeline>
          <SegmentURL media="http://example.com/seg1.m4s"/>
        </SegmentList>
      </Representation>
    </AdaptationSet>
  </Period>
</MPD>'''


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        from youtube_dl.utils import compat_etree_fromstring
        ie = _DummyIE()
        doc = compat_etree_fromstring(MPD.encode('utf-8'))
        formats = ie._parse_mpd_formats(doc, mpd_id='test')
        self.assertTrue(formats)
        self.assertIn('fragments', formats[0])

```

### [低] segment_duration 为 0 时被当作缺失而丢弃 duration

- 位置：`youtube_dl/extractor/common.py:1985`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：在无 SegmentTimeline 的 SegmentList 分支中，segment_duration 经 float_or_none 计算后，用 `if segment_duration:` 判断是否写入 fragment['duration']。当 segment_duration 合法地为 0（例如 timescale 很大而 segment_duration 属性为 0，或计算结果为 0.0）时，该真值判断为假，duration 字段被省略，与预期“存在 segment_duration 即写入”的语义不符。
- 触发条件：MPD 的 SegmentList 含 segment_duration='0'（或使 float_or_none 结果为 0.0 的取值），且无 SegmentTimeline。
- 依据：1985-1993 行：segment_duration = float_or_none(...) if 'segment_duration' in representation_ms_info else None；随后 if segment_duration: fragment['duration'] = segment_duration。0 值被真值判断过滤。
- 修复建议：改用 `if segment_duration is not None:` 判断，以区分“缺失”与“值为 0”。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1983:                             # https://github.com/rg3/youtube-dl/pull/14844
1984:                             fragments = []
1985:                             segment_duration = float_or_none(
1986:                                 representation_ms_info['segment_duration'],
1987:                                 representation_ms_info['timescale']) if 'segment_duration' in representation_ms_info else None
1988:                             for segment_url in representation_ms_info['segment_urls']:
1989:                                 fragment = {
1990:                                     location_key(segment_url): segment_url,
1991:                                 }
1992:                                 if segment_duration:
1993:                                     fragment['duration'] = segment_duration
1994:                                 fragments.append(fragment)
1995:                             representation_ms_info['fragments'] = fragments
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 common.py:1992 的 `if segment_duration:` 会把合法的 0 值 duration 丢弃。但上游 common.py:1800-1802 在解析 SegmentList 的 duration 属性时已用 `if segment_duration:` 过滤：当 XML 属性 duration='0' 时，source.get('duration') 返回字符串 '0'，其真值为 True，因此 ms_info['segment_duration'] = float('0') = 0.0 会被写入。随后 1985 行 float_or_none(0.0, timescale) 返回 0.0，1992 行 `if segment_duration:` 为假，duration 被省略。因此该路径确实可达，候选描述在逻辑上成立。

然而要构造最小行为复现，需要调用 _parse_mpd_formats 并传入完整 MPD 文档，且该函数依赖 self._download_webpage_handle 等网络方法。在只读、无网络的测试环境中，无法在不复制待审实现、不修改源码的前提下构造有效输入并调用实际目标函数。同时，仓库中没有任何文档或既有测试约定“segment_duration 为 0 时必须写入 fragment['duration']”——DASH 规范中 SegmentList@duration 为 0 本身语义可疑（0 时长分段无意义），代码现有实现不能单独证明期望返回值。缺少可定位契约，故 applicable=false，不编造测试。

[运行证据](evidence/e2c5a7b28a00/evidence.json)

### [低] B007: Loop control variable `r` not used within loop body

- 位置：`youtube_dl/extractor/common.py:1972`
- 来源：ruff B007
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Loop control variable `r` not used within loop body
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B007: Loop control variable `r` not used within loop body
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1970:                             for s in representation_ms_info['s']:
1971:                                 duration = float_or_none(s['d'], timescale)
1972:                                 for r in range(s.get('r', 0) + 1):
1973:                                     segment_uri = representation_ms_info['segment_urls'][segment_index]
1974:                                     fragments.append({
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/extractor/common.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 58, "sensitive_file": 1, "benchmark_tests_hidden": 29}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
