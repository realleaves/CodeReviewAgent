import unittest

from youtube_dl.extractor.common import InfoExtractor


class _DummyIE(InfoExtractor):
    IE_NAME = 'dummy'

    def _download_webpage_handle(self, *args, **kwargs):
        raise AssertionError('should not download')

    def report_warning(self, msg, video_id=None):
        pass


MPD = '''<?xml version="1.0" encoding="utf-8"?>
<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" mediaPresentationDuration="PT30S" type="static">
  <Period>
    <AdaptationSet mimeType="video/mp4">
      <Representation id="1" bandwidth="100000" width="640" height="360">
        <SegmentList timescale="1000" duration="5000">
          <SegmentTimeline>
            <S t="0" d="5000" r="1"/>
          </SegmentTimeline>
          <SegmentURL media="http://example.com/seg1.m4s"/>
        </SegmentList>
      </Representation>
    </AdaptationSet>
  </Period>
</MPD>'''


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        from youtube_dl.utils import compat_etree_fromstring
        ie = _DummyIE()
        doc = compat_etree_fromstring(MPD.encode('utf-8'))
        formats = ie._parse_mpd_formats(doc, mpd_id='test')
        self.assertTrue(formats)
        self.assertIn('fragments', formats[0])
