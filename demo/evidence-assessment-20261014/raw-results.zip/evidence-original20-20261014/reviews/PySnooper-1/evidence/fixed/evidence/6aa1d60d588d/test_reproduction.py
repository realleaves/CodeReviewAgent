import unittest
import sys
import types

from pysnooper.tracer import get_source_from_frame, source_cache


class EmptySourceLoader:
    def get_source(self, module_name):
        return ''


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        module_name = 'pysnooper_empty_source_test_module'
        module = types.ModuleType(module_name)
        module.__loader__ = EmptySourceLoader()
        module.__name__ = module_name
        sys.modules[module_name] = module
        try:
            code = compile('x = 1\n', '<empty-source-test>', 'exec')
            frame = None
            def capture():
                nonlocal frame
                frame = sys._getframe(0)
            capture()
            frame.f_globals['__name__'] = module_name
            frame.f_globals['__loader__'] = EmptySourceLoader()
            frame.f_code = code
            source_cache.clear()
            result = get_source_from_frame(frame)
            self.assertIsNotNone(result)
        finally:
            sys.modules.pop(module_name, None)
            source_cache.clear()
