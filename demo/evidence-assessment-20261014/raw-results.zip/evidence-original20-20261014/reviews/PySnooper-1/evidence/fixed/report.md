# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`e21a31162f4c54be693d8ca8260e42393b39abd3`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/7 个已索引 Python 文件
- 调用：15；耗时：38.24 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] source 为空列表时 source[0] 抛 IndexError

- 位置：`pysnooper/tracer.py:88`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：get_source_from_frame 在 source 为 None 时用 UnavailableSource 兜底，但若 loader.get_source 返回空字符串或文件为空，source 会是空列表 []，此时 isinstance(source[0], bytes) 会抛出 IndexError，导致追踪初始化崩溃。预期应把空列表也视为不可用源。
- 触发条件：loader.get_source(module_name) 返回 ''（或读取到空文件），source = ''.splitlines() == []，随后执行 source[0]。
- 依据：第 62-63 行 source = source.splitlines() 可能得到 []；第 82-83 行仅当 source is None 才替换；第 88 行直接访问 source[0]。
- 修复建议：在访问 source[0] 前判断 if not source: source = UnavailableSource()，或使用 source[:1] 安全切片。
- 验证方式：测试必须有且仅有一个 ReproductionTest。

```python
86:     # apply tokenize.detect_encoding to decode the source into a
87:     # string, then we should do that ourselves.
88:     if isinstance(source[0], bytes):
89:         encoding = 'utf-8'
90:         for line in source[:2]:
```

- 复现状态：invalid_plan
- 证据说明：测试必须有且仅有一个 ReproductionTest。

[运行证据](evidence/6aa1d60d588d/evidence.json)

复现测试：

```python
import unittest
import sys
import types

from pysnooper.tracer import get_source_from_frame, source_cache


class EmptySourceLoader:
    def get_source(self, module_name):
        return ''


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        module_name = 'pysnooper_empty_source_test_module'
        module = types.ModuleType(module_name)
        module.__loader__ = EmptySourceLoader()
        module.__name__ = module_name
        sys.modules[module_name] = module
        try:
            code = compile('x = 1\n', '<empty-source-test>', 'exec')
            frame = None
            def capture():
                nonlocal frame
                frame = sys._getframe(0)
            capture()
            frame.f_globals['__name__'] = module_name
            frame.f_globals['__loader__'] = EmptySourceLoader()
            frame.f_code = code
            source_cache.clear()
            result = get_source_from_frame(frame)
            self.assertIsNotNone(result)
        finally:
            sys.modules.pop(module_name, None)
            source_cache.clear()

```

### [中] vars_order.index 对不在列表中的局部变量抛 ValueError

- 位置：`pysnooper/tracer.py:29`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：vars_order 由 co_varnames + co_cellvars + co_freevars + f_locals.keys() 组成，但排序 key 使用 vars_order.index(key_value[0])。若某个 f_locals 键不在 vars_order 中（例如通过 exec 注入或某些实现下 f_locals 含额外键），index 会抛 ValueError 导致 get_local_reprs 崩溃。
- 触发条件：frame.f_locals 中存在一个不在 co_varnames/co_cellvars/co_freevars 且不在 f_locals.keys() 快照中的键（例如排序期间 f_locals 变化），调用 get_local_reprs。
- 依据：第 26 行构造 vars_order；第 28 行 result_items 来自 frame.f_locals.items()；第 29 行使用 vars_order.index(...)。
- 修复建议：改用带默认值的查找，如 vars_order.index(k) if k in vars_order else len(vars_order)，或先构建 {name: i} 映射。
- 验证方式：测试必须有且仅有一个 ReproductionTest。

```python
27: 
28:     result_items = [(key, utils.get_shortish_repr(value)) for key, value in frame.f_locals.items()]
29:     result_items.sort(key=lambda key_value: vars_order.index(key_value[0]))
30:     result = collections.OrderedDict(result_items)
31: 
```

- 复现状态：invalid_plan
- 证据说明：测试必须有且仅有一个 ReproductionTest。

[运行证据](evidence/83c6f9c2aa26/evidence.json)

复现测试：

```python
import unittest

from pysnooper.tracer import get_local_reprs


class _FakeCode(object):
    co_varnames = ('a', 'b')
    co_cellvars = ()
    co_freevars = ()


class _InconsistentLocals(dict):
    """keys() 与 items() 返回不一致的映射，模拟 f_locals 在快照后变化。"""

    def keys(self):
        return ['a', 'b']

    def items(self):
        return [('a', 1), ('b', 2), ('injected', 42)]


class _FakeFrame(object):
    def __init__(self):
        self.f_code = _FakeCode()
        self.f_locals = _InconsistentLocals()


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        frame = _FakeFrame()
        result = get_local_reprs(frame)
        self.assertIn('injected', result)

```

### [中] F821: Undefined name `basestring`

- 位置：`pysnooper/pycompat.py:55`
- 来源：ruff F821
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Undefined name `basestring`
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff F821: Undefined name `basestring`
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
53:     text_type = str
54: else:
55:     string_types = (basestring,)
56:     text_type = unicode
```

### [中] F821: Undefined name `unicode`

- 位置：`pysnooper/pycompat.py:56`
- 来源：ruff F821
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Undefined name `unicode`
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff F821: Undefined name `unicode`
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
54: else:
55:     string_types = (basestring,)
56:     text_type = unicode
```

### [低] B110: Try, Except, Pass detected.

- 位置：`pysnooper/tracer.py:74`
- 来源：bandit B110
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Try, Except, Pass detected.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B110: Try, Except, Pass detected.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
72:                                   get_range(0, entry_number, entry_number + 1)
73:                 source = source_chunk.splitlines()
74:             except Exception:
75:                 pass
76:         else:
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`pysnooper/tracer.py:122`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
120:         write = output
121:     else:
122:         assert isinstance(output, utils.WritableStream)
123: 
124:         def write(s):
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| pysnooper/pycompat.py | completed | window_completed | 1/1 |
| pysnooper/tracer.py | completed | window_completed | 2/2 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 11, "benchmark_tests_hidden": 8}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
