import unittest

from pysnooper.tracer import get_local_reprs


class _FakeCode(object):
    co_varnames = ('a', 'b')
    co_cellvars = ()
    co_freevars = ()


class _InconsistentLocals(dict):
    """keys() 与 items() 返回不一致的映射，模拟 f_locals 在快照后变化。"""

    def keys(self):
        return ['a', 'b']

    def items(self):
        return [('a', 1), ('b', 2), ('injected', 42)]


class _FakeFrame(object):
    def __init__(self):
        self.f_code = _FakeCode()
        self.f_locals = _InconsistentLocals()


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        frame = _FakeFrame()
        result = get_local_reprs(frame)
        self.assertIn('injected', result)
