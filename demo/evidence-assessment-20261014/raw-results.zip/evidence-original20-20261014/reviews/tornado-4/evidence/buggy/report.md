# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`a8420fc681c5423d072978f00eab4d0645057d16`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/62 个已索引 Python 文件
- 调用：7；耗时：17.175 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] suffix range 长度超过文件大小时 start 变为负数导致 416 判定失效

- 位置：`tornado/web.py:2603`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：当 Range 头为后缀形式（如 bytes=-N）时，_parse_request_range 返回 (start=-N, end=None)。第 2603 行的不可满足判定只检查 start >= size 或 end == 0，对负 start 不成立，因此不会返回 416。随后第 2611-2612 行执行 start += size，若 N > size，start 仍为负数。第 2633-2634 行 content_length = size - start 会大于实际文件大小，第 2637 行据此设置 Content-Length，而 get_content 用 file.seek(负数) 会抛 OSError（Invalid argument），导致请求处理异常而非按 RFC 7233 返回 416 或截断到整个文件。
- 触发条件：请求一个大小为 size 的静态文件，携带 Range: bytes=-{N}，其中 N > size（例如文件 10 字节，Range: bytes=-100）。
- 依据：第 2603 行条件 `(start is not None and start >= size) or end == 0` 对负 start 为 False；第 2611-2612 行 `if start is not None and start < 0: start += size` 后 start 仍为负；第 2634 行 `content_length = size - start` 得到大于 size 的值；get_content 第 2801 行 `file.seek(start)` 传入负数。
- 修复建议：在后缀范围处理后将 start 夹紧到 0（如 start = max(0, start + size)），或在 start + size < 0 时返回 416。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
2601:         if request_range:
2602:             start, end = request_range
2603:             if (start is not None and start >= size) or end == 0:
2604:                 # As per RFC 2616 14.35.1, a range is not satisfiable only: if
2605:                 # the first requested byte is equal to or greater than the
```

- 复现状态：unrelated_failure
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/3e533c03160d/evidence.json)

复现测试：

```python
import os
import tempfile
import unittest

from tornado.web import StaticFileHandler


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # 构造一个 10 字节的临时文件
        fd, path = tempfile.mkstemp()
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(b"0123456789")
            size = os.path.getsize(path)
            self.assertEqual(size, 10)

            # 后缀范围 bytes=-100，N=100 > size=10
            # 按 RFC 7233，后缀长度超过文件大小时应返回整个文件（start 夹紧到 0），
            # 而不是产生负的 seek 偏移。
            start = -100
            end = None
            # 模拟 web.py 第 2603 行的不可满足判定
            not_satisfiable = (start is not None and start >= size) or end == 0
            self.assertFalse(not_satisfiable)
            # 模拟 web.py 第 2611-2612 行的修正
            if start is not None and start < 0:
                start += size
            # 修正后 start 仍为负，这是缺陷所在
            self.assertGreaterEqual(
                start,
                0,
                "suffix range 长度超过文件大小时 start 修正后仍为负: %r" % (start,),
            )

            # 若 start 为负，get_content 会执行 file.seek(负数) 抛 OSError
            with open(path, "rb") as f:
                with self.assertRaises(OSError):
                    f.seek(start)
        finally:
            os.unlink(path)

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `unrelated_failure`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 1, "errors": 0, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "failure", "exception_type": "AssertionError", "message": "-90 not greater than or equal to 0 : suffix range \u957f\u5ea6\u8d85\u8fc7\u6587\u4ef6\u5927\u5c0f\u65f6 start \u4fee\u6b63\u540e\u4ecd\u4e3a\u8d1f: -90", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 33, in test_reproduction\n    \"suffix range \u957f\u5ea6\u8d85\u8fc7\u6587\u4ef6\u5927\u5c0f\u65f6 start \u4fee\u6b63\u540e\u4ecd\u4e3a\u8d1f: %r\" % (start,),\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 1257, in assertGreaterEqual\n    self.fail(self._formatMessage(msg, standardMsg))\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 693, in fail\n    raise self.failureException(msg)\nAssertionError: -90 not greater than or equal to 0 : suffix range \u957f\u5ea6\u8d85\u8fc7\u6587\u4ef6\u5927\u5c0f\u65f6 start \u4fee\u6b63\u540e\u4ecd\u4e3a\u8d1f: -90\n"}], "target_lines": [58, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 105, 107, 109, 124, 125, 127, 133, 135, 138, 146, 154, 162, 171, 172, 175, 178, 183, 185, 187, 188, 189, 191, 194, 195, 196, 200, 201, 202, 203, 230, 233, 253, 254, 258, 261, 262, 263, 264, 265, 266, 267, 269, 285, 295, 314, 328, 338, 357, 361, 370, 378, 387, 389, 417, 418, 421, 423, 424, 427, 429, 430, 436, 437, 438, 451, 469, 470, 471, 487, 501, 502, 503, 519, 535, 536, 545, 546, 559, 579, 580, 585, 605, 606, 607, 653, 667, 688, 689, 690, 722, 723, 752, 753, 780, 781, 793, 811, 843, 918, 941, 953, 975, 983, 1009, 1032, 1053, 1105, 1164, 1179, 1184, 1222, 1247, 1248, 1268, 1269, 1272, 1282, 1306, 1307, 1342, 1343, 1346, 1353, 1361, 1369, 1370, 1430, 1457, 1458, 1492, 1531, 1550, 1586, 1594, 1598, 1611, 1622, 1663, 1664, 1723, 1730, 1739, 1746, 1770, 1771, 1772, 1773, 1796, 1807, 1810, 1829, 1856, 1863, 1864, 1892, 1893, 1918, 1927, 1929, 1934, 1945, 1946, 1957, 2039, 2045, 2046, 2047, 2097, 2120, 2136, 2139, 2154, 2170, 2171, 2177, 2178, 2198, 2199, 2214, 2229, 2255, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2277, 2278, 2279, 2285, 2292, 2300, 2306, 2341, 2362, 2365, 2366, 2374, 2385, 2408, 2410, 2413, 2420, 2422, 2429, 2430, 2432, 2435, 2438, 2445, 2476, 2478, 2482, 2493, 2558, 2560, 2562, 2563, 2565, 2569, 2570, 2574, 2577, 2652, 2667, 2692, 2714, 2715, 2731, 2781, 2783, 2784, 2820, 2821, 2838, 2844, 2858, 2878, 2899, 2904, 2905, 2918, 2920, 2921, 2950, 2963, 2964, 2980, 2981, 2996, 3011, 3014, 3015, 3018, 3024, 3030, 3032, 3037, 3038, 3039, 3040, 3041, 3044, 3048, 3057, 3061, 3063, 3064, 3065, 3066, 3067, 3068, 3069, 3075, 3081, 3083, 3086, 3091, 3092, 3093, 3094, 3095, 3126, 3140, 3141, 3176, 3184, 3186, 3192, 3193, 3196, 3200, 3205, 3213, 3218, 3226, 3232, 3238, 3243, 3244, 3248, 3249, 3253, 3267, 3269, 3275, 3290, 3293, 3296, 3305, 3308, 3317, 3320, 3324, 3325, 3328, 3329, 3333, 3336, 3349, 3350, 3407, 3410, 3439, 3440, 3465, 3466, 3467, 3468, 3469, 3470, 3499, 3520, 3521, 3522, 3523, 3524, 3525, 3555, 3568, 3575, 3581], "target_calls": [["<module>", 58], ["Application", 1957], ["ErrorHandler", 2429], ["FallbackHandler", 2996], ["Finish", 2385], ["GZipContentEncoding", 3048], ["HTTPError", 2341], ["MissingArgumentError", 2413], ["OutputTransform", 3024], ["RedirectHandler", 2445], ["RequestHandler", 178], ["StaticFileHandler", 2493], ["TemplateModule", 3253], ["UIModule", 3176], ["_ApplicationRouter", 1918], ["_ArgDefaultMarker", 171], ["_HandlerDelegate", 2255], ["_UIModuleNamespace", 3324], ["_linkify", 3243], ["_xsrf_form_html", 3248]]}

```

### [低] 后缀范围恰好覆盖整个文件时错误返回 206 而非 200

- 位置：`tornado/web.py:2621`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 2621 行用 `size != (end or size) - (start or 0)` 判断是否返回 206。对于后缀范围 bytes=-size（即请求整个文件），_parse_request_range 返回 (start=-size, end=None)，经第 2611-2612 行 start += size 后 start 变为 0，end 为 None。此时表达式为 size != (None or size) - (0 or 0) = size != size，结果为 False，因此不设置 206，返回 200，这是正确的。但若后缀范围经处理后 start 为 0 且 end 为 None 之外的情形，例如 bytes=0-（start=0,end=None）同样得到 200，符合注释意图。此条经推演未发现实际错误，故不报告。
- 触发条件：无（推演后未确认缺陷）
- 依据：第 2621 行表达式在 start=0,end=None 时求值为 False，行为正确。
- 修复建议：无需修改。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
2619:             # refuses to play audio if it gets an HTTP 206 in response to
2620:             # ``Range: bytes=0-``.
2621:             if size != (end or size) - (start or 0):
2622:                 self.set_status(206)  # Partial Content
2623:                 self.set_header(
```

- 复现状态：unsupported
- 证据说明：候选缺陷本身在推演后已被否定：对于后缀范围 bytes=-size（请求整个文件），_parse_request_range 返回 (start=-size, end=None)，经 start += size 后 start=0、end=None，第 2621 行表达式 size != (None or size) - (0 or 0) 求值为 size != size 即 False，因此不设置 206，返回 200，行为正确。候选描述也明确说明“经推演未发现实际错误，故不报告”。没有可复现的真实缺陷，无法构造会因真实 bug 而失败的测试。

[运行证据](evidence/81ca7a4a1965/evidence.json)

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/web.py:2650`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
2648:                     return
2649:         else:
2650:             assert self.request.method == "HEAD"
2651: 
2652:     def compute_etag(self) -> Optional[str]:
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/web.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 185, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
