# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`a8420fc681c5423d072978f00eab4d0645057d16`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/62 个已索引 Python 文件
- 调用：10；耗时：21.519 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] Range 请求 size 为 0 时 Content-Range 计算错误

- 位置：`tornado/web.py:2629`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：当文件大小为 0（size=0）且请求 Range 头时，_parse_request_range 对 "bytes=0-" 返回 (0, None)。此时 start=0, end=None。第 2607-2610 行的不可满足判断为：start is not None and (start >= size ...) 即 0 >= 0 为 True，因此会返回 416。但若 Range 为 "bytes=-0"，_parse_request_range 返回 (None, 0)，第 2610 行 end == 0 为 True，也返回 416。这些路径在 size=0 时被 416 拦截，看似安全。然而当 size=0 且 Range 为 "bytes=0-" 时 start=0>=size=0 成立，返回 416，符合预期。真正的问题在于第 2629 行：当 size != (end or size) - (start or 0) 时设置 206。考虑 size=0 且 request_range 为 (None, None)（即 "bytes="），此时 start=end=None，第 2607 行条件为 False（start is None），end==0 为 False，不返回 416。第 2629 行：size != (end or size) - (start or 0) => 0 != (0) - (0) => 0 != 0 为 False，不设 206，正确。但若 size=0 且 request_range=(0, None)（"bytes=0-"），已被 416 拦截。综合看，size=0 的边界大多被 416 覆盖，但 "bytes=" 空范围会落到第 2637-2645 行：start=end=None，content_length=size=0，设置 Content-Length: 0，然后 get_content 读取空文件，行为正确。因此该处未发现明确缺陷。
- 触发条件：Range: bytes= 且文件大小为 0
- 依据：第 2601-2635 行逻辑：request_range 为 (None, None) 时 start=end=None，跳过 416 检查，content_length=size=0。
- 修复建议：无需修改，行为符合 RFC。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
2627:             # refuses to play audio if it gets an HTTP 206 in response to
2628:             # ``Range: bytes=0-``.
2629:             if size != (end or size) - (start or 0):
2630:                 self.set_status(206)  # Partial Content
2631:                 self.set_header(
2632:                     "Content-Range", httputil._get_content_range(start, end, size)
2633:                 )
2634:         else:
2635:             start = end = None
```

- 复现状态：unsupported
- 证据说明：候选缺陷自身分析已得出“未发现明确缺陷”的结论，且经核对 tornado/web.py 第 2593-2645 行与 tornado/httputil.py 第 692-755 行，size=0 与 Range: bytes= 的组合路径（request_range=(None,None)）会跳过 416 检查，content_length=size=0，行为符合预期；而 bytes=0- 与 bytes=-0 在 size=0 时均被 416 拦截。没有可定位的契约（文档/测试/语言规则）表明该处存在错误返回值，因此无法构造会导致真实 bug 失败的最小复现测试。

[运行证据](evidence/ff56883f59a9/evidence.json)

### [中] suffix range 与 start 为 None 时 Content-Length 计算依赖 end

- 位置：`tornado/web.py:2637`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：当 Range 为 "bytes=-N"（suffix range）时，_parse_request_range 返回 (-N, None)。第 2603-2606 行将 start 转为 size-N（若为负则 0）。此时 end 仍为 None。第 2637 行 start is not None and end is not None 为 False；第 2639 行 end is not None 为 False；第 2641 行 start is not None 为 True，content_length = size - start。这正确。但考虑 Range 为 "bytes=-0"：_parse_request_range 返回 (None, 0)。第 2610 行 end == 0 为 True，返回 416，正确。考虑 Range 为 "bytes=5-3"（start>end）：_parse_request_range 返回 (5, 4)。第 2609 行 start >= end 即 5>=4 为 True，返回 416，正确。考虑 Range 为 "bytes=0-0"：返回 (0, 1)。第 2609 行 start>=size 若 size>0 为 False，start>=end 即 0>=1 为 False，不返回 416。第 2629 行 size != (1 or size) - (0 or 0) => size != 1 - 0 => size != 1。若 size>1，设 206，Content-Range 为 bytes 0-0/size，正确。若 size==1，size != 1 为 False，不设 206，返回 200 全量，符合注释中 Chrome 的要求。逻辑正确。
- 触发条件：Range: bytes=0-0 且文件大小为 1
- 依据：第 2629 行条件 size != (end or size) - (start or 0) 在 size=1, start=0, end=1 时为 1 != 1，为 False，不设 206。
- 修复建议：无需修改。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
2635:             start = end = None
2636: 
2637:         if start is not None and end is not None:
2638:             content_length = end - start
2639:         elif end is not None:
2640:             content_length = end
2641:         elif start is not None:
2642:             content_length = size - start
2643:         else:
2644:             content_length = size
2645:         self.set_header("Content-Length", content_length)
2646: 
2647:         if include_body:
```

- 复现状态：unsupported
- 证据说明：候选缺陷本身的分析结论是“逻辑正确、无需修改”，其标题描述的 Content-Length 计算在 suffix range（start 为 None、end 为 None）场景下按代码路径走 elif start is not None 分支得到 size-start，是正确的。候选未指出任何实际错误行为，也没有可定位的契约说明期望返回值与实现不符。因此不存在可复现的真实 bug，无法构造会让真实 bug 导致失败的测试。

[运行证据](evidence/fb073da41436/evidence.json)

### [低] get_content 返回 bytes 时被包装为单元素列表，但迭代器路径未处理

- 位置：`tornado/web.py:2648`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 2648 行 content = self.get_content(self.absolute_path, start, end)。get_content 是生成器函数（含 yield），因此始终返回生成器对象，不会是 bytes。第 2649 行 isinstance(content, bytes) 永远为 False，该分支为死代码。但这是防御性代码，不影响正确性。真正的问题是：若子类覆写 get_content 返回 bytes（文档说明允许返回 byte string 或 iterator），第 2649-2650 行会将其包装为 [content]，然后迭代写入，行为正确。因此无缺陷。
- 触发条件：子类覆写 get_content 返回 bytes
- 依据：第 2790-2792 行 get_content 定义为生成器（含 yield），默认实现返回生成器；第 2649 行 isinstance 检查为防御性子类覆写。
- 修复建议：无需修改。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
2646: 
2647:         if include_body:
2648:             content = self.get_content(self.absolute_path, start, end)
2649:             if isinstance(content, bytes):
2650:                 content = [content]
2651:             for chunk in content:
2652:                 try:
2653:                     self.write(chunk)
2654:                     await self.flush()
2655:                 except iostream.StreamClosedError:
2656:                     return
2657:         else:
2658:             assert self.request.method == "HEAD"
```

- 复现状态：unsupported
- 证据说明：候选缺陷在 explanation 中已自我否定（“因此无缺陷”）。经核查源码：get_content 默认实现为生成器函数（第2790-2826行含 yield），因此第2648行 content 恒为生成器对象，第2649行 isinstance(content, bytes) 对默认实现恒为 False，属防御性子类覆写分支。文档（第2801-2803行）明确允许子类返回 byte string 或 iterator，而第2649-2650行对 bytes 返回值的包装逻辑正确，迭代写入行为无误。因此不存在可复现的行为缺陷，无法构造真实 bug 导致失败的测试。

[运行证据](evidence/6499c25ee067/evidence.json)

### [低] include_body=False 时 assert 依赖 request.method 为 HEAD

- 位置：`tornado/web.py:2658`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 2658 行 assert self.request.method == "HEAD"。head() 方法（第 2574-2575 行）调用 get(path, include_body=False)，此时 request.method 应为 HEAD。但若子类或其他调用者直接以 include_body=False 调用 get 而 method 不是 HEAD，assert 会触发。在 -O 优化下 assert 被移除，不会报错，但也不会写入 body，导致响应缺少内容。这属于契约依赖，非明确缺陷。
- 触发条件：非 HEAD 请求调用 get(path, include_body=False)
- 依据：第 2574-2575 行 head() 调用 get(include_body=False)；第 2658 行 assert 检查 method。
- 修复建议：可考虑改为显式条件或文档说明。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
2656:                     return
2657:         else:
2658:             assert self.request.method == "HEAD"
2659: 
2660:     def compute_etag(self) -> Optional[str]:
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/web.py:2658`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
2656:                     return
2657:         else:
2658:             assert self.request.method == "HEAD"
2659: 
2660:     def compute_etag(self) -> Optional[str]:
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/web.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 185, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
