# GitHub 仓库代码审查报告

- 仓库：https://github.com/cool-RR/PySnooper
- 分支：blinded-snapshot
- Commit：`e21a31162f4c54be693d8ca8260e42393b39abd3`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/7 个已索引 Python 文件
- 调用：23；耗时：54.464 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] 空源文件导致 IndexError

- 位置：`pysnooper/tracer.py:86`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：get_source_from_frame 在 source 为 None 时用 UnavailableSource 兜底，但若文件存在且为空（或 loader 返回空字符串），source 会是空列表 []，此时 source[0] 触发 IndexError。空文件是合法输入，预期应正常返回空源或兜底对象。
- 触发条件：对空文件（0 字节）中的代码调用 snoop，或 loader.get_source 返回空字符串。
- 依据：第 76-77 行 open(file_name,'rb').read().splitlines() 对空文件返回 []；第 80 行仅判断 source is None，未判断空列表；第 86 行 isinstance(source[0], bytes) 直接索引。
- 修复建议：在索引前判断 if source and isinstance(source[0], bytes)，或在 source 为空时替换为 UnavailableSource。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
84:     # apply tokenize.detect_encoding to decode the source into a
85:     # string, then we should do that ourselves.
86:     if isinstance(source[0], bytes):
87:         encoding = 'ascii'
88:         for line in source[:2]:
```

- 复现状态：unsupported
- 证据说明：静态分析确认 get_source_from_frame 在文件存在但为空（0 字节）时，open(...).read().splitlines() 返回空列表 []，随后第 86 行 source[0] 会触发 IndexError，这是可静态确认的索引越界缺陷。但无法在标准库 unittest 中构造一个 co_filename 指向临时空文件的有效 frame 对象：frame.f_code 是只读属性，无法替换；而通过 exec 编译空文件得到的 code 对象在空文件下不会产生可执行帧。因此无法在不修改待审源码或安装依赖的前提下构造有效输入来触发该路径，按规则标记 applicable=false，不编造测试。

[运行证据](evidence/a82a2771e3c4/evidence.json)

### [中] f_locals 键不在 vars_order 中导致 ValueError

- 位置：`pysnooper/tracer.py:24`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：vars_order 由 co_varnames+co_cellvars+co_freevars+当前 f_locals.keys() 组成，但 result_items 来自 frame.f_locals.items()。若在排序前 f_locals 发生变化（例如 watch 求值或其它副作用修改了局部变量），某个键可能不在 vars_order 中，list.index 抛 ValueError。
- 触发条件：frame.f_locals 的键集合与构造 vars_order 时不一致（如动态注入局部变量）。
- 依据：第 24 行 vars_order 基于某一时刻的 f_locals.keys()；第 26 行重新遍历 frame.f_locals.items()；第 27 行 vars_order.index(key_value[0]) 对缺失键抛 ValueError。
- 修复建议：使用 dict 映射键到索引，或对缺失键提供默认排序值。
- 验证方式：测试不支持运行时内部属性访问。

```python
22: def get_local_reprs(frame, watch=()):
23:     code = frame.f_code
24:     vars_order = code.co_varnames + code.co_cellvars + code.co_freevars + tuple(frame.f_locals.keys())
25: 
26:     result_items = [(key, utils.get_shortish_repr(value)) for key, value in frame.f_locals.items()]
27:     result_items.sort(key=lambda key_value: vars_order.index(key_value[0]))
28:     result = collections.OrderedDict(result_items)
29: 
```

- 复现状态：invalid_plan
- 证据说明：测试不支持运行时内部属性访问。

[运行证据](evidence/5ac7784966b8/evidence.json)

复现测试：

```python
import unittest

from pysnooper.tracer import get_local_reprs


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        class DynamicLocals(dict):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self._keys_called = False

            def keys(self):
                if not self._keys_called:
                    self._keys_called = True
                    return ['a']
                return super().keys()

        class FakeCode(object):
            co_varnames = ('a',)
            co_cellvars = ()
            co_freevars = ()

        class FakeFrame(object):
            def __init__(self):
                self.f_code = FakeCode()
                self.f_globals = {}
                self.f_locals = DynamicLocals(a=1, injected=2)

        frame = FakeFrame()
        result = get_local_reprs(frame)
        self.assertIn('a', result)
        self.assertIn('injected', result)

```

### [中] __exit__ 中 original_trace_functions 可能不存在

- 位置：`pysnooper/tracer.py:254`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：__exit__ 直接访问 self.thread_local.original_trace_functions 并 pop。若 __enter__ 未成功执行（例如 __enter__ 在 append 之前抛异常，或 __exit__ 被独立调用），该属性不存在会抛 AttributeError，掩盖原始异常。
- 触发条件：with 块中 __enter__ 抛异常后 __exit__ 仍被调用，或手动调用 __exit__。
- 依据：第250行在 __enter__ 中 setdefault 创建列表，第255行 __exit__ 直接访问 self.thread_local.original_trace_functions。
- 修复建议：使用 getattr 并检查栈是否为空，或在 __exit__ 中做防御性处理。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
252:         sys.settrace(self.trace)
253: 
254:     def __exit__(self, exc_type, exc_value, exc_traceback):
255:         stack = self.thread_local.original_trace_functions
256:         sys.settrace(stack.pop())
257:         calling_frame = inspect.currentframe().f_back
258:         self.target_frames.discard(calling_frame)
259:         self.frame_to_local_reprs.pop(calling_frame, None)
260: 
261:     def _is_internal_frame(self, frame):
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 __exit__ 在 __enter__ 未成功执行时会因 self.thread_local.original_trace_functions 不存在而抛 AttributeError。但 Python 语言规则保证：with 语句中只有当 __enter__ 正常返回后才会调用 __exit__；若 __enter__ 抛异常，__exit__ 不会被调用。因此“__enter__ 抛异常后 __exit__ 仍被调用”这一触发场景在语言层面不可能发生。唯一剩余场景是用户手动独立调用 __exit__，但这属于对上下文管理器协议的误用，且仓库文档/测试中没有任何契约要求 __exit__ 在未配对 __enter__ 时安全返回。缺少可定位的契约（文档、测试或语言规则）来证明期望行为，无法构造有效的复现测试，故标记为不适用。

[运行证据](evidence/ae2707b460f0/evidence.json)

### [低] depth 检查循环中 f_back 为 None 时提前返回

- 位置：`pysnooper/tracer.py:279`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：在 depth>1 的帧匹配循环中，若 _frame_candidate.f_back 为 None 则 return None，但此时可能已经遍历到顶层帧，逻辑上应视为未匹配而返回 None，行为正确；然而 for-else 的 else 分支在循环正常结束（未 break）时执行 return None，与 f_back 为 None 的 return None 重复但语义一致，不构成缺陷。此条为低置信度，仅记录潜在边界。
- 触发条件：depth>1 且调用栈深度不足。
- 依据：第289-296行循环与 for-else。
- 修复建议：无需修改，或补充注释说明。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
277:         # number of levels deeper.
278: 
279:         if not (frame.f_code in self.target_codes or frame in self.target_frames):
280:             if self.depth == 1:
281:                 # We did the most common and quickest check above, because the
282:                 # trace function runs so incredibly often, therefore it's
283:                 # crucial to hyper-optimize it for the common case.
284:                 return None
285:             elif self._is_internal_frame(frame):
286:                 return None
287:             else:
288:                 _frame_candidate = frame
289:                 for i in range(1, self.depth):
290:                     _frame_candidate = _frame_candidate.f_back
291:                     if _frame_candidate is None:
292:                         return None
293:                     elif _frame_candidate.f_code in self.target_codes or _frame_candidate in self.target_frames:
294:                         break
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [中] get_source_from_frame 返回 UnavailableSource 时按行号索引会返回占位字符串而非报错，但源码行号越界会 IndexError

- 位置：`pysnooper/tracer.py:328`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：get_source_from_frame 在无法读取源码时返回 UnavailableSource 实例，其 __getitem__ 对任意索引都返回 'SOURCE IS UNAVAILABLE'，因此第 328 行 source_line = get_source_from_frame(frame)[line_no - 1] 在源码不可用时不会崩溃。但当源码可读且 frame.f_lineno 超出源码行数（例如 exec/compile 生成的代码、或源码文件在运行中被修改/截断）时，普通 list 会抛出 IndexError，导致 trace 函数异常。
- 触发条件：对通过 compile()/exec() 定义且 co_filename 指向一个真实存在但行数不足的文件，或运行中源码文件被截断的函数进行 trace，frame.f_lineno 大于源码行数。
- 依据：第 328 行直接以 line_no - 1 索引 get_source_from_frame(frame) 的返回值；get_source_from_frame 在成功读取文件时返回 list（第 76-77、95-96 行），list 越界会抛 IndexError，而 trace 中未捕获。
- 修复建议：对源码行索引做边界保护，例如使用 try/except IndexError 或先检查 line_no 是否在范围内，越界时回退到占位字符串。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
326:         now_string = datetime_module.datetime.now().time().isoformat()
327:         line_no = frame.f_lineno
328:         source_line = get_source_from_frame(frame)[line_no - 1]
329:         thread_info = ""
330:         if self.thread_info:
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [中] frame.f_lasti 可能越界或指向无效位置导致 co_code 索引错误

- 位置：`pysnooper/tracer.py:361`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 361 行 code_byte = frame.f_code.co_code[frame.f_lasti] 直接以 f_lasti 索引字节码。在 'return' 事件中 f_lasti 通常有效，但在某些边界情况（如生成器/协程挂起、或 f_lasti 为 -1 或超出 co_code 长度）会抛 IndexError。此外第 362-363 行对非 int 做 ord() 处理，但 Python 3 中 co_code 索引已是 int，该分支为兼容 Python 2 遗留。
- 触发条件：在 f_lasti 为 -1 或超出 co_code 长度的帧上触发 trace（例如某些异常/挂起路径）。
- 依据：第 361 行无边界检查地索引 co_code；第 364-369 行随后用 opcode.opname[code_byte] 索引，若 code_byte 越界还会引发 IndexError。
- 修复建议：在索引前检查 0 <= frame.f_lasti < len(frame.f_code.co_code)，越界时跳过 ended_by_exception 判定或安全回退。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
359:         # with arg = None. This seems to be the only way to tell the difference
360:         # https://stackoverflow.com/a/12800909/2482744
361:         code_byte = frame.f_code.co_code[frame.f_lasti]
362:         if not isinstance(code_byte, int):
363:             code_byte = ord(code_byte)
364:         ended_by_exception = (
365:                 event == 'return'
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] exception 事件中 arg 可能为 None 导致 arg[:2] 抛 TypeError

- 位置：`pysnooper/tracer.py:388`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 388 行 exception = '\n'.join(traceback.format_exception_only(*arg[:2])) 假设 exception 事件的 arg 是 (type, value, tb) 三元组。按 CPython 契约 exception 事件的 arg 确实是该三元组，但若 trace 被非标准调用方或某些实现以 arg=None 触发，则 arg[:2] 会抛 TypeError。
- 触发条件：exception 事件以 arg=None 或非序列触发 trace。
- 依据：第 387-388 行未对 arg 做 None/类型检查即切片。
- 修复建议：在切片前检查 arg 是否为长度至少为 2 的序列，否则回退到通用异常描述。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
386: 
387:         if event == 'exception':
388:             exception = '\n'.join(traceback.format_exception_only(*arg[:2])).strip()
389:             exception = utils.truncate(exception, utils.MAX_EXCEPTION_LENGTH)
390:             self.write('{indent}{exception}'.
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] return 事件中 frame_to_local_reprs 删除与 depth 递减可能不匹配

- 位置：`pysnooper/tracer.py:379`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 379 行 del self.frame_to_local_reprs[frame] 假设该 frame 一定在字典中。若同一 frame 的 return 事件被处理两次，或 frame 从未被记录（例如 trace 在 call 之前被外部重新设置），del 会抛 KeyError。第 380 行 thread_global.depth -= 1 也可能使 depth 变为负值，导致后续缩进计算异常。
- 触发条件：对同一 frame 重复收到 return 事件，或 trace 在未收到对应 call 事件的情况下收到 return 事件。
- 依据：第 379 行使用 del 而非 pop；第 380 行无下界保护地递减 thread_global.depth。
- 修复建议：使用 self.frame_to_local_reprs.pop(frame, None)，并对 depth 递减做下界保护。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
377: 
378:         if event == 'return':
379:             del self.frame_to_local_reprs[frame]
380:             thread_global.depth -= 1
381: 
382:             if not ended_by_exception:
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] B007: Loop control variable `i` not used within loop body

- 位置：`pysnooper/tracer.py:289`
- 来源：ruff B007
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Loop control variable `i` not used within loop body
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B007: Loop control variable `i` not used within loop body
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
287:             else:
288:                 _frame_candidate = frame
289:                 for i in range(1, self.depth):
290:                     _frame_candidate = _frame_candidate.f_back
291:                     if _frame_candidate is None:
```

### [低] B110: Try, Except, Pass detected.

- 位置：`pysnooper/tracer.py:72`
- 来源：bandit B110
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Try, Except, Pass detected.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B110: Try, Except, Pass detected.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
70:                                   get_range(0, entry_number, entry_number + 1)
71:                 source = source_chunk.splitlines()
72:             except Exception:
73:                 pass
74:         else:
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`pysnooper/tracer.py:120`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
118:         write = output
119:     else:
120:         assert isinstance(output, utils.WritableStream)
121: 
122:         def write(s):
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`pysnooper/tracer.py:204`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
202:         self.thread_info = thread_info
203:         self.thread_info_padding = 0
204:         assert self.depth >= 1
205:         self.target_codes = set()
206:         self.target_frames = set()
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| pysnooper/tracer.py | completed | window_completed | 5/5 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 11, "benchmark_tests_hidden": 7}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
