import unittest

from pysnooper.tracer import get_local_reprs


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        class DynamicLocals(dict):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self._keys_called = False

            def keys(self):
                if not self._keys_called:
                    self._keys_called = True
                    return ['a']
                return super().keys()

        class FakeCode(object):
            co_varnames = ('a',)
            co_cellvars = ()
            co_freevars = ()

        class FakeFrame(object):
            def __init__(self):
                self.f_code = FakeCode()
                self.f_globals = {}
                self.f_locals = DynamicLocals(a=1, injected=2)

        frame = FakeFrame()
        result = get_local_reprs(frame)
        self.assertIn('a', result)
        self.assertIn('injected', result)
