import os
import tempfile
import unittest

from pysnooper.tracer import get_source_from_frame, source_cache


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        fd, path = tempfile.mkstemp(suffix='.py')
        os.close(fd)
        try:
            code = compile('pass', path, 'exec')
            frame = type('FakeFrame', (), {})()
            frame.f_globals = {'__name__': 'empty_module_for_test'}
            frame.f_code = code

            source_cache.clear()

            result = get_source_from_frame(frame)
            self.assertIsNotNone(result[0])
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
            source_cache.clear()
