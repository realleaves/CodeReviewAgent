# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`e21a31162f4c54be693d8ca8260e42393b39abd3`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/7 个已索引 Python 文件
- 调用：24；耗时：51.641 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] 空源文件导致 IndexError 崩溃

- 位置：`pysnooper/tracer.py:89`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：get_source_from_frame 在 source 为 None 时用 UnavailableSource 兜底，但若文件存在且为空（或 loader 返回空字符串），source 会是空列表 []，此时 source[0] 触发 IndexError。该异常未被捕获，会从 trace 回调中抛出，破坏被装饰函数的执行。
- 触发条件：被 snoop 的函数所在源文件为空（0 字节），或 loader.get_source 返回空字符串。
- 依据：第 79-80 行 open(file_name,'rb').read().splitlines() 对空文件返回 []；第 83 行 `if source is None` 不覆盖空列表；第 89 行 `isinstance(source[0], bytes)` 对空列表抛 IndexError。
- 修复建议：在判断前检查 `if not source:` 并回退到 UnavailableSource，或将第 89 行改为 `if source and isinstance(source[0], bytes):`。
- 验证方式：测试包含不支持的执行或无条件失败操作。

```python
87:     # apply tokenize.detect_encoding to decode the source into a
88:     # string, then we should do that ourselves.
89:     if isinstance(source[0], bytes):
90:         encoding = 'utf-8'
91:         for line in source[:2]:
```

- 复现状态：invalid_plan
- 证据说明：测试包含不支持的执行或无条件失败操作。

[运行证据](evidence/0e36e7cab0bb/evidence.json)

复现测试：

```python
import os
import tempfile
import unittest

from pysnooper.tracer import get_source_from_frame, source_cache


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        fd, path = tempfile.mkstemp(suffix='.py')
        os.close(fd)
        try:
            code = compile('pass', path, 'exec')
            frame = type('FakeFrame', (), {})()
            frame.f_globals = {'__name__': 'empty_module_for_test'}
            frame.f_code = code

            source_cache.clear()

            result = get_source_from_frame(frame)
            self.assertIsNotNone(result[0])
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
            source_cache.clear()

```

### [中] __exit__ 在未成功进入时访问 original_trace_functions 抛 AttributeError

- 位置：`pysnooper/tracer.py:276`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：__enter__ 在 DISABLED 时直接 return，不创建 thread_local.original_trace_functions；__exit__ 同样在 DISABLED 时 return，看似对称。但若 __enter__ 因其它原因未执行到 setdefault（例如调用栈异常），或 thread_local 属性被清理，__exit__ 中 stack = self.thread_local.original_trace_functions 会抛 AttributeError。更关键的是 __enter__ 与 __exit__ 的 DISABLED 分支依赖全局 DISABLED 在两次调用间不变，若运行期 DISABLED 变化会导致 pop 空栈或属性缺失。
- 触发条件：在 with 块执行期间修改 os.environ 或 DISABLED 相关状态，或 __enter__ 未走到 setdefault 而 __exit__ 被调用。
- 依据：第 260-261 行 __enter__ 在 DISABLED 时 return；第 274-277 行 __exit__ 在 DISABLED 时 return，否则访问 self.thread_local.original_trace_functions 并 pop。
- 修复建议：在 __exit__ 中使用 getattr 并检查栈非空，或在 __enter__ 中无条件初始化栈结构以保证对称。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
274:         if DISABLED:
275:             return
276:         stack = self.thread_local.original_trace_functions
277:         sys.settrace(stack.pop())
278:         calling_frame = inspect.currentframe().f_back
279:         self.target_frames.discard(calling_frame)
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 __exit__ 在未成功进入时访问 self.thread_local.original_trace_functions 会抛 AttributeError，但触发条件依赖运行期修改全局 DISABLED 或 __enter__ 异常中断，这些均非正常使用路径。DISABLED 是模块导入时由环境变量计算一次的常量（第143行），__enter__ 与 __exit__ 的 DISABLED 分支天然对称；在正常 with 语句中 __enter__ 必然先执行到 setdefault（第267-269行）创建栈，__exit__ 才能访问。候选未提供任何可定位的契约（文档/测试/语言规则）要求 __exit__ 在未进入时安全返回，且 Python 语言规则并不保证 __exit__ 在 __enter__ 未完成时被调用。无法构造符合契约的有效输入来复现，故不适用。

[运行证据](evidence/1ad3ca57a680/evidence.json)

### [中] thread_global.depth 在 'return' 事件时未递减，导致缩进持续增长

- 位置：`pysnooper/tracer.py:318`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：depth 只在 event == 'call' 时递增（第319-320行），但没有任何地方在函数返回（'return' 事件）时递减。thread_global 是 threading.local()，其 depth 在首次访问时被 setdefault 为 -1，之后随每次 call 单调递增。因此同一线程内每进入一个被追踪的调用，缩进就永久增加 4 个空格，后续所有输出（包括同级调用）的缩进都会越来越深，无法反映真实的调用层级。
- 触发条件：在同一线程中连续调用被 @pysnooper.snoop 装饰的函数（或递归调用），观察输出缩进。
- 依据：第318行 `thread_global.__dict__.setdefault('depth', -1)`；第319-320行仅在 `event == 'call'` 时 `thread_global.depth += 1`；第321行 `indent = ' ' * 4 * thread_global.depth`。整个 trace 方法（291-360+）中不存在对 depth 的递减操作。
- 修复建议：在 event == 'return' 时对 thread_global.depth 做递减（例如 `elif event == 'return': thread_global.depth -= 1`），使缩进随调用栈正确回退。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
316:                     return None
317: 
318:         thread_global.__dict__.setdefault('depth', -1)
319:         if event == 'call':
320:             thread_global.depth += 1
321:         indent = ' ' * 4 * thread_global.depth
322: 
323:         #                                                                     #
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 trace 方法中不存在对 thread_global.depth 的递减操作，导致缩进单调增长。但实际代码第398-400行在 event == 'return' 时执行了 `thread_global.depth -= 1`，正是候选建议的修复。因此该缺陷描述与源码不符，属于误报，无需构造复现测试。

[运行证据](evidence/331c905fb5e2/evidence.json)

### [中] get_source_from_frame 返回空列表时索引 [line_no-1] 抛 IndexError

- 位置：`pysnooper/tracer.py:348`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：get_source_from_frame 在源码不可用时返回 UnavailableSource（其 __getitem__ 永远返回占位字符串，不会抛 IndexError），但当 loader.get_source 返回空字符串或文件为空时，source 会是空列表 []（第64行 source.splitlines() 或第80行 read().splitlines()）。此时第348行 source_line = get_source_from_frame(frame)[line_no - 1] 会抛出 IndexError，导致 trace 函数异常，进而破坏被装饰函数的执行。
- 触发条件：被装饰函数所在模块的 loader.get_source 返回空字符串（例如空模块文件），或文件为空；执行到 trace 时 line_no>=1，访问空列表索引。
- 依据：第64行 source = source.splitlines() 对空字符串得到 []；第80行 fp.read().splitlines() 对空文件得到 []；第83行仅在 source is None 时才替换为 UnavailableSource，空列表不会被替换；第348行直接对结果做 [line_no-1] 索引。
- 修复建议：在 get_source_from_frame 中把空列表也视为不可用（如 if not source: source = UnavailableSource()），或在第348行对索引做边界保护。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
346:         now_string = datetime_module.datetime.now().time().isoformat()
347:         line_no = frame.f_lineno
348:         source_line = get_source_from_frame(frame)[line_no - 1]
349:         thread_info = ""
350:         if self.thread_info:
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [中] f_lasti 可能越界或指向无效字节导致 co_code 索引错误

- 位置：`pysnooper/tracer.py:381`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第381行 code_byte = frame.f_code.co_code[frame.f_lasti] 直接用 f_lasti 索引字节码。在 'call' 事件时 f_lasti 通常为 -1（尚未执行任何指令），Python 中 co_code[-1] 会取最后一个字节而非报错，但语义上并非当前指令；在某些事件/帧状态下 f_lasti 可能等于或超过 co_code 长度，导致 IndexError。该值随后用于 opcode.opname[code_byte] 判断是否由异常结束。
- 触发条件：trace 在 'call' 事件被调用时 f_lasti == -1，或 f_lasti 超出 co_code 范围时，索引得到错误字节或抛 IndexError。
- 依据：第381行无边界检查地使用 frame.f_lasti 索引 co_code；第387行用该字节查 opcode.opname。
- 修复建议：对 f_lasti 做范围检查（如 0 <= f_lasti < len(co_code)），否则跳过 ended_by_exception 判定。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
379:         # with arg = None. This seems to be the only way to tell the difference
380:         # https://stackoverflow.com/a/12800909/2482744
381:         code_byte = frame.f_code.co_code[frame.f_lasti]
382:         if not isinstance(code_byte, int):
383:             code_byte = ord(code_byte)
384:         ended_by_exception = (
385:                 event == 'return'
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] return 事件删除 frame_to_local_reprs 与 depth 递减可能不匹配

- 位置：`pysnooper/tracer.py:399`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第398-400行在 'return' 事件时执行 del self.frame_to_local_reprs[frame] 和 thread_global.depth -= 1。若同一帧的 'return' 事件被处理两次（例如生成器/协程或异常路径下重复触发），del 会抛 KeyError；且 depth 递减与 'call' 递增（第319-320行）依赖事件配对，若 'call' 未经过（如帧在 trace 安装前已存在），depth 会变为负值，导致缩进为负（' ' * 负数 得到空串）并影响后续缩进。
- 触发条件：帧的 'return' 事件在 frame_to_local_reprs 中不存在对应条目时（例如该帧的 'call' 未被记录），del 抛 KeyError；或 'return' 多于 'call' 时 depth 变为负数。
- 依据：第399行 del self.frame_to_local_reprs[frame] 无存在性检查；第400行 thread_global.depth -= 1 无下界保护；第321行 indent = ' ' * 4 * thread_global.depth 对负 depth 产生空缩进。
- 修复建议：使用 pop(frame, None) 替代 del，并对 depth 递减做下界保护或改为基于帧栈的计数。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
397: 
398:         if event == 'return':
399:             del self.frame_to_local_reprs[frame]
400:             thread_global.depth -= 1
401: 
402:             if not ended_by_exception:
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] B007: Loop control variable `i` not used within loop body

- 位置：`pysnooper/tracer.py:309`
- 来源：ruff B007
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Loop control variable `i` not used within loop body
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B007: Loop control variable `i` not used within loop body
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
307:             else:
308:                 _frame_candidate = frame
309:                 for i in range(1, self.depth):
310:                     _frame_candidate = _frame_candidate.f_back
311:                     if _frame_candidate is None:
```

### [低] B110: Try, Except, Pass detected.

- 位置：`pysnooper/tracer.py:75`
- 来源：bandit B110
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Try, Except, Pass detected.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B110: Try, Except, Pass detected.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
73:                                   get_range(0, entry_number, entry_number + 1)
74:                 source = source_chunk.splitlines()
75:             except Exception:
76:                 pass
77:         else:
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`pysnooper/tracer.py:123`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
121:         write = output
122:     else:
123:         assert isinstance(output, utils.WritableStream)
124: 
125:         def write(s):
```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`pysnooper/tracer.py:213`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
211:         self.thread_info = thread_info
212:         self.thread_info_padding = 0
213:         assert self.depth >= 1
214:         self.target_codes = set()
215:         self.target_frames = set()
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| pysnooper/tracer.py | completed | window_completed | 5/5 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 11, "benchmark_tests_hidden": 7}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
