import unittest
import json
from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        src = '{"a": "x\\ty"}'
        out = js_to_json(src)
        parsed = json.loads(out)
        self.assertEqual(parsed, {"a": "x\ty"})
