import unittest
import json
from youtube_dl.utils import strip_jsonp


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        code = 'cb({"a": ")"});'
        result = strip_jsonp(code)
        # 剥离回调后应得到合法 JSON 体
        parsed = json.loads(result)
        self.assertEqual(parsed, {"a": ")"})
