import json
import unittest

from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # JS 源码: {'a': 'x\\y'} 其中 \\ 是两个反斜杠字符，表示单个反斜杠
        js = "{'a': 'x\\\\y'}"
        result = js_to_json(js)
        parsed = json.loads(result)
        self.assertEqual(parsed['a'], 'x\\y')
