import unittest
import json
from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # JS 源码: "a\\'b" 表示 a、反斜杠、单引号、b
        src = '"a\\\\\'b"'
        out = js_to_json(src)
        # 输出应为合法 JSON，且解析后字符串为 a\'b（反斜杠+单引号）
        parsed = json.loads(out)
        self.assertEqual(parsed, "a\\'b")
