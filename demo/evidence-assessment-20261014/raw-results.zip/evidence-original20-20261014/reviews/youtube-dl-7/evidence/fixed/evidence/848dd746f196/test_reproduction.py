import unittest
from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # 点号是 JS 属性访问运算符，不是标识符字符。
        # 标识符正则不应把 b.c 整体匹配并加引号为 "b.c"。
        result = js_to_json('{a: b.c}')
        self.assertNotIn('"b.c"', result)
