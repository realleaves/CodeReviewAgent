# GitHub 仓库代码审查报告

- 仓库：https://github.com/ytdl-org/youtube-dl
- 分支：blinded-snapshot
- Commit：`cf2ac6df6896dac4d23918867bb86fac1e1088d9`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/563 个已索引 Python 文件
- 调用：15；耗时：49.802 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（3）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

### [中] 逗号分隔时 current_selector 为 None 会被追加进 selectors

- 位置：`youtube_dl/YoutubeDL.py:955`
- 来源：llm
- 复核：已复现 — 运行证据显示测试确实调用了原目标代码 build_format_selector，输入 ',best' 与 'best,,worst' 触发 _parse_format_selection 第955-957行无条件 append(None)，随后 _build_selector_function 第994行访问 None.type 抛出 AttributeError，与候选描述一致。期望行为有语言规则支持：解析阶段遇到非法逗号应抛出 SyntaxError（代码中已有 syntax_error 机制），而非把 None 传入构建阶段导致 AttributeError。测试断言 SyntaxError 合理，未假设未约定语义，也未复制实现。证据充分，接受。
- 问题：在 _parse_format_selection 中，遇到 ',' 时无条件执行 selectors.append(current_selector)。若输入以逗号开头或出现连续逗号（如 '-f ,best' 或 '-f best,,worst'），此时 current_selector 仍为 None，None 会被追加到 selectors 列表。后续 _build_selector_function 对 selectors 列表逐项调用 _build_selector_function(s)，而该函数对 None 会走到 isinstance(selector, list) 为 False、selector.type 访问 None.type，抛出 AttributeError，而非给出可读的语法错误。
- 触发条件：format_spec 为 ',best' 或 'best,,worst' 等含前导/连续逗号的字符串，调用 build_format_selector 后执行返回的 selector_function。
- 依据：第 955-957 行：elif string == ',': selectors.append(current_selector); current_selector = None。此处未校验 current_selector 是否为 None。第 985-987 行 _build_selector_function 对列表元素递归，None 元素会在 selector.type 处崩溃。
- 修复建议：在追加前判断 current_selector 是否为 None，若为 None 则 raise syntax_error('Unexpected ","', start)，避免把 None 传入后续构建逻辑。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
953:                         tokens.restore_last_token()
954:                         break
955:                     elif string == ',':
956:                         selectors.append(current_selector)
957:                         current_selector = None
958:                     elif string == '/':
959:                         first_choice = current_selector
```

- 复现状态：reproduced
- 证据说明：运行证据显示测试确实调用了原目标代码 build_format_selector，输入 ',best' 与 'best,,worst' 触发 _parse_format_selection 第955-957行无条件 append(None)，随后 _build_selector_function 第994行访问 None.type 抛出 AttributeError，与候选描述一致。期望行为有语言规则支持：解析阶段遇到非法逗号应抛出 SyntaxError（代码中已有 syntax_error 机制），而非把 None 传入构建阶段导致 AttributeError。测试断言 SyntaxError 合理，未假设未约定语义，也未复制实现。证据充分，接受。

[运行证据](evidence/248543bf3d91/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        for spec in (',best', 'best,,worst'):
            with self.assertRaises(SyntaxError):
                ydl.build_format_selector(spec)

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    ydl.build_format_selector(spec)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1129, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 994, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 944, 949, 952, 955, 956, 957, 979, 980, 981, 982, 983, 985, 986, 987, 994, 1102, 1103, 1104, 1108, 1109, 1110, 1111, 1113, 1114, 1116, 1117, 1119, 1120, 1121, 1123, 1125, 1128, 1129, 1131, 1144, 1149, 1289, 1338, 1602, 1626, 1643, 1649, 1671, 1682, 1701, 1710, 1711, 1727, 1777, 1791, 1808, 1819, 1844, 1845, 1846, 1909, 1910, 1911, 1913, 1914, 1916, 1917, 1924, 1925, 1926, 1932, 1934, 1936, 1938, 1939, 1940, 1941, 1942, 1947, 1948, 1950, 1960, 1966], "target_calls": [["<listcomp>", 987], ["<module>", 4], ["TokenIterator", 1108], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1109], ["__iter__", 1113], ["__next__", 1116], ["_build_selector_function", 985], ["_parse_format_selection", 934], ["_setup_opener", 1909], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1844]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    ydl.build_format_selector(spec)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1129, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 994, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 944, 949, 952, 955, 956, 957, 979, 980, 981, 982, 983, 985, 986, 987, 994, 1102, 1103, 1104, 1108, 1109, 1110, 1111, 1113, 1114, 1116, 1117, 1119, 1120, 1121, 1123, 1125, 1128, 1129, 1131, 1144, 1149, 1289, 1338, 1602, 1626, 1643, 1649, 1671, 1682, 1701, 1710, 1711, 1727, 1777, 1791, 1808, 1819, 1844, 1845, 1846, 1909, 1910, 1911, 1913, 1914, 1916, 1917, 1924, 1925, 1926, 1932, 1934, 1936, 1938, 1939, 1940, 1941, 1942, 1947, 1948, 1950, 1960, 1966], "target_calls": [["<listcomp>", 987], ["<module>", 4], ["TokenIterator", 1108], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1109], ["__iter__", 1113], ["__next__", 1116], ["_build_selector_function", 985], ["_parse_format_selection", 934], ["_setup_opener", 1909], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1844]]}

```

### [中] 斜杠 '/' 左侧缺少选择器时 first_choice 为 None

- 位置：`youtube_dl/YoutubeDL.py:958`
- 来源：llm
- 复核：已复现 — 运行证据显示测试确实调用原目标代码 build_format_selector('/best')，输入为以 '/' 开头、左侧选择器为空的格式表达式，属于该分支可处理的合法 token 序列。静态代码确认第 958-962 行未校验 current_selector 是否为 None 即作为 first_choice 存入 PICKFIRST，随后 _build_selector_function 在第 997 行递归处理该元组，None 在第 994 行访问 .type 触发 AttributeError，与观测到的异常类型和消息一致。该失败由 Python 语言规则（None 无 .type 属性）确定，不依赖未约定语义或复制实现。候选描述与证据相符，可支持正式缺陷报告。
- 问题：遇到 '/' 时直接取 first_choice = current_selector 并构造 FormatSelector(PICKFIRST, (first_choice, second_choice), [])。若 '/' 出现在表达式开头（如 '-f /best'），current_selector 为 None，first_choice 为 None。后续 _build_selector_function 对 PICKFIRST 的 selector 元组逐项构建，None 会触发 selector.type 的 AttributeError，而不是语法错误。
- 触发条件：format_spec 为 '/best' 或 'bestaudio/' 等一侧为空的选择器。
- 依据：第 958-962 行未检查 current_selector 是否为 None 即作为 first_choice 使用；第 996-997 行对 PICKFIRST 的 selector 逐项调用 _build_selector_function，None 会在第 994 行 selector.type 处失败。
- 修复建议：在构造 PICKFIRST 前校验 first_choice 非 None，否则 raise syntax_error('Unexpected "/"', start)。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
956:                         selectors.append(current_selector)
957:                         current_selector = None
958:                     elif string == '/':
959:                         first_choice = current_selector
960:                         second_choice = _parse_format_selection(tokens, inside_choice=True)
961:                         current_selector = None
962:                         selectors.append(FormatSelector(PICKFIRST, (first_choice, second_choice), []))
963:                     elif string == '[':
964:                         if not current_selector:
```

- 复现状态：reproduced
- 证据说明：运行证据显示测试确实调用原目标代码 build_format_selector('/best')，输入为以 '/' 开头、左侧选择器为空的格式表达式，属于该分支可处理的合法 token 序列。静态代码确认第 958-962 行未校验 current_selector 是否为 None 即作为 first_choice 存入 PICKFIRST，随后 _build_selector_function 在第 997 行递归处理该元组，None 在第 994 行访问 .type 触发 AttributeError，与观测到的异常类型和消息一致。该失败由 Python 语言规则（None 无 .type 属性）确定，不依赖未约定语义或复制实现。候选描述与证据相符，可支持正式缺陷报告。

[运行证据](evidence/328973b86f3e/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        with self.assertRaises(SyntaxError):
            ydl.build_format_selector('/best')
```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 10, in test_reproduction\n    ydl.build_format_selector('/best')\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1129, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 997, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector.selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 997, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector.selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 994, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 944, 949, 952, 955, 958, 959, 960, 961, 962, 979, 980, 981, 982, 983, 985, 986, 987, 994, 996, 997, 1102, 1103, 1104, 1108, 1109, 1110, 1111, 1113, 1114, 1116, 1117, 1118, 1119, 1120, 1121, 1123, 1125, 1128, 1129, 1131, 1144, 1149, 1289, 1338, 1602, 1626, 1643, 1649, 1671, 1682, 1701, 1710, 1711, 1727, 1777, 1791, 1808, 1819, 1844, 1845, 1846, 1909, 1910, 1911, 1913, 1914, 1916, 1917, 1924, 1925, 1926, 1932, 1934, 1936, 1938, 1939, 1940, 1941, 1942, 1947, 1948, 1950, 1960, 1966], "target_calls": [["<listcomp>", 987], ["<listcomp>", 997], ["<module>", 4], ["TokenIterator", 1108], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1109], ["__iter__", 1113], ["__next__", 1116], ["_build_selector_function", 985], ["_parse_format_selection", 934], ["_setup_opener", 1909], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1844]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 10, in test_reproduction\n    ydl.build_format_selector('/best')\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1129, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 997, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector.selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 997, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector.selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 994, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 944, 949, 952, 955, 958, 959, 960, 961, 962, 979, 980, 981, 982, 983, 985, 986, 987, 994, 996, 997, 1102, 1103, 1104, 1108, 1109, 1110, 1111, 1113, 1114, 1116, 1117, 1118, 1119, 1120, 1121, 1123, 1125, 1128, 1129, 1131, 1144, 1149, 1289, 1338, 1602, 1626, 1643, 1649, 1671, 1682, 1701, 1710, 1711, 1727, 1777, 1791, 1808, 1819, 1844, 1845, 1846, 1909, 1910, 1911, 1913, 1914, 1916, 1917, 1924, 1925, 1926, 1932, 1934, 1936, 1938, 1939, 1940, 1941, 1942, 1947, 1948, 1950, 1960, 1966], "target_calls": [["<listcomp>", 987], ["<listcomp>", 997], ["<module>", 4], ["TokenIterator", 1108], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1109], ["__iter__", 1113], ["__next__", 1116], ["_build_selector_function", 985], ["_parse_format_selection", 934], ["_setup_opener", 1909], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1844]]}

```

### [中] 加号 '+' 左侧缺少选择器时 video_selector 为 None

- 位置：`youtube_dl/YoutubeDL.py:973`
- 来源：llm
- 复核：已复现 — 运行证据充分：测试直接调用原目标代码 YoutubeDL.build_format_selector('+bestaudio')，输入为合法字符串，'+' 位于表达式开头时 current_selector 初始为 None（第936行），第974行将其赋给 video_selector，构造出含 None 的 MERGE 元组。第1087行对元组逐项调用 _build_selector_function，None 在第994行访问 .type 触发 AttributeError，与候选描述一致。两次执行均复现相同 AttributeError。该行为由 Python 语言规则（None 无 .type 属性）确定，无需假设未约定语义。候选声称应抛 SyntaxError 属合理期望（语法错误），但核心缺陷（None 导致 AttributeError 而非可读错误）已被证实。
- 问题：遇到 '+' 时 video_selector = current_selector，若 '+' 出现在开头（如 '-f +bestaudio'），video_selector 为 None，构造 FormatSelector(MERGE, (None, audio_selector), [])。后续 MERGE 分支第 1087 行 map(_build_selector_function, selector.selector) 会对 None 调用 _build_selector_function，导致 selector.type 处 AttributeError，而非可读语法错误。
- 触发条件：format_spec 为 '+bestaudio' 或 'bestvideo+' 等一侧为空的合并表达式。
- 依据：第 973-976 行未校验 current_selector 是否为 None；第 1087 行对 MERGE 的 selector 元组逐项构建，None 会在第 994 行 selector.type 处崩溃。
- 修复建议：在构造 MERGE 前校验 video_selector 非 None，否则 raise syntax_error('Unexpected "+"', start)。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
971:                         group = _parse_format_selection(tokens, inside_group=True)
972:                         current_selector = FormatSelector(GROUP, group, [])
973:                     elif string == '+':
974:                         video_selector = current_selector
975:                         audio_selector = _parse_format_selection(tokens, inside_merge=True)
976:                         current_selector = FormatSelector(MERGE, (video_selector, audio_selector), [])
977:                     else:
978:                         raise syntax_error('Operator not recognized: "{0}"'.format(string), start)
```

- 复现状态：reproduced
- 证据说明：运行证据充分：测试直接调用原目标代码 YoutubeDL.build_format_selector('+bestaudio')，输入为合法字符串，'+' 位于表达式开头时 current_selector 初始为 None（第936行），第974行将其赋给 video_selector，构造出含 None 的 MERGE 元组。第1087行对元组逐项调用 _build_selector_function，None 在第994行访问 .type 触发 AttributeError，与候选描述一致。两次执行均复现相同 AttributeError。该行为由 Python 语言规则（None 无 .type 属性）确定，无需假设未约定语义。候选声称应抛 SyntaxError 属合理期望（语法错误），但核心缺陷（None 导致 AttributeError 而非可读错误）已被证实。

[运行证据](evidence/49a68ceac4ab/evidence.json)

复现测试：

```python
import unittest
from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        with self.assertRaises(SyntaxError):
            ydl.build_format_selector('+bestaudio')
```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 9, in test_reproduction\n    ydl.build_format_selector('+bestaudio')\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1129, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1087, in _build_selector_function\n    video_selector, audio_selector = map(_build_selector_function, selector.selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 994, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 944, 949, 952, 955, 958, 963, 968, 973, 974, 975, 976, 979, 980, 981, 982, 983, 985, 986, 987, 994, 996, 1005, 1056, 1057, 1087, 1102, 1103, 1104, 1108, 1109, 1110, 1111, 1113, 1114, 1116, 1117, 1118, 1119, 1120, 1121, 1123, 1125, 1128, 1129, 1131, 1144, 1149, 1289, 1338, 1602, 1626, 1643, 1649, 1671, 1682, 1701, 1710, 1711, 1727, 1777, 1791, 1808, 1819, 1844, 1845, 1846, 1909, 1910, 1911, 1913, 1914, 1916, 1917, 1924, 1925, 1926, 1932, 1934, 1936, 1938, 1939, 1940, 1941, 1942, 1947, 1948, 1950, 1960, 1966], "target_calls": [["<listcomp>", 987], ["<module>", 4], ["TokenIterator", 1108], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1109], ["__iter__", 1113], ["__next__", 1116], ["_build_selector_function", 985], ["_parse_format_selection", 934], ["_setup_opener", 1909], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1844]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 9, in test_reproduction\n    ydl.build_format_selector('+bestaudio')\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1129, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 987, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1087, in _build_selector_function\n    video_selector, audio_selector = map(_build_selector_function, selector.selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 994, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 944, 949, 952, 955, 958, 963, 968, 973, 974, 975, 976, 979, 980, 981, 982, 983, 985, 986, 987, 994, 996, 1005, 1056, 1057, 1087, 1102, 1103, 1104, 1108, 1109, 1110, 1111, 1113, 1114, 1116, 1117, 1118, 1119, 1120, 1121, 1123, 1125, 1128, 1129, 1131, 1144, 1149, 1289, 1338, 1602, 1626, 1643, 1649, 1671, 1682, 1701, 1710, 1711, 1727, 1777, 1791, 1808, 1819, 1844, 1845, 1846, 1909, 1910, 1911, 1913, 1914, 1916, 1917, 1924, 1925, 1926, 1932, 1934, 1936, 1938, 1939, 1940, 1941, 1942, 1947, 1948, 1950, 1960, 1966], "target_calls": [["<listcomp>", 987], ["<module>", 4], ["TokenIterator", 1108], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1109], ["__iter__", 1113], ["__next__", 1116], ["_build_selector_function", 985], ["_parse_format_selection", 934], ["_setup_opener", 1909], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1844]]}

```

## 待验证候选与静态建议

### [低] _parse_filter 在缺少 ']' 时静默返回不完整过滤器

- 位置：`youtube_dl/YoutubeDL.py:926`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：_parse_filter 遍历 tokens，仅在遇到 ']' 时 return。若过滤器缺少右括号（如 '-f best[height>720'），循环会耗尽 tokens 而函数隐式返回 None。调用处第 967 行 current_selector.filters.append(format_filter) 会把 None 追加进 filters，随后第 1094 行 self._build_format_filter(None) 会因对 None 做正则匹配而抛出 TypeError，而非给出明确的语法错误。
- 触发条件：format_spec 为 'best[height>720'（缺少 ']'）。
- 依据：第 926-932 行循环结束无 return 语句，隐式返回 None；第 966-967 行未检查返回值；第 1094 行 _build_format_filter 期望字符串。
- 修复建议：在 _parse_filter 循环结束后 raise syntax_error('Missing closing "]"', ...)，或在调用处校验返回值非 None。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
924:         FormatSelector = collections.namedtuple('FormatSelector', ['type', 'selector', 'filters'])
925: 
926:         def _parse_filter(tokens):
927:             filter_parts = []
928:             for type, string, start, _, _ in tokens:
929:                 if type == tokenize.OP and string == ']':
930:                     return ''.join(filter_parts)
931:                 else:
932:                     filter_parts.append(string)
933: 
934:         def _parse_format_selection(tokens, inside_merge=False, inside_choice=False, inside_group=False):
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] B007: Loop control variable `start` not used within loop body

- 位置：`youtube_dl/YoutubeDL.py:928`
- 来源：ruff B007
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Loop control variable `start` not used within loop body
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B007: Loop control variable `start` not used within loop body
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
926:         def _parse_filter(tokens):
927:             filter_parts = []
928:             for type, string, start, _, _ in tokens:
929:                 if type == tokenize.OP and string == ']':
930:                     return ''.join(filter_parts)
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/YoutubeDL.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 44, "sensitive_file": 1, "benchmark_tests_hidden": 23}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
