# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`cf2ac6df6896dac4d23918867bb86fac1e1088d9`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/563 个已索引 Python 文件
- 调用：16；耗时：43.651 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（2）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

### [中] 逗号分隔时可能将 None 追加进 selectors

- 位置：`youtube_dl/YoutubeDL.py:956`
- 来源：llm
- 复核：已复现 — 运行证据显示测试确实调用了原目标代码 build_format_selector（traceback 指向 YoutubeDL.py:1128→986→993），输入 ',' 与 'best,' 是合法可构造的格式串，触发路径与候选描述一致：_parse_format_selection 在 ',' 分支无条件 append(current_selector)，此时 current_selector 为 None，随后 _build_selector_function 对 None 访问 .type 抛 AttributeError。该失败由 Python 语言规则（None 无 type 属性）确定，非测试自行假设语义。测试断言 SyntaxError 与期望行为一致，观测到的 AttributeError 与候选相同。证据充分，支持正式缺陷报告。
- 问题：在 _parse_format_selection 中，遇到 ',' 时无条件执行 selectors.append(current_selector)。若逗号出现在没有前置选择器的位置（例如格式串以 ',' 开头，或连续出现 ',,'），current_selector 仍为 None，会被追加进 selectors。随后 _build_selector_function 遍历该列表时对 None 调用 isinstance(selector, list) 为 False，接着访问 selector.type 会抛出 AttributeError，而非给出可读的语法错误。
- 触发条件：调用 build_format_selector(',') 或 build_format_selector('best,') 等以逗号开头/连续逗号的格式串。
- 依据：第955-957行：elif string == ',': selectors.append(current_selector); current_selector = None。此处未检查 current_selector 是否为 None。第984-993行 _build_selector_function 对列表元素直接访问 selector.type。
- 修复建议：在追加前判断 current_selector 是否为 None，若为 None 则 raise syntax_error('Unexpected ","', start)。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
954:                         break
955:                     elif string == ',':
956:                         selectors.append(current_selector)
957:                         current_selector = None
958:                     elif string == '/':
959:                         first_choice = current_selector
```

- 复现状态：reproduced
- 证据说明：运行证据显示测试确实调用了原目标代码 build_format_selector（traceback 指向 YoutubeDL.py:1128→986→993），输入 ',' 与 'best,' 是合法可构造的格式串，触发路径与候选描述一致：_parse_format_selection 在 ',' 分支无条件 append(current_selector)，此时 current_selector 为 None，随后 _build_selector_function 对 None 访问 .type 抛 AttributeError。该失败由 Python 语言规则（None 无 type 属性）确定，非测试自行假设语义。测试断言 SyntaxError 与期望行为一致，观测到的 AttributeError 与候选相同。证据充分，支持正式缺陷报告。

[运行证据](evidence/617648cc5081/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        for spec in [',', 'best,']:
            with self.assertRaises(SyntaxError):
                selector = ydl.build_format_selector(spec)
                list(selector([]))

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    selector = ydl.build_format_selector(spec)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1128, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 993, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 943, 944, 949, 952, 955, 956, 957, 978, 979, 980, 982, 984, 985, 986, 993, 1101, 1102, 1103, 1107, 1108, 1109, 1110, 1112, 1113, 1115, 1116, 1118, 1119, 1120, 1122, 1124, 1127, 1128, 1130, 1143, 1148, 1288, 1337, 1601, 1625, 1642, 1648, 1670, 1681, 1700, 1709, 1710, 1726, 1776, 1790, 1807, 1818, 1843, 1844, 1845, 1908, 1909, 1910, 1912, 1913, 1915, 1916, 1923, 1924, 1925, 1931, 1933, 1935, 1937, 1938, 1939, 1940, 1941, 1946, 1947, 1949, 1959, 1965], "target_calls": [["<listcomp>", 986], ["<module>", 4], ["TokenIterator", 1107], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1108], ["__iter__", 1112], ["__next__", 1115], ["_build_selector_function", 984], ["_parse_format_selection", 934], ["_setup_opener", 1908], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1843]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 11, in test_reproduction\n    selector = ydl.build_format_selector(spec)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1128, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 993, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 943, 944, 949, 952, 955, 956, 957, 978, 979, 980, 982, 984, 985, 986, 993, 1101, 1102, 1103, 1107, 1108, 1109, 1110, 1112, 1113, 1115, 1116, 1118, 1119, 1120, 1122, 1124, 1127, 1128, 1130, 1143, 1148, 1288, 1337, 1601, 1625, 1642, 1648, 1670, 1681, 1700, 1709, 1710, 1726, 1776, 1790, 1807, 1818, 1843, 1844, 1845, 1908, 1909, 1910, 1912, 1913, 1915, 1916, 1923, 1924, 1925, 1931, 1933, 1935, 1937, 1938, 1939, 1940, 1941, 1946, 1947, 1949, 1959, 1965], "target_calls": [["<listcomp>", 986], ["<module>", 4], ["TokenIterator", 1107], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1108], ["__iter__", 1112], ["__next__", 1115], ["_build_selector_function", 984], ["_parse_format_selection", 934], ["_setup_opener", 1908], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1843]]}

```

### [中] 加号左侧缺少选择器时 video_selector 为 None

- 位置：`youtube_dl/YoutubeDL.py:972`
- 来源：llm
- 复核：已复现 — 测试确实调用原目标代码 build_format_selector('+bestaudio')，输入有效（'+' 是合法 token，格式串语法上应被拒绝）。运行证据显示 AttributeError: 'NoneType' object has no attribute 'type'，与候选描述一致：'+' 为首 token 时 current_selector 为 None，构造 MERGE 后 _build_selector_function 对 None 访问 .type。契约依据为 Python 语言规则（对 None 访问属性必抛 AttributeError），且代码中其他非法操作符均通过 syntax_error 抛 SyntaxError，说明缺少左侧选择器应报语法错误而非 AttributeError。测试未复制实现或制造无条件失败，断言合理。证据充分，支持正式缺陷报告。
- 问题：遇到 '+' 时 video_selector = current_selector 可能为 None（例如格式串以 '+' 开头）。构造 FormatSelector(MERGE, (None, audio_selector), [])。在 _build_selector_function 的 MERGE 分支第1086行 map(_build_selector_function, selector.selector) 会对 None 调用 _build_selector_function，访问 None.type 抛 AttributeError，而非语法错误。
- 触发条件：调用 build_format_selector('+bestaudio')。
- 依据：第972-975行：video_selector = current_selector; audio_selector = _parse_format_selection(tokens, inside_merge=True); current_selector = FormatSelector(MERGE, (video_selector, audio_selector), [])。第1086行 map(_build_selector_function, selector.selector)。
- 修复建议：在构造 MERGE 前校验 video_selector 不为 None，否则 raise syntax_error('Unexpected "+"', start)。
- 验证方式：两次独立隔离执行出现同类型失败并触达目标代码；预期行为经模型对照引用原文核验，仍供维护者复查。

```python
970:                         group = _parse_format_selection(tokens, inside_group=True)
971:                         current_selector = FormatSelector(GROUP, group, [])
972:                     elif string == '+':
973:                         video_selector = current_selector
974:                         audio_selector = _parse_format_selection(tokens, inside_merge=True)
975:                         current_selector = FormatSelector(MERGE, (video_selector, audio_selector), [])
976:                     else:
977:                         raise syntax_error('Operator not recognized: "{0}"'.format(string), start)
```

- 复现状态：reproduced
- 证据说明：测试确实调用原目标代码 build_format_selector('+bestaudio')，输入有效（'+' 是合法 token，格式串语法上应被拒绝）。运行证据显示 AttributeError: 'NoneType' object has no attribute 'type'，与候选描述一致：'+' 为首 token 时 current_selector 为 None，构造 MERGE 后 _build_selector_function 对 None 访问 .type。契约依据为 Python 语言规则（对 None 访问属性必抛 AttributeError），且代码中其他非法操作符均通过 syntax_error 抛 SyntaxError，说明缺少左侧选择器应报语法错误而非 AttributeError。测试未复制实现或制造无条件失败，断言合理。证据充分，支持正式缺陷报告。

[运行证据](evidence/e7aa719b31af/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        with self.assertRaises(SyntaxError):
            ydl.build_format_selector('+bestaudio')
```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 10, in test_reproduction\n    ydl.build_format_selector('+bestaudio')\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1128, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1086, in _build_selector_function\n    video_selector, audio_selector = map(_build_selector_function, selector.selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 993, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 944, 949, 952, 955, 958, 962, 967, 972, 973, 974, 975, 978, 979, 980, 981, 982, 984, 985, 986, 993, 995, 1004, 1055, 1056, 1086, 1101, 1102, 1103, 1107, 1108, 1109, 1110, 1112, 1113, 1115, 1116, 1117, 1118, 1119, 1120, 1122, 1124, 1127, 1128, 1130, 1143, 1148, 1288, 1337, 1601, 1625, 1642, 1648, 1670, 1681, 1700, 1709, 1710, 1726, 1776, 1790, 1807, 1818, 1843, 1844, 1845, 1908, 1909, 1910, 1912, 1913, 1915, 1916, 1923, 1924, 1925, 1931, 1933, 1935, 1937, 1938, 1939, 1940, 1941, 1946, 1947, 1949, 1959, 1965], "target_calls": [["<listcomp>", 986], ["<module>", 4], ["TokenIterator", 1107], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1108], ["__iter__", 1112], ["__next__", 1115], ["_build_selector_function", 984], ["_parse_format_selection", 934], ["_setup_opener", 1908], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1843]]}

```

执行2：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `failure_observed`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "AttributeError", "message": "'NoneType' object has no attribute 'type'", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 10, in test_reproduction\n    ydl.build_format_selector('+bestaudio')\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1128, in build_format_selector\n    return _build_selector_function(parsed_selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in _build_selector_function\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 986, in <listcomp>\n    fs = [_build_selector_function(s) for s in selector]\n  File \"/work/youtube_dl/YoutubeDL.py\", line 1086, in _build_selector_function\n    video_selector, audio_selector = map(_build_selector_function, selector.selector)\n  File \"/work/youtube_dl/YoutubeDL.py\", line 993, in _build_selector_function\n    elif selector.type == GROUP:\nAttributeError: 'NoneType' object has no attribute 'type'\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 30, 42, 81, 82, 83, 84, 85, 92, 95, 267, 269, 270, 271, 272, 273, 274, 276, 278, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 291, 318, 319, 328, 333, 335, 336, 337, 339, 346, 349, 365, 367, 368, 369, 371, 383, 387, 388, 390, 395, 399, 412, 416, 419, 430, 440, 450, 457, 464, 468, 474, 504, 521, 533, 540, 583, 625, 631, 632, 684, 692, 856, 913, 914, 920, 921, 922, 923, 924, 926, 934, 935, 936, 937, 939, 940, 941, 942, 943, 944, 949, 952, 955, 958, 962, 967, 972, 973, 974, 975, 978, 979, 980, 981, 982, 984, 985, 986, 993, 995, 1004, 1055, 1056, 1086, 1101, 1102, 1103, 1107, 1108, 1109, 1110, 1112, 1113, 1115, 1116, 1117, 1118, 1119, 1120, 1122, 1124, 1127, 1128, 1130, 1143, 1148, 1288, 1337, 1601, 1625, 1642, 1648, 1670, 1681, 1700, 1709, 1710, 1726, 1776, 1790, 1807, 1818, 1843, 1844, 1845, 1908, 1909, 1910, 1912, 1913, 1915, 1916, 1923, 1924, 1925, 1931, 1933, 1935, 1937, 1938, 1939, 1940, 1941, 1946, 1947, 1949, 1959, 1965], "target_calls": [["<listcomp>", 986], ["<module>", 4], ["TokenIterator", 1107], ["YoutubeDL", 95], ["__init__", 276], ["__init__", 1108], ["__iter__", 1112], ["__next__", 1115], ["_build_selector_function", 984], ["_parse_format_selection", 934], ["_setup_opener", 1908], ["add_default_info_extractors", 383], ["add_info_extractor", 365], ["build_format_selector", 913], ["print_debug_header", 1843]]}

```

## 待验证候选与静态建议

### [中] 斜杠左侧缺少选择器时 first_choice 为 None

- 位置：`youtube_dl/YoutubeDL.py:959`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：遇到 '/' 时，first_choice = current_selector 可能为 None（例如格式串以 '/' 开头或 'a,/' 之后）。随后构造 FormatSelector(PICKFIRST, (None, second_choice), [])。在 _build_selector_function 的 PICKFIRST 分支中会对每个子选择器调用 _build_selector_function(s)，对 None 访问 s.type 抛 AttributeError，而不是报告语法错误。
- 触发条件：调用 build_format_selector('/best') 或 build_format_selector('best,/worst')。
- 依据：第958-961行：first_choice = current_selector; second_choice = _parse_format_selection(tokens, inside_choice=True); current_selector = FormatSelector(PICKFIRST, (first_choice, second_choice), [])。第995-996行对 selector.selector 中每个元素调用 _build_selector_function。
- 修复建议：在构造 PICKFIRST 前校验 first_choice 不为 None，否则 raise syntax_error('Unexpected "/"', start)。
- 验证方式：测试包含不支持的执行或无条件失败操作。

```python
957:                         current_selector = None
958:                     elif string == '/':
959:                         first_choice = current_selector
960:                         second_choice = _parse_format_selection(tokens, inside_choice=True)
961:                         current_selector = FormatSelector(PICKFIRST, (first_choice, second_choice), [])
962:                     elif string == '[':
963:                         if not current_selector:
```

- 复现状态：invalid_plan
- 证据说明：测试包含不支持的执行或无条件失败操作。

[运行证据](evidence/c986d482799a/evidence.json)

复现测试：

```python
import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        for spec in ('/best', 'best,/worst'):
            try:
                ydl.build_format_selector(spec)
            except SyntaxError:
                continue
            except AttributeError as e:
                self.fail(
                    'build_format_selector(%r) raised AttributeError '
                    'instead of a syntax error: %s' % (spec, e))

```

### [低] _parse_filter 在缺少 ']' 时静默返回不完整过滤器

- 位置：`youtube_dl/YoutubeDL.py:926`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：_parse_filter 遍历 tokens，仅在遇到 ']' 时返回拼接结果。若格式串中 '[' 后没有对应的 ']'（例如 'best[height>720'），循环会因 tokens 耗尽而结束，函数隐式返回 None。随后第966行 current_selector.filters.append(None)，之后 _build_format_filter(None) 会对 None 执行正则 search 抛 TypeError，而不是给出可读的语法错误。
- 触发条件：调用 build_format_selector('best[height>720')（缺少右方括号）。
- 依据：第926-932行 _parse_filter 无 ']' 时无 return 语句，隐式返回 None；第965-966行 format_filter = _parse_filter(tokens); current_selector.filters.append(format_filter)；第1093行 filters = [self._build_format_filter(f) for f in selector.filters]，_build_format_filter 对 filter_spec 调用 operator_rex.search。
- 修复建议：在 _parse_filter 循环结束后 raise syntax_error('Missing closing "]"', ...) 或返回明确错误，避免将 None 作为过滤器传入。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
924:         FormatSelector = collections.namedtuple('FormatSelector', ['type', 'selector', 'filters'])
925: 
926:         def _parse_filter(tokens):
927:             filter_parts = []
928:             for type, string, start, _, _ in tokens:
929:                 if type == tokenize.OP and string == ']':
930:                     return ''.join(filter_parts)
931:                 else:
932:                     filter_parts.append(string)
933: 
934:         def _parse_format_selection(tokens, inside_merge=False, inside_choice=False, inside_group=False):
```

- 复现状态：budget_exhausted
- 证据说明：达到复现候选数量预算。

### [低] B007: Loop control variable `start` not used within loop body

- 位置：`youtube_dl/YoutubeDL.py:928`
- 来源：ruff B007
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Loop control variable `start` not used within loop body
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B007: Loop control variable `start` not used within loop body
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
926:         def _parse_filter(tokens):
927:             filter_parts = []
928:             for type, string, start, _, _ in tokens:
929:                 if type == tokenize.OP and string == ']':
930:                     return ''.join(filter_parts)
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/YoutubeDL.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 44, "sensitive_file": 1, "benchmark_tests_hidden": 23}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
