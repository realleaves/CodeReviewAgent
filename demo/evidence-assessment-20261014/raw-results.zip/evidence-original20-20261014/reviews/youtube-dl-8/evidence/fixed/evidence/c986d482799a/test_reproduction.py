import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        for spec in ('/best', 'best,/worst'):
            try:
                ydl.build_format_selector(spec)
            except SyntaxError:
                continue
            except AttributeError as e:
                self.fail(
                    'build_format_selector(%r) raised AttributeError '
                    'instead of a syntax error: %s' % (spec, e))
