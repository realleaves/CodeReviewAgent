import subprocess
import sys
import unittest


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        code = (
            "import pysnooper\n"
            "write = pysnooper.get_write_function(123)\n"
            "try:\n"
            "    write('hello')\n"
            "except AttributeError:\n"
            "    print('ATTRIBUTE_ERROR')\n"
            "except AssertionError:\n"
            "    print('ASSERTION_ERROR')\n"
            "else:\n"
            "    print('NO_ERROR')\n"
        )
        result = subprocess.run(
            [sys.executable, '-O', '-c', code],
            capture_output=True,
            text=True,
        )
        self.assertIn(
            'ATTRIBUTE_ERROR',
            result.stdout,
            msg='在 -O 下非法 output 应导致 AttributeError，实际输出: %r, stderr: %r'
            % (result.stdout, result.stderr),
        )
