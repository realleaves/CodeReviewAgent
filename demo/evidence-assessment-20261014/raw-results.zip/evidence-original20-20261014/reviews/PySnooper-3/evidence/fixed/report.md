# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`6e3d797be3fa0a746fb5b1b7c7fea78eb926c208`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/6 个已索引 Python 文件
- 调用：7；耗时：15.859 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] assert 校验输出流在 -O 下被移除，非法 output 导致延迟 AttributeError

- 位置：`pysnooper/pysnooper.py:29`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：get_write_function 对非 None、非 str/PathLike 的 output 仅用 assert isinstance(output, utils.WritableStream) 做校验。在 Python -O 模式下 assert 被剥离，任何不具备 write 方法的对象（如整数、列表）都会通过校验，返回的 write 闭包在调用 output.write(s) 时抛出 AttributeError。即便在非 -O 下，assert 失败抛出的也是 AssertionError 而非明确的类型错误，错误信息不清晰。
- 触发条件：pysnooper.snoop(output=123) 装饰函数并执行，或在 -O 下运行；调用 write 时执行 output.write(s)。
- 依据：第 29 行 `assert isinstance(output, utils.WritableStream)`，第 30-31 行 `def write(s): output.write(s)`。assert 在 -O 下被移除，非法对象进入 write 分支。
- 修复建议：改为显式类型检查并抛出 TypeError，例如 `if not isinstance(output, utils.WritableStream): raise TypeError(...)`，避免依赖 assert。
- 验证方式：测试导入不在目标模块/受支持标准库集合中。

```python
27:                 output_file.write(s)
28:     else:
29:         assert isinstance(output, utils.WritableStream)
30:         def write(s):
31:             output.write(s)
32: 
33:     return write
```

- 复现状态：invalid_plan
- 证据说明：测试导入不在目标模块/受支持标准库集合中。

[运行证据](evidence/fc25b41936e7/evidence.json)

复现测试：

```python
import subprocess
import sys
import unittest


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        code = (
            "import pysnooper\n"
            "write = pysnooper.get_write_function(123)\n"
            "try:\n"
            "    write('hello')\n"
            "except AttributeError:\n"
            "    print('ATTRIBUTE_ERROR')\n"
            "except AssertionError:\n"
            "    print('ASSERTION_ERROR')\n"
            "else:\n"
            "    print('NO_ERROR')\n"
        )
        result = subprocess.run(
            [sys.executable, '-O', '-c', code],
            capture_output=True,
            text=True,
        )
        self.assertIn(
            'ATTRIBUTE_ERROR',
            result.stdout,
            msg='在 -O 下非法 output 应导致 AttributeError，实际输出: %r, stderr: %r'
            % (result.stdout, result.stderr),
        )

```

### [低] PathLike 输出路径在写入时未转换为字符串

- 位置：`pysnooper/pysnooper.py:24`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：当 output 是 pycompat.PathLike 实例（如 pathlib.Path）时，write 闭包直接调用 open(output, 'a')。在 Python 3.6+ 中 open 支持 PathLike，因此通常可用；但在 pycompat 回退定义（无 os.PathLike 的旧环境）下，PathLike 是自定义 ABC，open 不接受该对象，会抛 TypeError。此外每次 write 都重新 open 文件，效率较低但非缺陷。
- 触发条件：在无 os.PathLike 的 Python 环境（如 Python 2）传入自定义 PathLike 对象作为 output。
- 依据：第 24 行 `isinstance(output, (pycompat.PathLike, str))`，第 26 行 `open(output, 'a')`；pycompat.py 第 22-32 行在无 os.PathLike 时自定义 PathLike ABC。
- 修复建议：在写入前用 os.fspath(output) 或 str(output) 归一化路径，确保兼容回退的 PathLike 实现。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
22:             stderr = sys.stderr
23:             stderr.write(s)
24:     elif isinstance(output, (pycompat.PathLike, str)):
25:         def write(s):
26:             with open(output, 'a') as output_file:
27:                 output_file.write(s)
28:     else:
29:         assert isinstance(output, utils.WritableStream)
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称在无 os.PathLike 的旧环境（如 Python 2）下，自定义 PathLike 对象传给 open 会抛 TypeError。但当前环境为 Python 3.8.20，os.PathLike 存在，pycompat.PathLike 即 os.PathLike，open 原生支持 PathLike，无法构造出候选所描述的失败场景。该缺陷依赖一个本环境不存在的旧 Python 回退分支，无法在当前环境构造有效输入进行复现，故 applicable=false。

[运行证据](evidence/3f031d36610c/evidence.json)

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`pysnooper/pysnooper.py:29`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
27:                 output_file.write(s)
28:     else:
29:         assert isinstance(output, utils.WritableStream)
30:         def write(s):
31:             output.write(s)
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| pysnooper/pysnooper.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 8, "benchmark_tests_hidden": 3}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
