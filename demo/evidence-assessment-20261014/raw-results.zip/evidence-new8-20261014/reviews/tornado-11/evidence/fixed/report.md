# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`79ef301eb05cac82c075198e502d94dad296f6aa`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/63 个已索引 Python 文件
- 调用：6；耗时：18.239 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [低] Content-Length 重复值比较未去除首尾空白，可能误判不等

- 位置：`tornado/http1connection.py:533`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 537 行用 re.split(r',\s*', headers["Content-Length"]) 拆分重复的 Content-Length，但只去除了逗号后的空白，未去除各片段首尾空白。例如 "5, 5 " 或 "5 ,5" 会得到含空白的片段，导致 any(i != pieces[0]) 判定为不等而抛出 HTTPInputError，尽管各值语义相同。
- 触发条件：Content-Length 头为 "5, 5 "（末尾带空格）或 "5 ,5"（逗号前带空格）等含多余空白的等价重复值。
- 依据：第 537-542 行：pieces = re.split(r',\s*', headers["Content-Length"]); if any(i != pieces[0] for i in pieces): raise ...。正则只处理逗号后的空白，未 strip 各片段，比较为字符串精确比较。
- 修复建议：对每个片段执行 strip() 后再比较，例如 pieces = [p.strip() for p in re.split(r',', headers["Content-Length"])]。
- 验证方式：测试必须有且仅有一个 ReproductionTest。

```python
531:                 raise httputil.HTTPInputError(
532:                     "Response with both Transfer-Encoding and Content-Length")
533:             if "," in headers["Content-Length"]:
534:                 # Proxies sometimes cause Content-Length headers to get
535:                 # duplicated.  If all the values are identical then we can
536:                 # use them but if they differ it's an error.
537:                 pieces = re.split(r',\s*', headers["Content-Length"])
538:                 if any(i != pieces[0] for i in pieces):
539:                     raise httputil.HTTPInputError(
540:                         "Multiple unequal Content-Lengths: %r" %
541:                         headers["Content-Length"])
542:                 headers["Content-Length"] = pieces[0]
543: 
544:             try:
```

- 复现状态：invalid_plan
- 证据说明：测试必须有且仅有一个 ReproductionTest。

[运行证据](evidence/2d317dba5d82/evidence.json)

复现测试：

```python
import unittest
from tornado.http1connection import HTTP1Connection
from tornado.httputil import HTTPHeaders


class _DummyStream(object):
    def set_nodelay(self, value):
        pass

    def set_close_callback(self, cb):
        pass

    def close(self):
        pass


class _DummyDelegate(object):
    def data_received(self, chunk):
        return None

    def finish(self):
        return None

    def on_connection_close(self):
        return None


class ReproductionTest(unittest.TestCase):
    def _make_conn(self):
        conn = HTTP1Connection.__new__(HTTP1Connection)
        conn.stream = _DummyStream()
        conn.is_client = True
        conn._max_body_size = 100 * 1024 * 1024
        conn._write_finished = True
        conn.params = type('P', (), {'chunk_size': 65536})()
        return conn

    def test_reproduction(self):
        conn = self._make_conn()
        for value in ("5, 5 ", "5 ,5", "5,5"):
            headers = HTTPHeaders()
            headers["Content-Length"] = value
            try:
                conn._read_body(200, headers, _DummyDelegate())
            except Exception as e:
                self.fail(
                    "equivalent duplicate Content-Length %r raised %r"
                    % (value, e))
            self.assertEqual(headers["Content-Length"], "5")

```

### [低] B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling

- 位置：`tornado/http1connection.py:521`
- 来源：ruff B904
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
519:         except ValueError:
520:             # probably form split() if there was no ':' in the line
521:             raise httputil.HTTPInputError("Malformed HTTP headers: %r" %
522:                                           data[eol:100])
523:         return start_line, headers
```

### [低] B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling

- 位置：`tornado/http1connection.py:548`
- 来源：ruff B904
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
546:             except ValueError:
547:                 # Handles non-integer Content-Length value.
548:                 raise httputil.HTTPInputError(
549:                     "Only integer Content-Length is allowed: %s" % headers["Content-Length"])
550: 
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/http1connection.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 182, "sensitive_file": 1, "benchmark_tests_hidden": 49}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
