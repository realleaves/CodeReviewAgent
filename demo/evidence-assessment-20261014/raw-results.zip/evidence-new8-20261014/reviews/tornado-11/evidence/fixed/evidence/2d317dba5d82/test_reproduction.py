import unittest
from tornado.http1connection import HTTP1Connection
from tornado.httputil import HTTPHeaders


class _DummyStream(object):
    def set_nodelay(self, value):
        pass

    def set_close_callback(self, cb):
        pass

    def close(self):
        pass


class _DummyDelegate(object):
    def data_received(self, chunk):
        return None

    def finish(self):
        return None

    def on_connection_close(self):
        return None


class ReproductionTest(unittest.TestCase):
    def _make_conn(self):
        conn = HTTP1Connection.__new__(HTTP1Connection)
        conn.stream = _DummyStream()
        conn.is_client = True
        conn._max_body_size = 100 * 1024 * 1024
        conn._write_finished = True
        conn.params = type('P', (), {'chunk_size': 65536})()
        return conn

    def test_reproduction(self):
        conn = self._make_conn()
        for value in ("5, 5 ", "5 ,5", "5,5"):
            headers = HTTPHeaders()
            headers["Content-Length"] = value
            try:
                conn._read_body(200, headers, _DummyDelegate())
            except Exception as e:
                self.fail(
                    "equivalent duplicate Content-Length %r raised %r"
                    % (value, e))
            self.assertEqual(headers["Content-Length"], "5")
