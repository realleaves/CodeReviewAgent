# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`79ef301eb05cac82c075198e502d94dad296f6aa`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/63 个已索引 Python 文件
- 调用：7；耗时：17.201 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] 负数 Content-Length 绕过长度校验并导致读取异常

- 位置：`tornado/http1connection.py:545`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：int() 接受带符号的十进制字符串，因此 Content-Length: -1 会被解析为 content_length = -1。第 551 行的校验只检查 content_length > self._max_body_size，负数不会触发该检查。随后第 566-567 行 content_length is not None 成立，进入 _read_fixed_body(-1, delegate)。在 _read_fixed_body 中 while content_length > 0 为假，循环体不执行，函数直接返回，body 被当作空处理，而实际连接上仍有未消费的字节，破坏后续请求的解析（keep-alive 复用连接时会把残留数据当作下一个请求）。预期行为：Content-Length 必须是非负整数，负值应抛出 HTTPInputError。
- 触发条件：客户端发送请求头 Content-Length: -1（或 -0 之外的任何负数字符串），且连接为 keep-alive。
- 依据：第 545 行 content_length = int(headers["Content-Length"]) 接受负数；第 551 行仅判断 content_length > self._max_body_size；第 576 行 _read_fixed_body 的 while content_length > 0 对负数不进入循环，直接返回。
- 修复建议：在解析后增加 content_length < 0 的检查并抛出 HTTPInputError，例如 if content_length < 0: raise httputil.HTTPInputError("Invalid Content-Length")。
- 验证方式：测试必须有且仅有一个 ReproductionTest。

```python
543: 
544:             try:
545:                 content_length = int(headers["Content-Length"])
546:             except ValueError:
547:                 # Handles non-integer Content-Length value.
548:                 raise httputil.HTTPInputError(
549:                     "Only integer Content-Length is allowed: %s" % headers["Content-Length"])
550: 
551:             if content_length > self._max_body_size:
552:                 raise httputil.HTTPInputError("Content-Length too long")
553:         else:
554:             content_length = None
```

- 复现状态：invalid_plan
- 证据说明：测试必须有且仅有一个 ReproductionTest。

[运行证据](evidence/f555c00d7d01/evidence.json)

复现测试：

```python
import unittest
from tornado.http1connection import HTTP1Connection
from tornado.httputil import HTTPHeaders, HTTPInputError


class _FakeStream(object):
    max_buffer_size = 1024 * 1024


class _FakeDelegate(object):
    def headers_received(self, start_line, headers):
        return None

    def data_received(self, chunk):
        return None

    def finish(self):
        return None

    def on_connection_close(self):
        return None


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        conn = HTTP1Connection(_FakeStream(), is_client=False)
        headers = HTTPHeaders()
        headers["Content-Length"] = "-1"
        with self.assertRaises(HTTPInputError):
            conn._read_body(0, headers, _FakeDelegate())

```

### [低] B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling

- 位置：`tornado/http1connection.py:521`
- 来源：ruff B904
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
519:         except ValueError:
520:             # probably form split() if there was no ':' in the line
521:             raise httputil.HTTPInputError("Malformed HTTP headers: %r" %
522:                                           data[eol:100])
523:         return start_line, headers
```

### [低] B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling

- 位置：`tornado/http1connection.py:548`
- 来源：ruff B904
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
546:             except ValueError:
547:                 # Handles non-integer Content-Length value.
548:                 raise httputil.HTTPInputError(
549:                     "Only integer Content-Length is allowed: %s" % headers["Content-Length"])
550: 
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/http1connection.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 182, "sensitive_file": 1, "benchmark_tests_hidden": 49}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
