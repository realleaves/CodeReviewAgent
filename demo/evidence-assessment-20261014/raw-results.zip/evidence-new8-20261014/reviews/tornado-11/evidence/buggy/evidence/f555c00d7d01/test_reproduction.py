import unittest
from tornado.http1connection import HTTP1Connection
from tornado.httputil import HTTPHeaders, HTTPInputError


class _FakeStream(object):
    max_buffer_size = 1024 * 1024


class _FakeDelegate(object):
    def headers_received(self, start_line, headers):
        return None

    def data_received(self, chunk):
        return None

    def finish(self):
        return None

    def on_connection_close(self):
        return None


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        conn = HTTP1Connection(_FakeStream(), is_client=False)
        headers = HTTPHeaders()
        headers["Content-Length"] = "-1"
        with self.assertRaises(HTTPInputError):
            conn._read_body(0, headers, _FakeDelegate())
