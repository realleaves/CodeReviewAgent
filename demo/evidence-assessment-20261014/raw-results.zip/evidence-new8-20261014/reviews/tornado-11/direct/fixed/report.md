# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`79ef301eb05cac82c075198e502d94dad296f6aa`
- 状态：**completed**；模式：direct；模型：deepseek-flash
- 完成语义审查：0/63 个已索引 Python 文件
- 调用：1；耗时：7.609 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- 本报告是静态分析及模型推断；外部容器复现证据由评测程序另行保存。

## 候选问题（4）

### [中] Content-Length 解析未拒绝负数

- 位置：`tornado/http1connection.py:545`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：int() 会接受负数（如 "-1"），代码只捕获 ValueError，未校验 content_length < 0。负的 Content-Length 会绕过第 551 行的上限检查，随后传入 _read_fixed_body，使 while content_length > 0 循环不执行，导致请求体被静默丢弃、后续字节被当作下一个请求解析，可能造成请求走私/响应错位。
- 触发条件：对端发送 Content-Length: -1（或任何负整数字符串）的响应/请求。
- 依据：第 544-549 行仅 try: content_length = int(headers["Content-Length"]) except ValueError；第 551 行只检查 content_length > self._max_body_size，负数不触发；第 566-567 行 content_length is not None 时直接调用 _read_fixed_body。
- 修复建议：在 int() 成功后增加 if content_length < 0: raise httputil.HTTPInputError("Negative Content-Length")，或统一校验 0 <= content_length <= self._max_body_size。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
543: 
544:             try:
545:                 content_length = int(headers["Content-Length"])
546:             except ValueError:
547:                 # Handles non-integer Content-Length value.
548:                 raise httputil.HTTPInputError(
549:                     "Only integer Content-Length is allowed: %s" % headers["Content-Length"])
550: 
551:             if content_length > self._max_body_size:
```

### [中] Transfer-Encoding 仅精确匹配 chunked，其他取值被忽略

- 位置：`tornado/http1connection.py:568`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 568 行用 headers.get("Transfer-Encoding", "").lower() == "chunked" 做精确比较。若值为 "chunked, gzip"、"identity" 或其他非 chunked 编码，条件为假，代码会落到第 570-572 行按 read-until-close 处理（客户端）或返回 None（服务端），从而不按分块编码解析消息体，可能造成消息边界错误和请求/响应走私。
- 触发条件：对端发送 Transfer-Encoding: chunked, gzip 或 Transfer-Encoding: identity 等非精确 "chunked" 值。
- 依据：第 568 行 headers.get("Transfer-Encoding", "").lower() == "chunked" 为精确字符串比较；第 570-572 行在非 chunked 时回退到 _read_body_until_close 或 None。
- 修复建议：按 RFC 7230 解析 Transfer-Encoding 列表，取最后一个编码判断是否为 chunked；对不支持的编码显式报错，而不是静默回退到 read-until-close。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
566:         if content_length is not None:
567:             return self._read_fixed_body(content_length, delegate)
568:         if headers.get("Transfer-Encoding", "").lower() == "chunked":
569:             return self._read_chunked_body(delegate)
570:         if self.is_client:
571:             return self._read_body_until_close(delegate)
```

### [低] 重复 Content-Length 比较未去除空白，可能误判不等

- 位置：`tornado/http1connection.py:533`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 537 行用 re.split(r',\s*', ...) 拆分，但只去掉了逗号后的空白，未去除各片段前后的空白。例如 "5, 5 " 会得到 ['5', '5 ']，第 538 行 any(i != pieces[0]) 判定不等而抛出 HTTPInputError，尽管两个值语义相同。这会把合法（虽不规范）的重复头当作错误拒绝。
- 触发条件：对端发送 Content-Length: 5, 5 （末尾带空格）或类似带空白的重复值。
- 依据：第 537 行 pieces = re.split(r',\s*', headers["Content-Length"])；第 538 行 any(i != pieces[0] for i in pieces) 直接比较未 strip 的片段。
- 修复建议：拆分后对每个片段调用 .strip() 再比较，例如 pieces = [p.strip() for p in re.split(r',', headers["Content-Length"])]。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
531:                 raise httputil.HTTPInputError(
532:                     "Response with both Transfer-Encoding and Content-Length")
533:             if "," in headers["Content-Length"]:
534:                 # Proxies sometimes cause Content-Length headers to get
535:                 # duplicated.  If all the values are identical then we can
536:                 # use them but if they differ it's an error.
537:                 pieces = re.split(r',\s*', headers["Content-Length"])
538:                 if any(i != pieces[0] for i in pieces):
539:                     raise httputil.HTTPInputError(
540:                         "Multiple unequal Content-Lengths: %r" %
541:                         headers["Content-Length"])
542:                 headers["Content-Length"] = pieces[0]
543: 
544:             try:
```

### [低] 204 响应体校验未覆盖 1xx 与 304 等无体状态码

- 位置：`tornado/http1connection.py:556`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 556 行只对 code == 204 做无体校验。按 RFC 7230，1xx 和 304 响应同样不得包含消息体，且 304 可能携带 Content-Length 头（表示所选表示的长度）而不应读取体。当前实现会把这些状态码当作普通响应处理，可能读取本不存在的消息体，导致连接错位。
- 触发条件：对端返回 304 且带 Content-Length 头，或返回 1xx 响应。
- 依据：第 556 行 if code == 204: 仅覆盖 204；第 566-572 行对其它状态码按 Content-Length/Transfer-Encoding 正常读取体。
- 修复建议：将无体状态码判断扩展为 1xx、204、304，并对 304 忽略 Content-Length 不读取体。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
554:             content_length = None
555: 
556:         if code == 204:
557:             # This response code is not allowed to have a non-empty body,
558:             # and has an implicit length of zero instead of read-until-close.
559:             # http://www.w3.org/Protocols/rfc2616/rfc2616-sec4.html#sec4.3
560:             if ("Transfer-Encoding" in headers or
561:                     content_length not in (None, 0)):
562:                 raise httputil.HTTPInputError(
563:                     "Response with code %d should not have body" % code)
564:             content_length = 0
565: 
566:         if content_length is not None:
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/http1connection.py | not_requested | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 182, "sensitive_file": 1, "benchmark_tests_hidden": 49}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
