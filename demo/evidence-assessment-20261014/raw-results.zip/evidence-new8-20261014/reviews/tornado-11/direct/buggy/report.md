# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`79ef301eb05cac82c075198e502d94dad296f6aa`
- 状态：**completed**；模式：direct；模型：deepseek-flash
- 完成语义审查：0/63 个已索引 Python 文件
- 调用：1；耗时：7.621 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- 本报告是静态分析及模型推断；外部容器复现证据由评测程序另行保存。

## 候选问题（4）

### [中] Content-Length 为负数时未校验，导致读取行为异常

- 位置：`tornado/http1connection.py:545`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：int() 可以成功解析负数（如 "-1"），因此不会触发 ValueError 分支。负的 content_length 会绕过第 551 行的上限检查（负数不大于 _max_body_size），随后在第 566 行 content_length is not None 成立，进入 _read_fixed_body。在 _read_fixed_body 中 while content_length > 0 为假，直接返回，导致请求体被静默丢弃，后续解析从错误位置继续，可能造成请求走私或响应错位。
- 触发条件：对端发送 Content-Length: -1（或任何负整数字符串）的请求/响应。
- 依据：第 544-549 行仅捕获 ValueError，未检查 content_length < 0；第 551 行 `if content_length > self._max_body_size` 对负数不成立；第 566-567 行将负数传入 _read_fixed_body，而第 576 行 `while content_length > 0` 立即结束。
- 修复建议：在解析后增加 `if content_length < 0: raise httputil.HTTPInputError("Negative Content-Length")`，或使用 `int(...)` 后统一校验范围。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
543: 
544:             try:
545:                 content_length = int(headers["Content-Length"])
546:             except ValueError:
547:                 # Handles non-integer Content-Length value.
548:                 raise httputil.HTTPInputError(
549:                     "Only integer Content-Length is allowed: %s" % headers["Content-Length"])
550: 
551:             if content_length > self._max_body_size:
```

### [低] 重复 Content-Length 比较使用字符串而非数值，可能接受不等价的值

- 位置：`tornado/http1connection.py:533`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 538 行用字符串比较 `i != pieces[0]` 判断多个 Content-Length 是否一致。像 "5" 与 "05" 或 "5 " 这类数值相等但字符串不同的值会被判为不等而报错（较安全）；但反过来，若代理合并出 "5,5" 与 "5, 5" 等，split 后仍可能通过。更关键的是，比较在 int 转换之前，若存在前导零等差异会误报错误，属于健壮性问题。
- 触发条件：Content-Length 头包含多个值且格式存在空白/前导零差异，例如 "5, 05"。
- 依据：第 537 行 `pieces = re.split(r',\s*', headers["Content-Length"])`，第 538 行 `if any(i != pieces[0] for i in pieces)` 为纯字符串比较，未先转为整数。
- 修复建议：先对每个 piece 做 int 转换并校验非负，再比较数值是否一致，最后统一赋值。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
531:                 raise httputil.HTTPInputError(
532:                     "Response with both Transfer-Encoding and Content-Length")
533:             if "," in headers["Content-Length"]:
534:                 # Proxies sometimes cause Content-Length headers to get
535:                 # duplicated.  If all the values are identical then we can
536:                 # use them but if they differ it's an error.
537:                 pieces = re.split(r',\s*', headers["Content-Length"])
538:                 if any(i != pieces[0] for i in pieces):
539:                     raise httputil.HTTPInputError(
540:                         "Multiple unequal Content-Lengths: %r" %
541:                         headers["Content-Length"])
542:                 headers["Content-Length"] = pieces[0]
543: 
544:             try:
```

### [中] Transfer-Encoding 仅精确匹配 "chunked"，大小写或带参数时被忽略

- 位置：`tornado/http1connection.py:568`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 568 行使用 `headers.get("Transfer-Encoding") == "chunked"` 精确比较。HTTP 头值大小写不敏感，且可能为 "Chunked"、"chunked, identity" 或带其他参数。若值不是精确的 "chunked"，则不会进入分块读取；对于服务端（is_client 为 False）会返回 None，导致请求体被当作无 body 处理，剩余字节留在流中，可能被误解析为下一个请求，造成请求走私风险。
- 触发条件：对端发送 `Transfer-Encoding: Chunked` 或 `Transfer-Encoding: chunked, identity` 等非精确小写值。
- 依据：第 568 行 `if headers.get("Transfer-Encoding") == "chunked":` 为大小写敏感的精确字符串比较，未做 lower() 或 token 解析。
- 修复建议：对 Transfer-Encoding 值做 lower() 并按逗号拆分 token，判断是否包含 "chunked"；同时按 RFC 7230 处理不支持的编码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
566:         if content_length is not None:
567:             return self._read_fixed_body(content_length, delegate)
568:         if headers.get("Transfer-Encoding") == "chunked":
569:             return self._read_chunked_body(delegate)
570:         if self.is_client:
571:             return self._read_body_until_close(delegate)
```

### [低] 204 响应校验未覆盖 1xx 与 304 等无 body 状态码

- 位置：`tornado/http1connection.py:556`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 556 行仅对 code == 204 做无 body 校验。HTTP 规范中 1xx、204、304 均不得包含消息体。若收到 304 且带 Content-Length 或 Transfer-Encoding，代码会按正常 body 读取，可能阻塞等待不存在的 body 或错误消费后续数据。
- 触发条件：收到状态码 304（或 1xx）且带 Content-Length/Transfer-Encoding 的响应。
- 依据：第 556 行 `if code == 204:` 只处理 204；第 560-564 行仅在该分支内校验并置 content_length = 0。
- 修复建议：将条件扩展为 `if code == 204 or code == 304 or 100 <= code < 200:`，并按规范拒绝带 body 的此类响应。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
554:             content_length = None
555: 
556:         if code == 204:
557:             # This response code is not allowed to have a non-empty body,
558:             # and has an implicit length of zero instead of read-until-close.
559:             # http://www.w3.org/Protocols/rfc2616/rfc2616-sec4.html#sec4.3
560:             if ("Transfer-Encoding" in headers or
561:                     content_length not in (None, 0)):
562:                 raise httputil.HTTPInputError(
563:                     "Response with code %d should not have body" % code)
564:             content_length = 0
565: 
566:         if content_length is not None:
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/http1connection.py | not_requested | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 182, "sensitive_file": 1, "benchmark_tests_hidden": 49}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
