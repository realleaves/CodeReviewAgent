import unittest
from youtube_dl.utils import base_url


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # 'http://example.com' 无路径斜杠，不匹配 r'https?://[^?#&]+/'
        # re.match 返回 None，None.group() 触发 AttributeError
        try:
            result = base_url('http://example.com')
        except AttributeError:
            self.fail('base_url raised AttributeError on non-matching URL')
        self.assertIsNone(result)
