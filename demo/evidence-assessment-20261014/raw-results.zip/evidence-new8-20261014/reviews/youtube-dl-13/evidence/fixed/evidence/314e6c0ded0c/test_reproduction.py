import unittest
from youtube_dl.utils import base_url


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        with self.assertRaises(AttributeError):
            base_url('ftp://example.com/a/b')
