# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`ecd8968c5135b810cd607b5902dda2cd32122b39`
- 状态：**completed**；模式：direct；模型：deepseek-flash
- 完成语义审查：0/69 个已索引 Python 文件
- 调用：2；耗时：17.905 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- 本报告是静态分析及模型推断；外部容器复现证据由评测程序另行保存。

## 候选问题（9）

### [中] ETag 头检查使用大小写敏感的 "Etag" 键，可能重复设置 ETag

- 位置：`tornado/web.py:972`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：代码通过 `"Etag" not in self._headers` 判断是否已存在 ETag 头。但 HTTP 头名称是大小写不敏感的，Tornado 的 `set_header` 会以调用者传入的原始大小写存储键（内部使用 `HTTPHeaders`，其 `__contains__` 对字符串键是大小写敏感的）。如果应用或框架已经通过 `set_header("ETag", ...)` 或 `set_header("etag", ...)` 设置了 ETag，这里的检查不会命中，于是会再次调用 `set_etag_header()` 覆盖或追加 ETag 头，导致重复/冲突的 ETag 头，破坏缓存语义。
- 触发条件：应用在 finish() 之前调用 `self.set_header("ETag", ...)`（非 "Etag" 拼写），随后 finish() 执行到该判断。
- 依据：第 972 行 `"Etag" not in self._headers` 使用固定大小写字符串作为键；Tornado 的 HTTPHeaders 对字符串键大小写敏感，而 HTTP 规范要求头名大小写不敏感。
- 修复建议：使用大小写不敏感的检查，例如 `"Etag" not in self._headers` 改为遍历 `self._headers` 的键做 lower() 比较，或使用 `self._headers.get("Etag")` 前先规范化；更稳妥的是调用 `self.clear_header("ETag")` 后再设置，或统一使用 `set_header` 的规范化键。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
970:             if (self._status_code == 200 and
971:                 self.request.method in ("GET", "HEAD") and
972:                     "Etag" not in self._headers):
973:                 self.set_etag_header()
974:                 if self.check_etag_header():
```

### [中] Content-Length 按字节长度计算，但 write_buffer 可能包含非字节对象

- 位置：`tornado/web.py:981`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 981 行 `sum(len(part) for part in self._write_buffer)` 假设缓冲区中每个元素都是 bytes/str 且 `len()` 返回字节数。若 `write()` 被传入非 bytes 对象（例如某些自定义对象或 memoryview 之外的类型），`len()` 可能返回元素个数而非字节数，导致 Content-Length 与实际发送字节数不一致，造成响应截断或挂起。此外，若缓冲区包含 str（Python 3 下 Tornado 通常要求 bytes），len 返回字符数而非字节数，多字节字符会算错。
- 触发条件：在 finish() 之前调用 `self.write()` 传入非 bytes 类型（如 str 或自定义对象），且尚未 flush。
- 依据：第 981 行直接对 `self._write_buffer` 元素调用 `len()`，未做类型转换或字节化处理。
- 修复建议：在计算前确保每个 part 为 bytes，例如 `sum(len(part) if isinstance(part, bytes) else len(part.encode('utf-8')) for part in self._write_buffer)`，或在 write() 入口强制转换为 bytes。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
979:                 self._clear_headers_for_304()
980:             elif "Content-Length" not in self._headers:
981:                 content_length = sum(len(part) for part in self._write_buffer)
982:                 self.set_header("Content-Length", content_length)
983: 
984:         if hasattr(self.request, "connection"):
```

### [低] 204/304 响应断言在优化模式下被移除，可能发送非法 body

- 位置：`tornado/web.py:977`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 978 行使用 `assert not self._write_buffer` 来保证 204/304 响应不带 body。Python 以 -O 运行时 assert 被移除，此时若缓冲区非空，代码会继续执行 `_clear_headers_for_304()` 并最终 flush，可能向客户端发送带 body 的 204/304 响应，违反 HTTP 规范。
- 触发条件：以 `python -O` 运行，且状态码为 204/304 时 `_write_buffer` 非空。
- 依据：第 978 行 `assert not self._write_buffer, ...` 依赖 assert 做运行时校验。
- 修复建议：改为显式条件判断并抛出异常或清空缓冲区，例如 `if self._write_buffer: raise RuntimeError(...)` 或 `self._write_buffer = []`。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
975:                     self._write_buffer = []
976:                     self.set_status(304)
977:             if self._status_code in (204, 304):
978:                 assert not self._write_buffer, "Cannot send body with %s" % self._status_code
979:                 self._clear_headers_for_304()
980:             elif "Content-Length" not in self._headers:
981:                 content_length = sum(len(part) for part in self._write_buffer)
```

### [低] set_close_callback(None) 可能覆盖连接上已有的关闭回调

- 位置：`tornado/web.py:989`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 989 行在 finish 时无条件将 `request.connection` 的 close callback 置为 None。如果该连接上还有其他组件（如 WebSocket 升级、流式处理或自定义连接逻辑）注册了关闭回调，这里会将其清除，导致资源清理逻辑丢失。虽然注释说明是为了避免 keepalive 连接阻止 GC，但直接置 None 会破坏其他回调。
- 触发条件：在同一个 HTTPConnection 上，除 RequestHandler 外还有代码通过 `set_close_callback` 注册了回调，且该请求正常 finish。
- 依据：第 989 行 `self.request.connection.set_close_callback(None)` 无条件覆盖。
- 修复建议：仅清除本 handler 注册的回调，或使用更细粒度的清理机制（如保存并恢复原回调，或使用弱引用回调）。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
987:             # garbage collection of the RequestHandler when there
988:             # are keepalive connections)
989:             self.request.connection.set_close_callback(None)
990: 
991:         self.flush(include_footers=True)
```

### [低] check_etag_header 命中后未清除 Content-Length 相关头，可能残留旧头

- 位置：`tornado/web.py:974`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：当 ETag 匹配时，第 975-976 行清空 `_write_buffer` 并设置状态码 304。但此时尚未进入第 977 行的 204/304 分支（因为状态码在 970 行判断时还是 200，之后才被改为 304），因此 `_clear_headers_for_304()` 不会被调用。若之前已设置 Content-Type、Content-Length 等头，304 响应可能携带不应有的实体头，违反规范。
- 触发条件：请求带 If-None-Match 且匹配，状态码原为 200，finish() 时 ETag 检查命中。
- 依据：第 970 行条件基于 `self._status_code == 200`，第 976 行才改为 304；第 977 行的 `if self._status_code in (204, 304)` 在本次执行中不会为真，因为该判断在 976 行之前已求值（顺序上 977 在 976 之后，但 977 是独立 if，会重新读取状态码——实际上 977 在 976 之后执行，会看到 304）。
- 修复建议：确认 304 分支确实会执行 `_clear_headers_for_304()`；若不会，需在设置 304 后显式调用清理。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
972:                     "Etag" not in self._headers):
973:                 self.set_etag_header()
974:                 if self.check_etag_header():
975:                     self._write_buffer = []
976:                     self.set_status(304)
977:             if self._status_code in (204, 304):
978:                 assert not self._write_buffer, "Cannot send body with %s" % self._status_code
```

### [中] check_origin 在缺少 Host 头时可能被绕过

- 位置：`tornado/websocket.py:409`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：check_origin 通过比较 Origin 的 netloc 与请求的 Host 头来判断来源。如果请求中缺少 Host 头，self.request.headers.get("Host") 返回 None，而 origin 是字符串。当 origin 也为空字符串时（例如 Origin 头缺失或为畸形值导致 netloc 为空），origin == host 可能成立（'' == None 为 False，但若 Host 头存在为空字符串则 '' == '' 为 True），从而可能放行非预期来源。更关键的是，该方法完全依赖 Host 头，而 Host 头可被客户端伪造，在反向代理未严格校验 Host 的场景下，攻击者可通过同时伪造 Origin 与 Host 使二者相等，绕过同源检查，导致跨站 WebSocket 劫持（CSWSH）。
- 触发条件：客户端发起 WebSocket 握手时同时设置 Origin 与 Host 为相同值（例如都设为 attacker.com），且服务端未在代理层强制校验 Host。
- 依据：第 405-412 行：parsed_origin = urlparse(origin); origin = parsed_origin.netloc; origin = origin.lower(); host = self.request.headers.get("Host"); return origin == host。比较仅基于客户端可控的 Origin 与 Host 头。
- 修复建议：不要仅依赖 Host 头进行同源判断。应基于服务端配置的可信域名列表（如 self.settings 或应用配置）进行校验，或在文档中明确要求部署时在反向代理层校验 Host 头。同时处理 Host 为 None 的情况，避免空值比较。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
407:         origin = origin.lower()
408: 
409:         host = self.request.headers.get("Host")
410: 
411:         # Check to see that origin matches host directly, including ports
412:         return origin == host
413: 
414:     def set_nodelay(self, value):
```

### [中] get_websocket_protocol 对不支持的版本静默返回 None

- 位置：`tornado/websocket.py:448`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：get_websocket_protocol 仅在 Sec-WebSocket-Version 为 "7"、"8" 或 "13" 时返回协议对象，其他情况（包括缺失该头、版本为 "0" 或未来版本）会隐式返回 None。调用方若未对 None 做处理，可能在后续使用该返回值时抛出 AttributeError 或导致握手流程异常，而不是返回明确的 400/426 错误响应。
- 触发条件：客户端发送 Sec-WebSocket-Version 为不支持的值（如 "9"）或完全缺失该头时调用 get_websocket_protocol。
- 依据：第 449-452 行：websocket_version = self.request.headers.get("Sec-WebSocket-Version"); if websocket_version in ("7", "8", "13"): return WebSocketProtocol13(...)。无 else 分支，函数在未匹配时返回 None。
- 修复建议：在未匹配到支持的版本时显式抛出 HTTPError(400) 或返回 426 Upgrade Required 并附带 Sec-WebSocket-Version 响应头，避免调用方拿到 None。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
446:             self.stream.close()
447: 
448:     def get_websocket_protocol(self):
449:         websocket_version = self.request.headers.get("Sec-WebSocket-Version")
450:         if websocket_version in ("7", "8", "13"):
451:             return WebSocketProtocol13(
452:                 self, compression_options=self.get_compression_options())
453: 
454:     def _attach_stream(self):
```

### [低] _attach_stream 通过实例属性覆盖方法，可能影响子类与调试

- 位置：`tornado/websocket.py:454`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：_attach_stream 使用 setattr 将 write、redirect、set_header 等方法替换为 _raise_not_supported_for_websockets，直接修改实例属性。这会遮蔽类方法，导致子类中重写这些方法的行为被忽略，也使调试和静态分析难以追踪实际调用目标。此外，若在 _attach_stream 之前已调用过这些方法，行为不一致。
- 触发条件：子类重写了 write/finish 等方法，或在 _attach_stream 调用后依赖这些方法的正常语义。
- 依据：第 458-460 行：for method in ["write", "redirect", "set_header", "set_cookie", "set_status", "flush", "finish"]: setattr(self, method, _raise_not_supported_for_websockets)。
- 修复建议：考虑在类层面通过显式方法定义或使用 __getattr__ 拦截，或在文档中说明该行为；至少确保子类重写不会被静默忽略。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
452:                 self, compression_options=self.get_compression_options())
453: 
454:     def _attach_stream(self):
455:         self.stream = self.request.connection.detach()
456:         self.stream.set_close_callback(self.on_connection_close)
457:         # disable non-WS methods
458:         for method in ["write", "redirect", "set_header", "set_cookie",
459:                        "set_status", "flush", "finish"]:
460:             setattr(self, method, _raise_not_supported_for_websockets)
461: 
462: 
```

### [低] on_connection_close 可能重复触发 on_close 的边界

- 位置：`tornado/websocket.py:430`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：on_connection_close 先调用 ws_connection.on_connection_close() 并将 ws_connection 置为 None，然后通过 _on_close_called 标志确保 on_close 只调用一次。逻辑本身有保护，但若 ws_connection.on_connection_close() 内部抛出异常，则 self.ws_connection = None 与 on_close 调用都不会执行，_on_close_called 保持 False，可能导致资源未清理或 on_close 永不触发。
- 触发条件：ws_connection.on_connection_close() 在执行过程中抛出异常。
- 依据：第 431-436 行：if self.ws_connection: self.ws_connection.on_connection_close(); self.ws_connection = None; if not self._on_close_called: ... on_close()。异常会跳过后续清理。
- 修复建议：使用 try/finally 确保 ws_connection 置空与 on_close 调用在异常情况下仍能执行，或捕获并记录异常。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
428:         self.stream.set_nodelay(value)
429: 
430:     def on_connection_close(self):
431:         if self.ws_connection:
432:             self.ws_connection.on_connection_close()
433:             self.ws_connection = None
434:         if not self._on_close_called:
435:             self._on_close_called = True
436:             self.on_close()
437: 
438:     def send_error(self, *args, **kwargs):
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/web.py | not_requested | window_completed | 1/1 |
| tornado/websocket.py | not_requested | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 185, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
