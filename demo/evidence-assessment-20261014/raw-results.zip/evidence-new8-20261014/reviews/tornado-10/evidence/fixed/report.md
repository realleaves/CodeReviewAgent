# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`ecd8968c5135b810cd607b5902dda2cd32122b39`
- 状态：**completed**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/69 个已索引 Python 文件
- 调用：2；耗时：2.242 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/web.py:978`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
976:                     self.set_status(304)
977:             if self._status_code in (204, 304):
978:                 assert not self._write_buffer, "Cannot send body with %s" % self._status_code
979:                 self._clear_headers_for_304()
980:             elif "Content-Length" not in self._headers:
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/web.py | completed | window_completed | 1/1 |
| tornado/websocket.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 185, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
