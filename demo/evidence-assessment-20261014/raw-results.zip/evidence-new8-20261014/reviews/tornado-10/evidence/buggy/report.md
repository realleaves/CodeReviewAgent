# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`ecd8968c5135b810cd607b5902dda2cd32122b39`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/69 个已索引 Python 文件
- 调用：9；耗时：17.756 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] finish() 中 204/304 断言在 -O 下被移除，可能发送非法响应体

- 位置：`tornado/web.py:978`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 978 行使用 assert 校验 204/304 响应不得携带 body。Python 以 -O 运行时 assert 被剥离，此时若 _write_buffer 非空，代码会继续执行 _clear_headers_for_304() 并 flush，从而向客户端发送带 body 的 204/304 响应，违反 HTTP 规范。该断言是唯一阻止此非法状态输出的检查。
- 触发条件：以 python -O 运行；处理器先 write() 写入内容（未 flush），随后 set_status(204) 并调用 finish()，此时 _headers_written 为 False 且 _write_buffer 非空。
- 依据：第 977-979 行：if self._status_code in (204, 304): assert not self._write_buffer, ...; self._clear_headers_for_304()。断言被 -O 移除后无其他校验。
- 修复建议：将断言替换为显式运行时检查，例如 if self._write_buffer: raise RuntimeError(...)，以保证在优化模式下仍能阻止非法响应体。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
976:                     self.set_status(304)
977:             if self._status_code in (204, 304):
978:                 assert not self._write_buffer, "Cannot send body with %s" % self._status_code
979:                 self._clear_headers_for_304()
980:             elif "Content-Length" not in self._headers:
```

- 复现状态：unsupported
- 证据说明：候选缺陷依赖以 python -O 运行（剥离 assert）才能触发，而当前测试环境为 python:3.7-slim 默认解释器，无法在标准 unittest 中可靠地模拟 -O 优化模式；同时断言被剥离属于解释器运行模式差异，无法在单进程测试内构造有效输入来验证。此外，该断言本身是 Tornado 有意的防御性检查，其行为在正常（非 -O）模式下符合预期，缺少可定位的契约文档或测试来证明 -O 下必须抛出异常。因此无法构造最小行为复现。

[运行证据](evidence/1ef9feb3fcf1/evidence.json)

### [低] ETag 自动生成检查使用 'Etag' 而非规范大小写，可能覆盖用户设置的 ETag

- 位置：`tornado/web.py:972`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第 972 行以字符串 'Etag' 判断用户是否已设置 ETag 头。HTTP 头名大小写不敏感，但 _headers 字典的键是区分大小写的。若用户通过 set_header('ETag', ...) 或 set_header('etag', ...) 设置，则 'Etag' not in self._headers 为真，代码会调用 set_etag_header() 覆盖用户显式设置的 ETag，导致用户设置被静默丢弃。
- 触发条件：处理器中调用 self.set_header('ETag', '"abc"')，随后 finish() 且状态码为 200、方法为 GET/HEAD。
- 依据：第 970-973 行：if (self._status_code == 200 and self.request.method in ('GET','HEAD') and 'Etag' not in self._headers): self.set_etag_header()。set_header 直接以传入 name 作为字典键（第 339 行 self._headers[name] = ...）。
- 修复建议：使用大小写不敏感的检查，例如 any(k.lower() == 'etag' for k in self._headers)，或统一头名规范化后再判断。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
970:             if (self._status_code == 200 and
971:                 self.request.method in ("GET", "HEAD") and
972:                     "Etag" not in self._headers):
973:                 self.set_etag_header()
974:                 if self.check_etag_header():
```

- 复现状态：not_reproduced
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/e3438c0130fe/evidence.json)

复现测试：

```python
import unittest
from tornado.httputil import HTTPHeaders


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        headers = HTTPHeaders()
        headers['ETag'] = '"abc"'
        self.assertIn('Etag', headers)
        self.assertIn('etag', headers)
        self.assertIn('ETAG', headers)
        headers2 = HTTPHeaders()
        headers2['etag'] = '"xyz"'
        self.assertIn('Etag', headers2)

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `not_reproduced`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 0, "skipped": 0, "load_error": null, "observations": [], "target_lines": [], "target_calls": []}

```

### [低] B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.

- 位置：`tornado/web.py:978`
- 来源：bandit B101
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 触发条件：触发条件需结合业务调用确认。
- 依据：bandit B101: Use of assert detected. The enclosed code will be removed when compiling to optimised byte code.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
976:                     self.set_status(304)
977:             if self._status_code in (204, 304):
978:                 assert not self._write_buffer, "Cannot send body with %s" % self._status_code
979:                 self._clear_headers_for_304()
980:             elif "Content-Length" not in self._headers:
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/web.py | completed | window_completed | 1/1 |
| tornado/websocket.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 185, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
