import unittest
from tornado.httputil import HTTPHeaders


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        headers = HTTPHeaders()
        headers['ETag'] = '"abc"'
        self.assertIn('Etag', headers)
        self.assertIn('etag', headers)
        self.assertIn('ETAG', headers)
        headers2 = HTTPHeaders()
        headers2['etag'] = '"xyz"'
        self.assertIn('Etag', headers2)
