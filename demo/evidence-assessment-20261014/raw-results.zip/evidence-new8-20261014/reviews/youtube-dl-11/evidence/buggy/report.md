# GitHub 仓库代码审查报告

- 仓库：https://github.com/ytdl-org/youtube-dl
- 分支：blinded-snapshot
- Commit：`b568561eba6f4aceb87419e21aba11567c5de7da`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/822 个已索引 Python 文件
- 调用：7；耗时：17.456 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] str_to_int 对非字符串输入抛出 TypeError 而非返回 None

- 位置：`youtube_dl/utils.py:3520`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：str_to_int 的契约（docstring 称其为 int_or_none 的宽松版本）暗示对无法解析的输入应返回 None。但实现只处理了 int_str is None 的情况，随后直接调用 re.sub(r'[,\.\+]', '', int_str)。当传入非字符串（如 int、float、list）时，re.sub 会抛出 TypeError: expected string or bytes-like object，而不是返回 None。调用方若依赖宽松解析语义，会因未捕获异常而崩溃。
- 触发条件：调用 str_to_int(123) 或 str_to_int(1.5) 或 str_to_int(['1'])
- 依据：第 3522-3524 行：仅判断 `if int_str is None: return None`，之后 `int_str = re.sub(r'[,\.\+]', '', int_str)` 未做类型检查，非字符串输入会触发 re.sub 的 TypeError。
- 修复建议：在 re.sub 前增加类型检查，例如 `if not isinstance(int_str, compat_str): return None`，或捕获 TypeError 返回 None。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
3518: 
3519: 
3520: def str_to_int(int_str):
3521:     """ A more relaxed version of int_or_none """
3522:     if int_str is None:
3523:         return None
3524:     int_str = re.sub(r'[,\.\+]', '', int_str)
3525:     return int(int_str)
3526: 
3527: 
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 str_to_int 对非字符串输入应返回 None，但唯一可定位的契约是 docstring 'A more relaxed version of int_or_none'。该描述并未规定非字符串输入（int/float/list）必须返回 None；int_or_none 本身对非字符串数字（如 int）是能成功解析的，因此'更宽松'并不蕴含对 int 输入返回 None。所有实际调用方（adobetv、appleconnect、camdemy、cloudy 等）传入的都是正则匹配得到的字符串或 None，没有证据表明存在依赖非字符串输入返回 None 的约定。缺少明确契约，无法构造有来源依据的复现测试，故 applicable=false。

[运行证据](evidence/1f94bb5c2092/evidence.json)

### [低] int_or_none 对布尔值 True/False 返回 1/0 而非 default

- 位置：`youtube_dl/utils.py:3502`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：int_or_none 用于从元数据中提取整数。当 v 为布尔值时，int(True)=1、int(False)=0，函数返回 1/0 而非 default。若调用方传入布尔标志（如某些 JSON 字段可能为 true/false），会得到意外的整数结果而非 None。
- 触发条件：int_or_none(True) 返回 1；int_or_none(False) 返回 0
- 依据：第 3510-3511 行 `return int(v) * invscale // scale`，Python 中 int(True)==1、int(False)==0，未排除 bool 类型。
- 修复建议：若布尔值不应被当作整数，增加 `if isinstance(v, bool): return default`。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
3500: 
3501: 
3502: def int_or_none(v, scale=1, default=None, get_attr=None, invscale=1):
3503:     if get_attr:
3504:         if v is not None:
3505:             v = getattr(v, get_attr, None)
3506:     if v == '':
3507:         v = None
3508:     if v is None:
3509:         return default
3510:     try:
3511:         return int(v) * invscale // scale
3512:     except (ValueError, TypeError):
3513:         return default
3514: 
3515: 
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 int_or_none 对布尔值 True/False 应返回 default 而非 1/0，但没有任何可定位的契约支持这一期望。函数名与实现语义是“将可转换为整数的值转为整数，否则返回 default”，Python 语言规则明确 int(True)==1、int(False)==0，因此返回 1/0 是符合语言规则与函数语义的行为，而非 bug。仓库中也没有文档或测试声明布尔值应被特殊处理为 default。相反，同文件中的 bool_or_none 专门用于布尔值处理，说明 int_or_none 并不承担该职责。缺少约定时不能凭空要求对布尔输入返回 default，故不构造复现测试。

[运行证据](evidence/b4a2ea4f37f2/evidence.json)

### [低] url_or_none 对仅含空白的字符串返回 None 但未处理 strip 后为空的情况

- 位置：`youtube_dl/utils.py:3545`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：url_or_none 先检查 `not url`，再 strip。若输入为纯空白字符串（如 '   '），`not url` 为 False（非空字符串），strip 后变为空字符串，随后 re.match 对空字符串不匹配，返回 None。行为正确但依赖正则不匹配空串。若输入为 '  //example.com'，strip 后为 '//example.com'，正则 `^(?:[a-zA-Z][\da-zA-Z.+-]*:)?//` 匹配，返回 '//example.com'，这是协议相对 URL，符合预期。无明显缺陷。
- 触发条件：url_or_none('   ') 返回 None（正确）
- 依据：第 3546-3549 行逻辑对空白输入返回 None，行为符合预期，不构成缺陷。
- 修复建议：无需修改。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
3543: 
3544: 
3545: def url_or_none(url):
3546:     if not url or not isinstance(url, compat_str):
3547:         return None
3548:     url = url.strip()
3549:     return url if re.match(r'^(?:[a-zA-Z][\da-zA-Z.+-]*:)?//', url) else None
3550: 
3551: 
```

- 复现状态：unsupported
- 证据说明：候选缺陷自身结论为“无明显缺陷/行为符合预期”，未指出任何与契约相悖的实际错误。url_or_none 对纯空白字符串返回 None 是合理行为，且没有文档或测试约定要求其他返回值；对 '  //example.com' 返回 '//example.com' 也符合协议相对 URL 的预期。因此不存在可复现的真实 bug，无法构造会因真实缺陷而失败的测试。

[运行证据](evidence/a9d812286810/evidence.json)

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/utils.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 73, "sensitive_file": 1, "benchmark_tests_hidden": 31}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
