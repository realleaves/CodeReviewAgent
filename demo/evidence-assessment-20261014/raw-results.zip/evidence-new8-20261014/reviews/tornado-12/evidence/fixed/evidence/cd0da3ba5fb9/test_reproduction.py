import unittest
from tornado.auth import FacebookGraphMixin, AuthError
from tornado.concurrent import Future


class _FakeResponse(object):
    def __init__(self, body, error=None):
        self.body = body
        self.error = error

    def __str__(self):
        return "FakeResponse(body=%r, error=%r)" % (self.body, self.error)


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        mixin = FacebookGraphMixin()
        future = Future()
        response = _FakeResponse(body="error=invalid_request")
        try:
            mixin._on_access_token(
                "/auth/facebookgraph/", "client_id", "client_secret",
                future, set(["id"]), response)
        except KeyError:
            self.fail("缺少 access_token 时抛出了 KeyError，而非通过 future 传递 AuthError")
        self.assertTrue(future.done(), "future 应已完成")
        self.assertIsInstance(future.exception(), AuthError)
