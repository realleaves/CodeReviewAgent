# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`4ee9ba94de11aaa4f932560fa2b3d8ceb8c61d2a`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/63 个已索引 Python 文件
- 调用：11；耗时：20.31 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] 缺少 access_token 时 KeyError 而非 AuthError

- 位置：`tornado/auth.py:990`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：_on_access_token 在 response.error 为假时直接访问 args["access_token"]。当 Facebook 返回 HTTP 200 但 body 中不含 access_token（例如返回错误 JSON 或空 body）时，parse_qs 结果中无该键，会抛出 KeyError，而不是通过 future.set_exception 传递 AuthError。这会使异常逃逸出回调，future 永不完成，调用方挂起或收到未处理异常。
- 触发条件：response.error 为 None/False，response.body 为不含 access_token 的字符串（如空字符串或 'error=xxx'）。
- 依据：第 988-990 行：args = urlparse.parse_qs(...); session = {"access_token": args["access_token"][-1], ...}，未做键存在性检查。
- 修复建议：在访问前检查 'access_token' in args，缺失时 future.set_exception(AuthError(...)) 并 return。
- 验证方式：测试必须有且仅有一个 ReproductionTest。

```python
988:         args = urlparse.parse_qs(escape.native_str(response.body))
989:         session = {
990:             "access_token": args["access_token"][-1],
991:             "expires": args.get("expires")
992:         }
```

- 复现状态：invalid_plan
- 证据说明：测试必须有且仅有一个 ReproductionTest。

[运行证据](evidence/cd0da3ba5fb9/evidence.json)

复现测试：

```python
import unittest
from tornado.auth import FacebookGraphMixin, AuthError
from tornado.concurrent import Future


class _FakeResponse(object):
    def __init__(self, body, error=None):
        self.body = body
        self.error = error

    def __str__(self):
        return "FakeResponse(body=%r, error=%r)" % (self.body, self.error)


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        mixin = FacebookGraphMixin()
        future = Future()
        response = _FakeResponse(body="error=invalid_request")
        try:
            mixin._on_access_token(
                "/auth/facebookgraph/", "client_id", "client_secret",
                future, set(["id"]), response)
        except KeyError:
            self.fail("缺少 access_token 时抛出了 KeyError，而非通过 future 传递 AuthError")
        self.assertTrue(future.done(), "future 应已完成")
        self.assertIsInstance(future.exception(), AuthError)

```

### [低] fields 为 set，join 顺序不确定

- 位置：`tornado/auth.py:999`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：fields 是 set（第 973 行），第 999 行 ",".join(fields) 生成的字段顺序不确定。虽然 Facebook API 通常不依赖顺序，但结果不可复现，且若下游对请求参数做签名/缓存会不稳定。
- 触发条件：每次调用 get_authenticated_user 时 fields 集合迭代顺序可能不同。
- 依据：第 973 行 fields = set([...])；第 999 行 fields=",".join(fields)。
- 修复建议：使用有序结构（如 list 或 sorted(fields)）以保证确定性。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
997:                 self._on_get_user_info, future, session, fields),
998:             access_token=session["access_token"],
999:             fields=",".join(fields)
1000:         )
1001: 
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 set 迭代顺序不确定导致 ",".join(fields) 结果不可复现。但该行为没有可定位的契约要求：文档（get_authenticated_user 的 docstring）未规定 fields 参数的顺序，Facebook Graph API 的 fields 参数语义为无序集合，且 _on_get_user_info 使用 fields 仅做成员遍历构造 dict，不依赖顺序。代码中 set 的迭代顺序在单次进程内对同一集合是稳定的，且 Python 3.7 中字符串哈希随机化（PYTHONHASHSEED）默认开启，但这是语言实现细节而非对返回值顺序的契约。没有文档、测试或语言规则规定 join 结果必须有序，因此无法构造一个断言'正确行为'的复现测试——任何断言顺序的测试都只是断言实现细节，而非契约。此外，get_authenticated_user 是异步方法，需要 mock HTTP 客户端与 OAuth 流程才能触发 _on_access_token，构造有效输入成本高且无契约支撑。故 applicable=false。

[运行证据](evidence/8071d7804e86/evidence.json)

### [低] B018: Found useless expression. Either assign it to a variable or remove it.

- 位置：`tornado/auth.py:98`
- 来源：ruff B018
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Found useless expression. Either assign it to a variable or remove it.
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B018: Found useless expression. Either assign it to a variable or remove it.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
96: 
97: try:
98:     long  # py2
99: except NameError:
100:     long = int  # py3
```

### [中] B006: Do not use mutable data structures for argument defaults

- 位置：`tornado/auth.py:1074`
- 来源：ruff B006
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Do not use mutable data structures for argument defaults
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B006: Do not use mutable data structures for argument defaults
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1072: 
1073: 
1074: def _oauth_signature(consumer_token, method, url, parameters={}, token=None):
1075:     """Calculates the HMAC-SHA1 OAuth signature for the given request.
1076: 
```

### [中] B006: Do not use mutable data structures for argument defaults

- 位置：`tornado/auth.py:1098`
- 来源：ruff B006
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Do not use mutable data structures for argument defaults
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B006: Do not use mutable data structures for argument defaults
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1096: 
1097: 
1098: def _oauth10a_signature(consumer_token, method, url, parameters={}, token=None):
1099:     """Calculates the HMAC-SHA1 OAuth 1.0a signature for the given request.
1100: 
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/auth.py | completed | window_completed | 3/3 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 177, "sensitive_file": 1, "benchmark_tests_hidden": 47}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
