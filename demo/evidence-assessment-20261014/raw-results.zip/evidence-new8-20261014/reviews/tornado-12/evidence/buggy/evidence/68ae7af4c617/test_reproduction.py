import unittest
from tornado.auth import FacebookGraphMixin
from tornado.concurrent import Future


class _FakeResponse(object):
    def __init__(self, body):
        self.body = body
        self.error = None


class _FakeMixin(FacebookGraphMixin):
    def __init__(self):
        self.captured = None

    def facebook_request(self, path, callback, access_token=None, **kwargs):
        self.captured = {
            "path": path,
            "access_token": access_token,
            "callback": callback,
        }


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        mixin = _FakeMixin()
        future = Future()
        body = "access_token=xxx&expires=5100000"
        mixin._on_access_token(
            redirect_uri="/auth/facebookgraph/",
            client_id="cid",
            client_secret="secret",
            future=future,
            fields=set(["id"]),
            response=_FakeResponse(body),
        )
        self.assertIsNotNone(mixin.captured)
        self.assertEqual(mixin.captured["access_token"], "xxx")
        session = mixin.captured["callback"].keywords["session"]
        self.assertEqual(session["access_token"], "xxx")
        self.assertEqual(session["expires"], "5100000")
