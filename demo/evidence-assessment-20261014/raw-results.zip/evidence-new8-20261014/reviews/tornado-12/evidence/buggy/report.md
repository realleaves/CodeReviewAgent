# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`4ee9ba94de11aaa4f932560fa2b3d8ceb8c61d2a`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/63 个已索引 Python 文件
- 调用：13；耗时：30.269 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] 缺少 access_token 时 KeyError 导致回调异常而非 AuthError

- 位置：`tornado/auth.py:990`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：_on_access_token 在 response.error 为假时直接以 args["access_token"] 取值。若 Facebook 返回 200 但 body 中不含 access_token（例如返回错误 JSON 或空 body），parse_qs_bytes 得到的字典没有该键，会抛出 KeyError。该异常发生在 http.fetch 的回调中，不会通过 future.set_exception 传递，而是以未捕获异常形式冒泡，调用方无法按 AuthError 契约处理。
- 触发条件：Facebook 返回 HTTP 200 且 body 不含 access_token 参数（如 body 为 'error=...' 或空字符串）。
- 依据：988: args = escape.parse_qs_bytes(escape.native_str(response.body))
989: session = {
990:     "access_token": args["access_token"][-1],
- 修复建议：使用 args.get("access_token") 并在缺失时 future.set_exception(AuthError(...)) 后 return，与 response.error 分支保持一致的错误处理。
- 验证方式：测试必须有且仅有一个 ReproductionTest。

```python
988:         args = escape.parse_qs_bytes(escape.native_str(response.body))
989:         session = {
990:             "access_token": args["access_token"][-1],
991:             "expires": args.get("expires")
992:         }
```

- 复现状态：invalid_plan
- 证据说明：测试必须有且仅有一个 ReproductionTest。

[运行证据](evidence/871f4f45fdfa/evidence.json)

复现测试：

```python
import unittest
from tornado.auth import FacebookGraphMixin, AuthError
from tornado.concurrent import Future


class _FakeResponse(object):
    def __init__(self, body, error=None):
        self.body = body
        self.error = error


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        mixin = FacebookGraphMixin()
        future = Future()
        response = _FakeResponse(b"error=invalid_code")
        try:
            mixin._on_access_token(
                redirect_uri='/auth/facebookgraph/',
                client_id='cid',
                client_secret='secret',
                future=future,
                fields=set(['id']),
                response=response)
        except KeyError:
            self.fail("missing access_token raised KeyError instead of AuthError")
        self.assertTrue(future.done())
        self.assertIsInstance(future.exception(), AuthError)

```

### [低] expires 取值为列表而非标量

- 位置：`tornado/auth.py:991`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：args 由 parse_qs_bytes 返回，其值是列表。access_token 用 [-1] 取了标量，但 expires 用 args.get("expires") 直接取，得到的是列表（如 ['5100000']）而非字符串。该列表随后被存入 session 并最终作为 session_expires 返回给用户，类型与 access_token 不一致，可能破坏依赖该字段为字符串的调用方。
- 触发条件：Facebook 响应包含 expires 参数，例如 body='access_token=xxx&expires=5100000'。
- 依据：990: "access_token": args["access_token"][-1],
991: "expires": args.get("expires")
- 修复建议：改为 args.get("expires", [None])[-1] 或对 expires 同样取最后一个元素，保持标量类型。
- 验证方式：测试必须有且仅有一个 ReproductionTest。

```python
989:         session = {
990:             "access_token": args["access_token"][-1],
991:             "expires": args.get("expires")
992:         }
993: 
```

- 复现状态：invalid_plan
- 证据说明：测试必须有且仅有一个 ReproductionTest。

[运行证据](evidence/68ae7af4c617/evidence.json)

复现测试：

```python
import unittest
from tornado.auth import FacebookGraphMixin
from tornado.concurrent import Future


class _FakeResponse(object):
    def __init__(self, body):
        self.body = body
        self.error = None


class _FakeMixin(FacebookGraphMixin):
    def __init__(self):
        self.captured = None

    def facebook_request(self, path, callback, access_token=None, **kwargs):
        self.captured = {
            "path": path,
            "access_token": access_token,
            "callback": callback,
        }


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        mixin = _FakeMixin()
        future = Future()
        body = "access_token=xxx&expires=5100000"
        mixin._on_access_token(
            redirect_uri="/auth/facebookgraph/",
            client_id="cid",
            client_secret="secret",
            future=future,
            fields=set(["id"]),
            response=_FakeResponse(body),
        )
        self.assertIsNotNone(mixin.captured)
        self.assertEqual(mixin.captured["access_token"], "xxx")
        session = mixin.captured["callback"].keywords["session"]
        self.assertEqual(session["access_token"], "xxx")
        self.assertEqual(session["expires"], "5100000")

```

### [低] B018: Found useless expression. Either assign it to a variable or remove it.

- 位置：`tornado/auth.py:98`
- 来源：ruff B018
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Found useless expression. Either assign it to a variable or remove it.
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B018: Found useless expression. Either assign it to a variable or remove it.
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
96: 
97: try:
98:     long  # py2
99: except NameError:
100:     long = int  # py3
```

### [中] B006: Do not use mutable data structures for argument defaults

- 位置：`tornado/auth.py:1069`
- 来源：ruff B006
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Do not use mutable data structures for argument defaults
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B006: Do not use mutable data structures for argument defaults
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1067: 
1068: 
1069: def _oauth_signature(consumer_token, method, url, parameters={}, token=None):
1070:     """Calculates the HMAC-SHA1 OAuth signature for the given request.
1071: 
```

### [中] B006: Do not use mutable data structures for argument defaults

- 位置：`tornado/auth.py:1093`
- 来源：ruff B006
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Do not use mutable data structures for argument defaults
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B006: Do not use mutable data structures for argument defaults
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1091: 
1092: 
1093: def _oauth10a_signature(consumer_token, method, url, parameters={}, token=None):
1094:     """Calculates the HMAC-SHA1 OAuth 1.0a signature for the given request.
1095: 
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/auth.py | completed | window_completed | 3/3 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 177, "sensitive_file": 1, "benchmark_tests_hidden": 47}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
