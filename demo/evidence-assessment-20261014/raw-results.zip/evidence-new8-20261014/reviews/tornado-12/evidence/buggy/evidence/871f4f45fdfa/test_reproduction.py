import unittest
from tornado.auth import FacebookGraphMixin, AuthError
from tornado.concurrent import Future


class _FakeResponse(object):
    def __init__(self, body, error=None):
        self.body = body
        self.error = error


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        mixin = FacebookGraphMixin()
        future = Future()
        response = _FakeResponse(b"error=invalid_code")
        try:
            mixin._on_access_token(
                redirect_uri='/auth/facebookgraph/',
                client_id='cid',
                client_secret='secret',
                future=future,
                fields=set(['id']),
                response=response)
        except KeyError:
            self.fail("missing access_token raised KeyError instead of AuthError")
        self.assertTrue(future.done())
        self.assertIsInstance(future.exception(), AuthError)
