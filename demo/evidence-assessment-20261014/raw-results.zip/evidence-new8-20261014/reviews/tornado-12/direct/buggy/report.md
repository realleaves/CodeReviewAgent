# GitHub 仓库代码审查报告

- 仓库：https://github.com/tornadoweb/tornado
- 分支：blinded-snapshot
- Commit：`4ee9ba94de11aaa4f932560fa2b3d8ceb8c61d2a`
- 状态：**completed**；模式：direct；模型：deepseek-flash
- 完成语义审查：0/63 个已索引 Python 文件
- 调用：3；耗时：14.041 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- 本报告是静态分析及模型推断；外部容器复现证据由评测程序另行保存。

## 候选问题（8）

### [中] 缺少 access_token 时抛出未处理的 KeyError

- 位置：`tornado/auth.py:990`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 990 行直接使用 args["access_token"][-1] 访问解析后的查询参数。当 Facebook 返回的响应体不包含 access_token（例如返回错误信息、空 body 或格式异常的响应）时，会抛出 KeyError，而不是通过 future.set_exception 传递一个可处理的 AuthError。由于 _on_access_token 是 http.fetch 的回调，异常不会被 future 捕获，可能导致请求挂起或异常被吞掉，调用方无法得到明确错误。
- 触发条件：Facebook OAuth 端点返回的响应体缺少 access_token 参数（如返回错误页面、空响应或非预期格式）时触发。
- 依据：第 988-992 行：args = escape.parse_qs_bytes(...); session = {"access_token": args["access_token"][-1], ...}。args 是普通 dict，缺失键会抛 KeyError，且该异常未被 try/except 或 future.set_exception 处理。
- 修复建议：在访问前检查 args 是否包含 access_token，例如使用 args.get("access_token") 并在缺失时调用 future.set_exception(AuthError(...)) 后返回，避免未捕获异常。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
988:         args = escape.parse_qs_bytes(escape.native_str(response.body))
989:         session = {
990:             "access_token": args["access_token"][-1],
991:             "expires": args.get("expires")
992:         }
```

### [低] expires 字段未转换为整数

- 位置：`tornado/auth.py:991`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 991 行将 args.get("expires") 直接存入 session，其值是 parse_qs_bytes 返回的列表（如 [b'3600']），而非整数或字符串。后续若使用 session["expires"] 进行时间计算或比较，会因类型不符而出错。
- 触发条件：Facebook 返回 expires 参数时，session["expires"] 为列表类型，任何期望数值的后续处理都会失败。
- 依据：第 988 行 parse_qs_bytes 返回 dict[str, list[bytes]]；第 991 行 args.get("expires") 返回列表，未做 [-1] 或 int() 转换。
- 修复建议：使用 args.get("expires", [None])[-1] 并转换为 int，或明确处理缺失情况。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
989:         session = {
990:             "access_token": args["access_token"][-1],
991:             "expires": args.get("expires")
992:         }
993: 
```

### [低] fields 参数可能包含空字符串导致请求异常

- 位置：`tornado/auth.py:999`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：第 999 行使用 ",".join(fields) 构造 fields 查询参数。如果 fields 集合为空，join 结果为空字符串，Facebook API 可能拒绝该请求或返回非预期结果。虽然调用方通常传入非空 fields，但代码未做防御。
- 触发条件：调用 _on_access_token 时 fields 为空集合。
- 依据：第 999 行：fields=",".join(fields)，未检查 fields 是否为空。
- 修复建议：在 join 前检查 fields 是否非空，或仅在非空时传递 fields 参数。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
997:                 self._on_get_user_info, future, session, fields),
998:             access_token=session["access_token"],
999:             fields=",".join(fields)
1000:         )
1001: 
```

### [中] OAuth 签名参数未对键名进行转义

- 位置：`tornado/auth.py:1081`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：在 _oauth_signature 中，参数拼接使用 "%s=%s" % (k, _oauth_escape(str(v)))，只对值 v 做了 _oauth_escape，键名 k 未做转义。OAuth 1.0 规范要求参数名和参数值都必须进行百分号编码后再排序拼接。若参数名包含特殊字符（如 '!'、'*'、'('、')' 等），生成的 base string 将不符合规范，导致签名校验失败。
- 触发条件：当 parameters 中存在包含需转义字符的键名时（例如自定义参数名含 '!' 或空格），生成的签名与服务器端计算不一致，OAuth 请求被拒绝。
- 依据：1081: base_elems.append("&".join("%s=%s" % (k, _oauth_escape(str(v)))\n1082: for k, v in sorted(parameters.items()))) —— 键 k 直接使用，未调用 _oauth_escape。
- 修复建议：改为 "%s=%s" % (_oauth_escape(str(k)), _oauth_escape(str(v)))，确保键名也按 OAuth 规范进行百分号编码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1079:     base_elems.append(method.upper())
1080:     base_elems.append(normalized_url)
1081:     base_elems.append("&".join("%s=%s" % (k, _oauth_escape(str(v)))
1082:                                for k, v in sorted(parameters.items())))
1083:     base_string = "&".join(_oauth_escape(e) for e in base_elems)
1084: 
```

### [低] 参数排序基于未转义的原始键名

- 位置：`tornado/auth.py:1082`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：OAuth 1.0 规范要求参数先按编码后的名称排序，再按编码后的值排序。此处 sorted(parameters.items()) 按原始键名排序，若键名包含需转义字符，排序顺序可能与规范要求不一致，导致 base string 与服务器端不同。
- 触发条件：当参数键名包含需转义字符且排序结果受转义影响时，签名计算顺序与服务器不一致，签名校验失败。
- 依据：1082: for k, v in sorted(parameters.items()) —— 排序使用原始键名而非 _oauth_escape 后的键名。
- 修复建议：先对键值对进行转义，再按转义后的键名（及值）排序，例如 sorted((_oauth_escape(str(k)), _oauth_escape(str(v))) for k, v in parameters.items())。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1080:     base_elems.append(normalized_url)
1081:     base_elems.append("&".join("%s=%s" % (k, _oauth_escape(str(v)))
1082:                                for k, v in sorted(parameters.items())))
1083:     base_string = "&".join(_oauth_escape(e) for e in base_elems)
1084: 
```

### [中] OAuth 1.0 签名密钥未对 secret 进行百分号编码

- 位置：`tornado/auth.py:1085`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：_oauth_signature 中 key_elems 直接使用 escape.utf8(consumer_token["secret"]) 和 token["secret"]，未做百分号编码。而 _oauth10a_signature（1109-1110 行）对 secret 使用了 urllib_parse.quote(..., safe='~')。OAuth 1.0 规范要求签名密钥中的 consumer secret 和 token secret 必须经过百分号编码。若 secret 含特殊字符，1.0 签名将不正确。
- 触发条件：当 consumer_token["secret"] 或 token["secret"] 包含需百分号编码的字符（如 '+'、'/'、'=' 等）时，_oauth_signature 生成的签名与服务器端不一致。
- 依据：1085: key_elems = [escape.utf8(consumer_token["secret"])]\n1086: key_elems.append(escape.utf8(token["secret"] if token else "")) —— 未调用 quote/_oauth_escape；对比 1109-1110 行使用了 urllib_parse.quote。
- 修复建议：对 secret 使用与 _oauth10a_signature 相同的编码方式，例如 escape.utf8(urllib_parse.quote(consumer_token["secret"], safe='~'))。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1083:     base_string = "&".join(_oauth_escape(e) for e in base_elems)
1084: 
1085:     key_elems = [escape.utf8(consumer_token["secret"])]
1086:     key_elems.append(escape.utf8(token["secret"] if token else ""))
1087:     key = b"&".join(key_elems)
1088: 
```

### [低] 可变默认参数 parameters={}

- 位置：`tornado/auth.py:1069`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：_oauth_signature 和 _oauth10a_signature 使用可变对象 {} 作为默认参数。虽然当前实现只读取 parameters 未修改它，但这是 Python 中易导致 bug 的反模式，若后续代码修改该字典，会在多次调用间共享状态。
- 触发条件：若未来在函数体内对 parameters 进行原地修改（如 parameters.update(...)），默认参数会在调用间累积，导致签名错误。
- 依据：1069: def _oauth_signature(consumer_token, method, url, parameters={}, token=None):\n1093: def _oauth10a_signature(consumer_token, method, url, parameters={}, token=None):
- 修复建议：将默认值改为 None，并在函数体内 parameters = parameters or {}。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1067: 
1068: 
1069: def _oauth_signature(consumer_token, method, url, parameters={}, token=None):
1070:     """Calculates the HMAC-SHA1 OAuth signature for the given request.
1071: 
```

### [低] 签名返回 bytes 而非 str

- 位置：`tornado/auth.py:1090`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：_oauth_signature 和 _oauth10a_signature 返回 binascii.b2a_base64(hash.digest())[:-1]，这是 bytes 类型。在 Python 3 中，若调用方期望字符串（例如拼接到 Authorization 头或 URL 查询字符串），会引发 TypeError 或产生 b'...' 字面量。需确认调用方是否做了 decode 处理。
- 触发条件：在 Python 3 环境下，调用方直接将返回值用于字符串拼接或格式化时，会得到 bytes 表示或抛出 TypeError。
- 依据：1090: return binascii.b2a_base64(hash.digest())[:-1]\n1114: return binascii.b2a_base64(hash.digest())[:-1] —— 返回 bytes。
- 修复建议：确认调用方是否 decode；若需要字符串，返回 binascii.b2a_base64(hash.digest())[:-1].decode("ascii")。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1088: 
1089:     hash = hmac.new(key, escape.utf8(base_string), hashlib.sha1)
1090:     return binascii.b2a_base64(hash.digest())[:-1]
1091: 
1092: 
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/auth.py | not_requested | window_completed | 3/3 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 177, "sensitive_file": 1, "benchmark_tests_hidden": 47}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
