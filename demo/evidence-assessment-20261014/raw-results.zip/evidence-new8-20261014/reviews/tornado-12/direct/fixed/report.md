# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`4ee9ba94de11aaa4f932560fa2b3d8ceb8c61d2a`
- 状态：**completed**；模式：direct；模型：deepseek-flash
- 完成语义审查：0/63 个已索引 Python 文件
- 调用：3；耗时：12.985 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- 本报告是静态分析及模型推断；外部容器复现证据由评测程序另行保存。

## 候选问题（9）

### [中] OAuth 回调解析缺少错误响应校验，可能抛出 KeyError

- 位置：`tornado/auth.py:988`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Facebook 的 access_token 交换接口在失败时（例如 code 无效、redirect_uri 不匹配、应用被禁用）会返回 HTTP 200 但 body 为 `error=...&error_description=...` 或 JSON 错误体，而不是 `access_token=...`。此处仅检查 `response.error`（HTTP 层错误），随后直接访问 `args["access_token"]`，一旦响应体中没有 access_token 键就会抛出未捕获的 KeyError，导致 future 永远不会被设置，回调挂起或产生 500 错误。
- 触发条件：Facebook 返回不含 access_token 的响应体（如 `error=invalid_code` 或 JSON 错误对象）时，`args["access_token"]` 触发 KeyError。
- 依据：第 988 行 `args = urlparse.parse_qs(escape.native_str(response.body))`，第 990 行 `"access_token": args["access_token"][-1]` 使用下标访问而非 `.get()`，且第 984-986 行只处理了 `response.error`。
- 修复建议：在解析后检查 `"access_token" in args`，缺失时调用 `future.set_exception(AuthError(...))` 并 return；同时可解析 `error`/`error_description` 字段以提供更明确的错误信息。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
986:             return
987: 
988:         args = urlparse.parse_qs(escape.native_str(response.body))
989:         session = {
990:             "access_token": args["access_token"][-1],
991:             "expires": args.get("expires")
992:         }
993: 
994:         self.facebook_request(
```

### [低] expires 字段未转换为整数，类型不一致

- 位置：`tornado/auth.py:991`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：`args.get("expires")` 返回的是 parse_qs 产生的字符串列表（如 `['5184000']`），而非整数。session 中 access_token 取了 `[-1]` 得到字符串，但 expires 保留了整个列表，导致 session 结构不一致，后续若用 expires 做时间计算会出错。
- 触发条件：任何成功回调都会使 session['expires'] 为列表而非标量。
- 依据：第 990 行 `args["access_token"][-1]` 取了最后一个元素，而第 991 行 `args.get("expires")` 未做同样处理。
- 修复建议：改为 `args.get("expires", [None])[-1]` 或显式转换为 int，保持 session 字段类型一致。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
989:         session = {
990:             "access_token": args["access_token"][-1],
991:             "expires": args.get("expires")
992:         }
993: 
```

### [低] fields 拼接未做 URL 编码，特殊字符可能破坏请求

- 位置：`tornado/auth.py:999`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：`",".join(fields)` 直接作为 fields 查询参数传给 facebook_request，若字段名包含逗号以外的特殊字符（如空格、&、=）不会被转义，可能改变请求语义或导致 Graph API 解析错误。
- 触发条件：extra_fields 中包含需要 URL 编码的字符时。
- 依据：第 999 行 `fields=",".join(fields)` 未经过 urlencode/quote。
- 修复建议：使用 `urllib.parse.urlencode` 或对拼接结果做 quote 后再传入。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
997:                 self._on_get_user_info, future, session, fields),
998:             access_token=session["access_token"],
999:             fields=",".join(fields)
1000:         )
1001: 
```

### [中] 可变默认参数 parameters={}

- 位置：`tornado/auth.py:1074`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：_oauth_signature 使用可变字典作为默认参数。虽然当前函数体只读取 parameters 而未修改它，但这是 Python 中典型的危险模式，一旦后续代码或调用方误改该默认对象，会在多次调用间共享状态，导致签名计算错误。
- 触发条件：任何调用 _oauth_signature 时省略 parameters 参数，且函数体（或未来修改）对该字典进行写入操作。
- 依据：def _oauth_signature(consumer_token, method, url, parameters={}, token=None):
- 修复建议：将默认值改为 None，并在函数体内 parameters = parameters or {} 进行初始化。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1072: 
1073: 
1074: def _oauth_signature(consumer_token, method, url, parameters={}, token=None):
1075:     """Calculates the HMAC-SHA1 OAuth signature for the given request.
1076: 
```

### [中] _oauth10a_signature 同样使用可变默认参数

- 位置：`tornado/auth.py:1098`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：_oauth10a_signature 与 _oauth_signature 一样使用 parameters={} 作为默认参数，存在相同的共享可变状态风险。
- 触发条件：调用 _oauth10a_signature 时省略 parameters，且后续对默认字典发生写入。
- 依据：def _oauth10a_signature(consumer_token, method, url, parameters={}, token=None):
- 修复建议：将默认值改为 None，并在函数体内 parameters = parameters or {}。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1096: 
1097: 
1098: def _oauth10a_signature(consumer_token, method, url, parameters={}, token=None):
1099:     """Calculates the HMAC-SHA1 OAuth 1.0a signature for the given request.
1100: 
```

### [中] OAuth 1.0 签名参数未按 RFC 排序/编码

- 位置：`tornado/auth.py:1086`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：OAuth 1.0 规范要求签名基串中的参数先按编码后的键排序，再按编码后的值排序。此处仅对原始键 sorted(parameters.items()) 排序，且键 k 未做 _oauth_escape 编码，值也未先编码再排序。当参数键包含需要转义的字符或存在同名键时，生成的签名基串可能与服务端不一致，导致签名验证失败。
- 触发条件：请求参数键包含特殊字符（如空格、&、=）或存在需要按编码后值排序的多个参数时。
- 依据：base_elems.append("&".join("%s=%s" % (k, _oauth_escape(str(v))) for k, v in sorted(parameters.items())))
- 修复建议：按 OAuth 规范先对键和值分别进行 _oauth_escape，再按编码后的键（及值）排序后拼接。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1084:     base_elems.append(method.upper())
1085:     base_elems.append(normalized_url)
1086:     base_elems.append("&".join("%s=%s" % (k, _oauth_escape(str(v)))
1087:                                for k, v in sorted(parameters.items())))
1088:     base_string = "&".join(_oauth_escape(e) for e in base_elems)
1089: 
```

### [中] OAuth 1.0a 签名参数排序与编码不符合规范

- 位置：`tornado/auth.py:1110`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：与 _oauth_signature 相同，_oauth10a_signature 在构造签名基串时未对参数键进行 _oauth_escape 编码，也未按编码后的键/值排序，可能导致与服务端计算出的签名不一致。
- 触发条件：参数键包含需转义字符或需要按编码后值排序时。
- 依据：base_elems.append("&".join("%s=%s" % (k, _oauth_escape(str(v))) for k, v in sorted(parameters.items())))
- 修复建议：先对键和值进行 _oauth_escape，再按编码后的键（及值）排序拼接。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1108:     base_elems.append(method.upper())
1109:     base_elems.append(normalized_url)
1110:     base_elems.append("&".join("%s=%s" % (k, _oauth_escape(str(v)))
1111:                                for k, v in sorted(parameters.items())))
1112: 
1113:     base_string = "&".join(_oauth_escape(e) for e in base_elems)
```

### [低] 签名返回 bytes 而非 str

- 位置：`tornado/auth.py:1095`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：binascii.b2a_base64 返回 bytes，切片后仍为 bytes。OAuth 签名通常需要作为字符串放入 Authorization 头或查询参数。若调用方期望 str，可能导致类型错误或需要额外解码。
- 触发条件：调用方将返回值直接用于字符串拼接或 HTTP 头设置时。
- 依据：return binascii.b2a_base64(hash.digest())[:-1]
- 修复建议：明确返回类型，例如 return binascii.b2a_base64(hash.digest())[:-1].decode('ascii')，并同步更新调用方。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1093: 
1094:     hash = hmac.new(key, escape.utf8(base_string), hashlib.sha1)
1095:     return binascii.b2a_base64(hash.digest())[:-1]
1096: 
1097: 
```

### [低] _oauth10a_signature 返回 bytes 而非 str

- 位置：`tornado/auth.py:1119`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：与 _oauth_signature 相同，_oauth10a_signature 返回 bytes 类型的 base64 签名，可能与调用方对字符串的期望不符。
- 触发条件：调用方将返回值用于字符串上下文时。
- 依据：return binascii.b2a_base64(hash.digest())[:-1]
- 修复建议：解码为 ASCII 字符串后再返回，或明确文档化返回类型。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1117: 
1118:     hash = hmac.new(key, escape.utf8(base_string), hashlib.sha1)
1119:     return binascii.b2a_base64(hash.digest())[:-1]
1120: 
1121: 
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/auth.py | not_requested | window_completed | 3/3 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 177, "sensitive_file": 1, "benchmark_tests_hidden": 47}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
