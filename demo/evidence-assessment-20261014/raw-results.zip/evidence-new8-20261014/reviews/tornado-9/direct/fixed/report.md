# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`c9d2a3fa573987629ad576e991c2f3b65f4daab4`
- 状态：**completed**；模式：direct；模型：deepseek-flash
- 完成语义审查：0/69 个已索引 Python 文件
- 调用：1；耗时：10.566 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- 本报告是静态分析及模型推断；外部容器复现证据由评测程序另行保存。

## 候选问题（3）

### [中] url_concat 对 dict 参数使用 items() 会丢失多值键

- 位置：`tornado/httputil.py:611`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：当 args 为 dict 时，代码使用 args.items() 扩展查询参数。dict 本身无法表示同一键的多个值，因此调用方若传入 dict 且期望多值语义会静默丢失数据。文档明确说明 list 才支持多值，但 dict 分支与 list 分支行为不一致，且没有对值做类型校验（例如值为 list 时 urlencode 会将其字符串化）。
- 触发条件：调用 url_concat(url, {'a': ['1', '2']}) 或依赖 dict 表达重复键时，最终查询串会变成 a=%5B%271%27%2C+%272%27%5D 而非 a=1&a=2。
- 依据：第 609-611 行：if isinstance(args, dict): parsed_query.extend(args.items())，未对值做展开或校验。
- 修复建议：在 dict 分支中对值为 list/tuple 的项展开为多个键值对，或明确文档化并校验值类型，避免静默产生错误查询串。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
609:     if isinstance(args, dict):
610:         parsed_query = parse_qsl(parsed_url.query, keep_blank_values=True)
611:         parsed_query.extend(args.items())
612:     elif isinstance(args, list) or isinstance(args, tuple):
613:         parsed_query = parse_qsl(parsed_url.query, keep_blank_values=True)
```

### [低] url_concat 使用 urlencode 默认 quote_plus 会改变已有查询串编码

- 位置：`tornado/httputil.py:619`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：parse_qsl 解码已有查询参数后，urlencode 默认使用 quote_plus 重新编码。这会把原有查询串中的 %20 变为 +、把某些保留字符重新编码，导致 url_concat 对已编码 URL 不是幂等的，可能改变服务端解析结果。
- 触发条件：url_concat('http://example.com/?a=b%20c', {'d': 'e'}) 返回 'http://example.com/?a=b+c&d=e'，空格编码被改变。
- 依据：第 610、613 行 parse_qsl 解码，第 619 行 urlencode(parsed_query) 默认 quote_plus=True 重新编码。
- 修复建议：如需保持原编码，可考虑使用 quote_via=quote 或对已有查询串做更保守的处理；至少在文档中说明该行为。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
617:             type(args))
618:         raise TypeError(err)
619:     final_query = urlencode(parsed_query)
620:     url = urlunparse((
621:         parsed_url[0],
```

### [低] url_concat 对 list/tuple 元素未做结构校验

- 位置：`tornado/httputil.py:612`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：list/tuple 分支直接 extend(args)，若元素不是二元组（如传入 ['a', 'b'] 或 [(1,2,3)]），urlencode 会抛出难以理解的异常或产生意外结果，错误信息不指向调用方参数问题。
- 触发条件：url_concat('http://example.com/', ['a', 'b']) 会在 urlencode 阶段抛出 ValueError/TypeError，而非清晰的参数错误。
- 依据：第 612-614 行仅判断容器类型，未校验每个元素是否为长度为 2 的序列。
- 修复建议：在 extend 前校验每个元素为二元组，或捕获 urlencode 异常并抛出带参数说明的 TypeError。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
610:         parsed_query = parse_qsl(parsed_url.query, keep_blank_values=True)
611:         parsed_query.extend(args.items())
612:     elif isinstance(args, list) or isinstance(args, tuple):
613:         parsed_query = parse_qsl(parsed_url.query, keep_blank_values=True)
614:         parsed_query.extend(args)
615:     else:
616:         err = "'args' parameter should be dict, list or tuple. Not {0}".format(
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| tornado/httputil.py | not_requested | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 185, "sensitive_file": 1, "benchmark_tests_hidden": 50}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
