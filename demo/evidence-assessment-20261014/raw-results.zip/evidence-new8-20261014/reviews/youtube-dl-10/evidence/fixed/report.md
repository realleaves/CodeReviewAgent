# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`85d586617750d38d742a24f141b099f6b898d269`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/497 个已索引 Python 文件
- 调用：7；耗时：19.448 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] js_to_json 单引号字符串转义处理错误：反斜杠被重复转义

- 位置：`youtube_dl/utils.py:1555`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：fix_kv 中处理单引号字符串时，先 v = v[1:-1] 去掉首尾引号，然后用 re.sub 对 v 做替换。替换字典中 '\\\\' 映射到 '\\\\'（即两个反斜杠映射为两个反斜杠），而 "\\'" 映射为 "'"，'"' 映射为 '\\"'。问题在于正则 r"\\\\|\\'|\"" 匹配的是「两个反斜杠」或「反斜杠+单引号」或「双引号」。对于 JS 单引号字符串中的单个反斜杠转义（如 \\n、\\t、\\/ 等），正则不会匹配单个反斜杠，因此这些转义序列被原样保留，但随后整个字符串被包进双引号，导致 \\n 等被当作字面反斜杠+n 而非换行。更严重的是，当输入包含 \\\\（JS 中表示一个反斜杠）时，正则匹配两个反斜杠并替换为两个反斜杠，结果 JSON 中仍是两个反斜杠，解析后得到两个反斜杠而非一个，语义错误。
- 触发条件：调用 js_to_json("'a\\\\b'")（JS 源码中单引号字符串含转义反斜杠），期望解析出单个反斜杠。
- 依据：第1555-1559行替换字典：'\\\\': '\\\\' 将匹配到的两个反斜杠替换为两个反斜杠，未做反转义；正则 r"\\\\|\\'|\"" 只覆盖双反斜杠、反斜杠单引号、双引号三种情况，遗漏 \\n \\t \\/ 等常见转义。
- 修复建议：应使用更完整的 JS 字符串反转义逻辑（如逐个处理转义序列），或至少将 '\\\\' 映射为 '\\'（单个反斜杠）以正确反转义。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
1553:         if v.startswith("'"):
1554:             v = v[1:-1]
1555:             v = re.sub(r"\\\\|\\'|\"", lambda m: {
1556:                 '\\\\': '\\\\',
1557:                 "\\'": "'",
1558:                 '"': '\\"',
1559:             }[m.group(0)], v)
1560:         return '"%s"' % v
1561: 
```

- 复现状态：not_reproduced
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/1b068241bc37/evidence.json)

复现测试：

```python
import json
import unittest

from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # JS 源码: 'a\\b'  (单引号字符串，含转义反斜杠，表示单个反斜杠)
        js_source = "'a\\\\b'"
        result = js_to_json(js_source)
        parsed = json.loads(result)
        self.assertEqual(parsed, 'a\\b')

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `not_reproduced`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 0, "skipped": 0, "load_error": null, "observations": [], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 54, 57, 58, 59, 60, 61, 66, 67, 70, 85, 139, 140, 162, 174, 188, 193, 216, 233, 268, 277, 312, 321, 341, 350, 378, 387, 397, 406, 431, 432, 434, 460, 466, 467, 473, 474, 475, 478, 484, 486, 492, 497, 498, 501, 506, 508, 512, 513, 514, 517, 522, 523, 526, 532, 534, 535, 537, 542, 564, 580, 582, 586, 591, 598, 606, 624, 653, 654, 657, 658, 663, 674, 700, 762, 772, 776, 805, 815, 816, 818, 831, 836, 842, 846, 856, 931, 953, 962, 969, 1024, 1026, 1029, 1033, 1034, 1039, 1048, 1054, 1057, 1060, 1064, 1069, 1080, 1089, 1097, 1106, 1120, 1174, 1190, 1199, 1209, 1217, 1232, 1238, 1244, 1249, 1250, 1254, 1263, 1267, 1275, 1279, 1320, 1325, 1335, 1336, 1350, 1361, 1362, 1367, 1368, 1372, 1410, 1411, 1416, 1439, 1447, 1454, 1464, 1465, 1478, 1479, 1482, 1498, 1502, 1503, 1508, 1526, 1527, 1528, 1529, 1530, 1534, 1541, 1546, 1547, 1548, 1549, 1551, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1562, 1566, 1567, 1568, 1571, 1581, 1584, 1594, 1598, 1607, 1614, 1619, 1637, 1647, 1667, 1689, 1697, 1756, 1763], "target_calls": [["<lambda>", 1555], ["<module>", 4], ["ContentTooShortError", 526], ["DateRange", 815], ["DownloadError", 478], ["ExtractorError", 431], ["HEADRequest", 1249], ["InAdvancePagedList", 1410], ["MaxDownloadsReached", 512], ["OnDemandPagedList", 1367], ["PagedList", 1361], ["PostProcessingError", 501], ["RegexNotFoundError", 473], ["SameFileError", 492], ["UnavailableVideoError", 517], ["UnsupportedError", 466], ["YoutubeDLHTTPSHandler", 657], ["YoutubeDLHandler", 564], ["fix_kv", 1547], ["js_to_json", 1546], ["locked_file", 1033]]}

```

### [低] js_to_json 去除尾随逗号的正则仅处理数组，遗漏对象

- 位置：`youtube_dl/utils.py:1567`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第1567行 re.sub(r',(\s*\])', ...) 只匹配逗号后跟空白再跟 ] 的情况，用于移除数组尾随逗号。但 JS 对象同样允许尾随逗号（如 {a:1,}），该正则不处理 } 前的尾随逗号，导致生成的 JSON 含尾随逗号而解析失败。
- 触发条件：js_to_json('{a: 1,}') 或含对象尾随逗号的 JS 片段。
- 依据：第1567行正则仅含 \]，无 \} 分支。
- 修复建议：将正则扩展为同时匹配 ] 和 }，例如 r',(\s*[\]}])'。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
1565:         [a-zA-Z_][.a-zA-Z_0-9]*
1566:         ''', fix_kv, code)
1567:     res = re.sub(r',(\s*\])', lambda m: m.group(1), res)
1568:     return res
1569: 
```

- 复现状态：unrelated_failure
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/4fb7761f6647/evidence.json)

复现测试：

```python
import json
import unittest

from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        result = js_to_json('{a: 1,}')
        parsed = json.loads(result)
        self.assertEqual(parsed, {'a': 1})

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `unrelated_failure`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "JSONDecodeError", "message": "Expecting property name enclosed in double quotes: line 1 column 9 (char 8)", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 10, in test_reproduction\n    parsed = json.loads(result)\n  File \"/usr/local/lib/python3.7/json/__init__.py\", line 348, in loads\n    return _default_decoder.decode(s)\n  File \"/usr/local/lib/python3.7/json/decoder.py\", line 337, in decode\n    obj, end = self.raw_decode(s, idx=_w(s, 0).end())\n  File \"/usr/local/lib/python3.7/json/decoder.py\", line 353, in raw_decode\n    obj, end = self.scan_once(s, idx)\njson.decoder.JSONDecodeError: Expecting property name enclosed in double quotes: line 1 column 9 (char 8)\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 54, 57, 58, 59, 60, 61, 66, 67, 70, 85, 139, 140, 162, 174, 188, 193, 216, 233, 268, 277, 312, 321, 341, 350, 378, 387, 397, 406, 431, 432, 434, 460, 466, 467, 473, 474, 475, 478, 484, 486, 492, 497, 498, 501, 506, 508, 512, 513, 514, 517, 522, 523, 526, 532, 534, 535, 537, 542, 564, 580, 582, 586, 591, 598, 606, 624, 653, 654, 657, 658, 663, 674, 700, 762, 772, 776, 805, 815, 816, 818, 831, 836, 842, 846, 856, 931, 953, 962, 969, 1024, 1026, 1029, 1033, 1034, 1039, 1048, 1054, 1057, 1060, 1064, 1069, 1080, 1089, 1097, 1106, 1120, 1174, 1190, 1199, 1209, 1217, 1232, 1238, 1244, 1249, 1250, 1254, 1263, 1267, 1275, 1279, 1320, 1325, 1335, 1336, 1350, 1361, 1362, 1367, 1368, 1372, 1410, 1411, 1416, 1439, 1447, 1454, 1464, 1465, 1478, 1479, 1482, 1498, 1502, 1503, 1508, 1526, 1527, 1528, 1529, 1530, 1534, 1541, 1546, 1547, 1548, 1549, 1551, 1553, 1560, 1562, 1566, 1567, 1568, 1571, 1581, 1584, 1594, 1598, 1607, 1614, 1619, 1637, 1647, 1667, 1689, 1697, 1756, 1763], "target_calls": [["<module>", 4], ["ContentTooShortError", 526], ["DateRange", 815], ["DownloadError", 478], ["ExtractorError", 431], ["HEADRequest", 1249], ["InAdvancePagedList", 1410], ["MaxDownloadsReached", 512], ["OnDemandPagedList", 1367], ["PagedList", 1361], ["PostProcessingError", 501], ["RegexNotFoundError", 473], ["SameFileError", 492], ["UnavailableVideoError", 517], ["UnsupportedError", 466], ["YoutubeDLHTTPSHandler", 657], ["YoutubeDLHandler", 564], ["fix_kv", 1547], ["js_to_json", 1546], ["locked_file", 1033]]}

```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/utils.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 44, "sensitive_file": 1, "benchmark_tests_hidden": 20}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
