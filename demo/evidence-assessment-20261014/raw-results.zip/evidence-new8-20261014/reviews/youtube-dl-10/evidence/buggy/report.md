# GitHub 仓库代码审查报告

- 仓库：https://github.com/ytdl-org/youtube-dl
- 分支：blinded-snapshot
- Commit：`85d586617750d38d742a24f141b099f6b898d269`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/497 个已索引 Python 文件
- 调用：7；耗时：18.309 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] js_to_json 单引号字符串转义处理错误：反斜杠转义被破坏

- 位置：`youtube_dl/utils.py:1555`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：fix_kv 处理单引号字符串时，先 v = v[1:-1] 去掉首尾引号，然后用 re.sub(r"\\\\|\\'|\"", ...) 做替换。该正则匹配的是两个反斜杠、反斜杠+单引号、或双引号。映射表中 '\\\\' 映射为 '\\\\'（即两个反斜杠映射为两个反斜杠），并未把 JS 中的转义反斜杠还原为单个反斜杠。对于 JS 源码中的单引号字符串如 'a\\b'（JS 中表示 a\b），转换后得到 "a\\b"，JSON 解析后为 a\b，而 JS 语义应为 a\b（单个反斜杠）。即反斜杠被重复保留，导致字符串内容与 JS 实际值不一致。
- 触发条件：调用 js_to_json("'a\\\\b'")（源码中单引号字符串含转义反斜杠），随后 json.loads 结果。
- 依据：第1555-1559行映射 {'\\\\': '\\\\'} 将匹配到的双反斜杠原样返回，未做单反斜杠还原；第1554行已剥离引号。
- 修复建议：将映射改为把 '\\\\' 还原为 '\\'（单个反斜杠），并确保正则与替换逻辑一致地处理 JS 转义序列。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
1553:         if v.startswith("'"):
1554:             v = v[1:-1]
1555:             v = re.sub(r"\\\\|\\'|\"", lambda m: {
1556:                 '\\\\': '\\\\',
1557:                 "\\'": "'",
1558:                 '"': '\\"',
1559:             }[m.group(0)], v)
1560:         return '"%s"' % v
1561: 
```

- 复现状态：not_reproduced
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/aa6fad22fe66/evidence.json)

复现测试：

```python
import json
import unittest

from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # JS 源码: 'a\\b' 表示字符串 a\b（单个反斜杠）
        js_source = "'a\\\\b'"
        result = js_to_json(js_source)
        parsed = json.loads(result)
        self.assertEqual(parsed, 'a\\b')

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `not_reproduced`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 0, "skipped": 0, "load_error": null, "observations": [], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 54, 57, 58, 59, 60, 61, 66, 67, 70, 85, 139, 140, 162, 174, 188, 193, 216, 233, 268, 277, 312, 321, 341, 350, 378, 387, 397, 406, 431, 432, 434, 460, 466, 467, 473, 474, 475, 478, 484, 486, 492, 497, 498, 501, 506, 508, 512, 513, 514, 517, 522, 523, 526, 532, 534, 535, 537, 542, 564, 580, 582, 586, 591, 598, 606, 624, 653, 654, 657, 658, 663, 674, 700, 762, 772, 776, 805, 815, 816, 818, 831, 836, 842, 846, 856, 931, 953, 962, 969, 1024, 1026, 1029, 1033, 1034, 1039, 1048, 1054, 1057, 1060, 1064, 1069, 1080, 1089, 1097, 1106, 1120, 1174, 1190, 1199, 1209, 1217, 1232, 1238, 1244, 1249, 1250, 1254, 1263, 1267, 1275, 1279, 1320, 1325, 1335, 1336, 1350, 1361, 1362, 1367, 1368, 1372, 1410, 1411, 1416, 1439, 1447, 1454, 1464, 1465, 1478, 1479, 1482, 1498, 1502, 1503, 1508, 1526, 1527, 1528, 1529, 1530, 1534, 1541, 1546, 1547, 1548, 1549, 1551, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1562, 1566, 1567, 1568, 1571, 1581, 1584, 1594, 1598, 1607, 1614, 1619, 1637, 1647, 1667, 1689, 1697, 1756, 1763], "target_calls": [["<lambda>", 1555], ["<module>", 4], ["ContentTooShortError", 526], ["DateRange", 815], ["DownloadError", 478], ["ExtractorError", 431], ["HEADRequest", 1249], ["InAdvancePagedList", 1410], ["MaxDownloadsReached", 512], ["OnDemandPagedList", 1367], ["PagedList", 1361], ["PostProcessingError", 501], ["RegexNotFoundError", 473], ["SameFileError", 492], ["UnavailableVideoError", 517], ["UnsupportedError", 466], ["YoutubeDLHTTPSHandler", 657], ["YoutubeDLHandler", 564], ["fix_kv", 1547], ["js_to_json", 1546], ["locked_file", 1033]]}

```

### [低] js_to_json 仅移除数组尾逗号，对象尾逗号未处理

- 位置：`youtube_dl/utils.py:1567`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：第1567行 re.sub(r',(\s*\])', ...) 只处理数组（']'）前的尾随逗号，未处理对象（'}'）前的尾随逗号。JS 对象字面量常含尾随逗号（如 {a:1,}），转换后仍为 {"a":1,}，json.loads 会抛 ValueError。调用方 _parse_json 依赖 js_to_json 产出合法 JSON，遇到对象尾逗号会解析失败。
- 触发条件：js_to_json('{a:1,}') 后 json.loads，抛出 JSONDecodeError。
- 依据：第1567行正则仅匹配 ']'，未包含 '}'。
- 修复建议：将正则扩展为同时匹配 ']' 和 '}'，例如 r',(\s*[\]}])'。
- 验证方式：执行未形成与候选对应的有效失败；不作为正式缺陷。

```python
1565:         [a-zA-Z_][.a-zA-Z_0-9]*
1566:         ''', fix_kv, code)
1567:     res = re.sub(r',(\s*\])', lambda m: m.group(1), res)
1568:     return res
1569: 
```

- 复现状态：unrelated_failure
- 证据说明：执行未形成与候选对应的有效失败；不作为正式缺陷。

[运行证据](evidence/f6130b059b32/evidence.json)

复现测试：

```python
import unittest
import json
from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        result = js_to_json('{a:1,}')
        parsed = json.loads(result)
        self.assertEqual(parsed, {'a': 1})

```

执行1：镜像 `sha256:a255ffcb469f2ec40f2958a76beb0c2bbebfe92ce9af67a9b48d84b4cb695ac8`；Python `3.7.17`；状态 `unrelated_failure`。

```text

CODE_REVIEW_EXECUTION={"python": "3.7.17", "tests_run": 1, "failures": 0, "errors": 1, "skipped": 0, "load_error": null, "observations": [{"test": "generated_reproduction.ReproductionTest.test_reproduction", "outcome": "error", "exception_type": "JSONDecodeError", "message": "Expecting property name enclosed in double quotes: line 1 column 8 (char 7)", "traceback": "Traceback (most recent call last):\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 59, in testPartExecutor\n    yield\n  File \"/usr/local/lib/python3.7/unittest/case.py\", line 628, in run\n    testMethod()\n  File \"/harness/test_reproduction.py\", line 9, in test_reproduction\n    parsed = json.loads(result)\n  File \"/usr/local/lib/python3.7/json/__init__.py\", line 348, in loads\n    return _default_decoder.decode(s)\n  File \"/usr/local/lib/python3.7/json/decoder.py\", line 337, in decode\n    obj, end = self.raw_decode(s, idx=_w(s, 0).end())\n  File \"/usr/local/lib/python3.7/json/decoder.py\", line 353, in raw_decode\n    obj, end = self.scan_once(s, idx)\njson.decoder.JSONDecodeError: Expecting property name enclosed in double quotes: line 1 column 8 (char 7)\n"}], "target_lines": [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 54, 57, 58, 59, 60, 61, 66, 67, 70, 85, 139, 140, 162, 174, 188, 193, 216, 233, 268, 277, 312, 321, 341, 350, 378, 387, 397, 406, 431, 432, 434, 460, 466, 467, 473, 474, 475, 478, 484, 486, 492, 497, 498, 501, 506, 508, 512, 513, 514, 517, 522, 523, 526, 532, 534, 535, 537, 542, 564, 580, 582, 586, 591, 598, 606, 624, 653, 654, 657, 658, 663, 674, 700, 762, 772, 776, 805, 815, 816, 818, 831, 836, 842, 846, 856, 931, 953, 962, 969, 1024, 1026, 1029, 1033, 1034, 1039, 1048, 1054, 1057, 1060, 1064, 1069, 1080, 1089, 1097, 1106, 1120, 1174, 1190, 1199, 1209, 1217, 1232, 1238, 1244, 1249, 1250, 1254, 1263, 1267, 1275, 1279, 1320, 1325, 1335, 1336, 1350, 1361, 1362, 1367, 1368, 1372, 1410, 1411, 1416, 1439, 1447, 1454, 1464, 1465, 1478, 1479, 1482, 1498, 1502, 1503, 1508, 1526, 1527, 1528, 1529, 1530, 1534, 1541, 1546, 1547, 1548, 1549, 1551, 1553, 1560, 1562, 1566, 1567, 1568, 1571, 1581, 1584, 1594, 1598, 1607, 1614, 1619, 1637, 1647, 1667, 1689, 1697, 1756, 1763], "target_calls": [["<module>", 4], ["ContentTooShortError", 526], ["DateRange", 815], ["DownloadError", 478], ["ExtractorError", 431], ["HEADRequest", 1249], ["InAdvancePagedList", 1410], ["MaxDownloadsReached", 512], ["OnDemandPagedList", 1367], ["PagedList", 1361], ["PostProcessingError", 501], ["RegexNotFoundError", 473], ["SameFileError", 492], ["UnavailableVideoError", 517], ["UnsupportedError", 466], ["YoutubeDLHTTPSHandler", 657], ["YoutubeDLHandler", 564], ["fix_kv", 1547], ["js_to_json", 1546], ["locked_file", 1033]]}

```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/utils.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 44, "sensitive_file": 1, "benchmark_tests_hidden": 20}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
