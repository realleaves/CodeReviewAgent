import unittest
import json
from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        result = js_to_json('{a:1,}')
        parsed = json.loads(result)
        self.assertEqual(parsed, {'a': 1})
