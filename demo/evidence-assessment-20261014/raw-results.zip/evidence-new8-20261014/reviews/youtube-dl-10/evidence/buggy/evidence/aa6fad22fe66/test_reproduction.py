import json
import unittest

from youtube_dl.utils import js_to_json


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        # JS 源码: 'a\\b' 表示字符串 a\b（单个反斜杠）
        js_source = "'a\\\\b'"
        result = js_to_json(js_source)
        parsed = json.loads(result)
        self.assertEqual(parsed, 'a\\b')
