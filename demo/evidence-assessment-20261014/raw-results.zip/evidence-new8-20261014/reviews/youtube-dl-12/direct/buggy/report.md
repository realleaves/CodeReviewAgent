# GitHub 仓库代码审查报告

- 仓库：https://github.com/ytdl-org/youtube-dl
- 分支：blinded-snapshot
- Commit：`435e382423f860aca82a58d7c3db58cbfa242b40`
- 状态：**completed**；模式：direct；模型：deepseek-flash
- 完成语义审查：0/837 个已索引 Python 文件
- 调用：1；耗时：8.568 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- 本报告是静态分析及模型推断；外部容器复现证据由评测程序另行保存。

## 候选问题（4）

### [高] 字符串过滤器取反逻辑错误：lambda 忽略 attr/value 且对函数对象取反

- 位置：`youtube_dl/YoutubeDL.py:1081`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：当 filter_spec 使用否定形式（如 'ext!="mp4"'）时，代码执行 `op = lambda attr, value: not str_op`。这里 `str_op` 是一个函数对象（如 operator.eq 或 lambda），`not str_op` 恒为 False（函数对象为真值），因此该 lambda 无论传入什么 attr/value 都返回 False。结果是所有格式都被过滤掉，而不是排除匹配项。正确写法应为 `lambda attr, value: not str_op(attr, value)`。
- 触发条件：使用带否定运算符的字符串格式过滤器，例如 `-f 'ext!="mp4"'` 或 `-f 'vcodec!*=avc'`，_filter 会对每个格式返回 False，导致没有可用格式。
- 依据：1080: if m.group('negation'):
1081:     op = lambda attr, value: not str_op
1082: else:
1083:     op = str_op
- 修复建议：改为 `op = lambda attr, value: not str_op(attr, value)`，并补充针对否定过滤器的单元测试。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1079:                 str_op = STR_OPERATORS[m.group('op')]
1080:                 if m.group('negation'):
1081:                     op = lambda attr, value: not str_op
1082:                 else:
1083:                     op = str_op
```

### [中] 数值过滤器对带单位/小数的值先 int() 再 parse_filesize，导致解析错误或异常

- 位置：`youtube_dl/YoutubeDL.py:1052`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：代码先尝试 `int(m.group('value'))`，失败后才调用 parse_filesize。但正则允许小数和单位（如 '1.5M'、'500k'、'1GiB'）。对 '1.5M'，int() 抛 ValueError 后 parse_filesize('1.5M') 可能返回 None，再尝试 '1.5MB'；对纯小数如 '1.5'，int() 抛错，parse_filesize('1.5') 与 '1.5B' 都可能返回 None，最终抛出 ValueError，尽管该值在数值语义上合法。此外对 '1.5' 这类无单位值，用户期望的是 1.5 的数值比较，而非文件大小。
- 触发条件：使用形如 `-f 'tbr>1.5'`、`-f 'filesize>1.5M'` 的过滤器，其中 value 含小数点或单位。
- 依据：1052: comparison_value = int(m.group('value'))
1053: except ValueError:
1054:     comparison_value = parse_filesize(m.group('value'))
1055:     if comparison_value is None:
1056:         comparison_value = parse_filesize(m.group('value') + 'B')
- 修复建议：先尝试 float() 解析纯数值，再回退到 parse_filesize；或明确区分数值型 key（width/height/tbr 等）与文件大小型 key（filesize/filesize_approx），分别解析。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1050:         if m:
1051:             try:
1052:                 comparison_value = int(m.group('value'))
1053:             except ValueError:
1054:                 comparison_value = parse_filesize(m.group('value'))
1055:                 if comparison_value is None:
1056:                     comparison_value = parse_filesize(m.group('value') + 'B')
1057:                 if comparison_value is None:
1058:                     raise ValueError(
```

### [中] _filter 闭包捕获循环/后续变量，且对 None 值返回字符串而非布尔

- 位置：`youtube_dl/YoutubeDL.py:1089`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：_filter 依赖外层变量 m、op、comparison_value。当 actual_value 为 None 时返回 `m.group('none_inclusive')`，该值是字符串（如 '?' 或 None），而非布尔值。调用方若按布尔语义使用（如 if _filter(f)），非空字符串 '?' 会被当作 True，可能意外包含本应排除的格式；返回 None 则等价 False。此外 m 是可变引用，若在返回 _filter 后被重新赋值（当前函数内不会，但闭包设计脆弱），过滤行为会改变。
- 触发条件：格式字典缺少被过滤的 key（如某些格式无 'filesize' 字段）且过滤器带 '?' 后缀，例如 `-f 'filesize>100? '`。
- 依据：1089: actual_value = f.get(m.group('key'))
1090: if actual_value is None:
1091:     return m.group('none_inclusive')
1092: return op(actual_value, comparison_value)
- 修复建议：将 none_inclusive 显式转换为布尔（如 `return bool(m.group('none_inclusive'))`），并在闭包创建时把 m/op/comparison_value 绑定为默认参数以避免后续被修改。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1087: 
1088:         def _filter(f):
1089:             actual_value = f.get(m.group('key'))
1090:             if actual_value is None:
1091:                 return m.group('none_inclusive')
1092:             return op(actual_value, comparison_value)
1093:         return _filter
1094: 
```

### [低] 数值过滤器正则未锚定开头，可能匹配到 filter_spec 中间片段

- 位置：`youtube_dl/YoutubeDL.py:1043`
- 来源：llm
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：operator_rex 以 `(?x)\s*` 开头但未加 `^`，仅以 `$` 结尾。search 会在字符串任意位置匹配，因此像 'foo tbr>100' 这样的非法前缀也会被接受并解析出 tbr>100，掩盖输入错误。字符串过滤器正则同样未锚定开头。
- 触发条件：传入含前导垃圾字符的过滤器，如 `-f 'abc tbr>100'`。
- 依据：1043: operator_rex = re.compile(r'''(?x)\s*
1044:     (?P<key>width|height|tbr|...)
...
1047:     $
1048:     ''' % ...)
- 修复建议：在正则开头加入 `^`（或使用 fullmatch），确保整个 filter_spec 被完整匹配。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1041:             '!=': operator.ne,
1042:         }
1043:         operator_rex = re.compile(r'''(?x)\s*
1044:             (?P<key>width|height|tbr|abr|vbr|asr|filesize|filesize_approx|fps)
1045:             \s*(?P<op>%s)(?P<none_inclusive>\s*\?)?\s*
1046:             (?P<value>[0-9.]+(?:[kKmMgGtTpPeEzZyY]i?[Bb]?)?)
1047:             $
1048:             ''' % '|'.join(map(re.escape, OPERATORS.keys())))
1049:         m = operator_rex.search(filter_spec)
1050:         if m:
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/YoutubeDL.py | not_requested | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 62, "sensitive_file": 1, "benchmark_tests_hidden": 31}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
