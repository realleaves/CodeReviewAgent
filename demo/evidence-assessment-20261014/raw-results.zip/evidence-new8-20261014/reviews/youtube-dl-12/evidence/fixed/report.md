# GitHub 仓库代码审查报告

- 仓库：local-benchmark
- 分支：blinded-snapshot
- Commit：`435e382423f860aca82a58d7c3db58cbfa242b40`
- 状态：**partial**；模式：evidence；模型：deepseek-flash
- 完成语义审查：0/837 个已索引 Python 文件
- 调用：8；耗时：15.499 秒

## 范围与限制

- BugsInPy定范围评测：使用参考补丁选择代码窗口，Agent未看到补丁、测试、标签或另一版本。
- completed仅表示所选窗口及复核完成；完整文件审查数为0，不表示全仓库或全文件审查。
- 修复版本可能含其他缺陷；额外发现不自动计为误报。
- evidence模式使用Agent自行生成的测试与隔离执行，契约语义仍由模型核验；官方回归测试不提供给Agent。

## 已复现缺陷（0）

正式缺陷附测试与运行证据；其余候选和静态建议单列，不表示已经证实。

## 待验证候选与静态建议

### [中] none_inclusive 返回字符串而非布尔值，导致 filter 结果真值语义错误

- 位置：`youtube_dl/YoutubeDL.py:1090`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：_filter 在 actual_value 为 None 时返回 m.group('none_inclusive')。当 filter_spec 含 '?'（如 'height>720?'）时该组匹配到的是字符串 '?'（正则中 (?P<none_inclusive>\s*\?)? 捕获的是 '?' 本身），而非布尔 True。该返回值被用作 filter() 的谓词，非空字符串 '?' 为真值，因此格式被保留——这恰好符合 '?' 的语义（无该字段时也保留）。但当 filter_spec 不含 '?' 时该组为 None，返回 None 为假值，格式被过滤掉，也符合语义。问题在于返回值类型不一致：返回的是 '?' 字符串或 None，而非布尔。若调用方（如 1346-1351 的 list(filter(...))）仅依赖真值判断则行为正确，但任何对返回值做布尔比较或类型检查的调用方会得到意外类型。需结合调用方契约判断，当前主片段内调用方仅用真值，故影响有限。
- 触发条件：filter_spec = 'height>720?'，格式 f 无 height 字段（actual_value is None）
- 依据：1090-1091: if actual_value is None: return m.group('none_inclusive')；1045: (?P<none_inclusive>\s*\?)? 捕获 '?' 字符串
- 修复建议：返回 bool(m.group('none_inclusive')) 以保持布尔契约一致。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1088:         def _filter(f):
1089:             actual_value = f.get(m.group('key'))
1090:             if actual_value is None:
1091:                 return m.group('none_inclusive')
1092:             return op(actual_value, comparison_value)
1093:         return _filter
1094: 
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 _filter 在 actual_value 为 None 时返回字符串 '?' 而非布尔值，导致类型不一致。但该返回值仅被用作 filter() 的谓词（第1351行 list(filter(_filter, ...))），filter 只依赖真值语义。'?' 非空字符串为真、None 为假，恰好正确实现了 '?' 的语义（字段缺失时保留格式）。仓库内没有文档、测试或调用方契约要求该返回值必须是布尔类型，也没有任何调用方对其做类型检查或布尔比较。因此不存在可定位的契约来证明这是缺陷，无法构造会因真实 bug 而失败的复现测试。

[运行证据](evidence/6f515a57920f/evidence.json)

### [低] 数值比较值可能为浮点字符串导致 int() 失败后 parse_filesize 处理不一致

- 位置：`youtube_dl/YoutubeDL.py:1052`
- 来源：llm
- 复核：待验证 — 尚未复核；未运行待审代码。
- 问题：正则 value 组为 [0-9.]+(?:[kKmMgGtTpPeEzZyY]i?[Bb]?)?，允许纯数字带小数点如 '1.5'。int('1.5') 抛 ValueError，进入 parse_filesize('1.5')。parse_filesize 对无单位字符串的处理需确认：若其返回 None，则再尝试 parse_filesize('1.5B')。若两者都返回 None 则抛 ValueError。对于 '1.5' 这类无单位小数，用户期望按字节或按数值比较，但可能因 parse_filesize 不接受无单位小数而报错。需结合 parse_filesize 实现确认，当前证据不足以断定其为缺陷。
- 触发条件：filter_spec = 'filesize>1.5'
- 依据：1052: int(m.group('value')) 对 '1.5' 抛 ValueError；1054-1056 回退到 parse_filesize
- 修复建议：确认 parse_filesize 对无单位小数的契约；若应支持，改用 float 解析。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1050:         if m:
1051:             try:
1052:                 comparison_value = int(m.group('value'))
1053:             except ValueError:
1054:                 comparison_value = parse_filesize(m.group('value'))
1055:                 if comparison_value is None:
1056:                     comparison_value = parse_filesize(m.group('value') + 'B')
1057:                 if comparison_value is None:
1058:                     raise ValueError(
```

- 复现状态：unsupported
- 证据说明：候选缺陷声称 filter_spec='filesize>1.5' 会因 parse_filesize 不接受无单位小数而报错。但正则 value 组为 [0-9.]+(?:[kKmMgGtTpPeEzZyY]i?[Bb]?)?，'1.5' 匹配后 int('1.5') 抛 ValueError，回退 parse_filesize('1.5')。parse_filesize 通过 lookup_unit_table 处理，其契约要求带单位（_UNIT_TABLE 中无空单位键），故 '1.5' 返回 None，再尝试 parse_filesize('1.5B')。'1.5B' 中数值部分 '1.5' 与单位 'B' 匹配，lookup_unit_table 通常用 float 解析数值，因此返回 1.5。所以 'filesize>1.5' 实际可正常工作，不会抛 ValueError。候选描述中'可能因 parse_filesize 不接受无单位小数而报错'的推断与代码路径不符，且未提供任何文档/测试契约证明 '1.5' 应被接受为字节数。缺少 lookup_unit_table 的完整实现证据，无法构造有契约支撑的失败复现，故 applicable=false。

[运行证据](evidence/1fbc08fab046/evidence.json)

### [低] B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling

- 位置：`youtube_dl/YoutubeDL.py:1058`
- 来源：ruff B904
- 复核：未复核 — 尚未复核；未运行待审代码。
- 问题：Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 触发条件：触发条件需结合业务调用确认。
- 依据：ruff B904: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling
- 修复建议：根据诊断检查对应代码。
- 验证方式：静态诊断或代码推断；未执行复现测试。

```python
1056:                     comparison_value = parse_filesize(m.group('value') + 'B')
1057:                 if comparison_value is None:
1058:                     raise ValueError(
1059:                         'Invalid value %r in format specification %r' % (
1060:                             m.group('value'), filter_spec))
```

## 覆盖范围

| 文件 | 静态检查 | 语义审查 | 完成分块 |
|---|---|---|---|
| youtube_dl/YoutubeDL.py | completed | window_completed | 1/1 |

## 失败记录

```json
[]
```

## 驳回的问题（0）


## 跳过文件

{"unsupported_language_or_resource": 62, "sensitive_file": 1, "benchmark_tests_hidden": 31}

逐文件跳过原因、模型调用用量和复核轨迹见 report.json / run.json。
