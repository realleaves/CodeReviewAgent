import hashlib
import json
from pathlib import Path
import shutil
import subprocess

from src.reproduction import execution_verdict
from src.schemas import Finding

root = Path('/home/real/Desktop/Agent/CodeReviewAgent')
out = root / 'outputs/primuus-controlled-20261015'
out.mkdir(parents=True, exist_ok=False)
shutil.copytree(root / 'src', out / 'baseline/src', ignore=shutil.ignore_patterns('__pycache__'))
shutil.copy2(root / 'main.py', out / 'baseline/main.py')
records = []
for batch, work in [('evidence-original20-20261014', 'bugsinpy-work'), ('evidence-new8-20261014', 'evidence-holdout-work')]:
    folder = root / 'outputs' / batch
    selection = {c['id']: c for c in json.loads((folder / 'selection.json').read_text())}
    for record in json.loads((folder / 'results.json').read_text())['records']:
        if record['mode'] != 'evidence':
            continue
        report = json.loads((folder / record['report']).read_text())
        for item in report['findings']:
            if item['source'] != 'llm' or item['status'] != 'reproduced':
                continue
            finding = Finding.model_validate(item)
            snapshot = root / 'outputs' / work / selection[record['case']]['snapshot_paths'][record['variant']]
            files = {finding.path: (snapshot / finding.path).read_text()}
            verdict = execution_verdict(item['reproduction']['attempts'][0], finding, files)
            records.append({'case': record['case'], 'variant': record['variant'], 'finding_id': finding.id, 'batch': batch, 'snapshot': str(snapshot), 'report': str(folder / record['report']), 'baseline_verdict': verdict, 'reference_gate_label': True if record['case'] == 'PySnooper-3' else False if record['case'] == 'youtube-dl-12' else None})
assert len(records) == 13 and all(r['baseline_verdict'] == 'failure_observed' for r in records)
(out / 'baseline-records.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
manifest = {
    'status': 'preregistered_before_source_changes',
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source_sha256': {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [*sorted((root/'src').glob('*.py')), root/'main.py']},
    'gate_experiment': {'input': '13 saved accepted candidates and their original first executions; repeat actual PySnooper-3 and youtube-dl-12 controls in immutable Docker images', 'acceptance': 'Reject wrong-branch youtube-dl-12; preserve PySnooper-3 via real candidate-line traceback; report other candidates as unadjudicated.'},
    'feedback_experiment': {'case': 'tornado-4', 'initial_plan': 'Frozen saved original generated plan; source and expected_behavior/contract fixed in both variants', 'variants': ['new_gate_feedback_off', 'new_gate_feedback_on'], 'repeats': 3, 'order': 'off/on, on/off, off/on', 'max_model_calls_total': 24, 'max_repairs_per_candidate': 1, 'acceptance': 'Improved valid target evidence with unchanged contract; evaluator-only fixed-snapshot control passes; otherwise keep feedback disabled by default.'},
    'exclusions': 'No changes to original scores, rubrics, held-out answers or denominators. Development diagnostics, not a new end-to-end detection score.'
}
(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print('Saved source baseline, 13 original verdicts and predeclared diagnostic protocol:', out)
