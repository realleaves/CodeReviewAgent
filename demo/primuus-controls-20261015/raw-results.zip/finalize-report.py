from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

from src.report import write_reports
from src.reproduction import DockerExecutor, execution_verdict
from src.schemas import Finding

root = Path('/home/real/Desktop/Agent/CodeReviewAgent')
experiment = root / 'outputs/primuus-controlled-20261015'
out = root / 'demo/primuus-controls-20261015'
out.mkdir(parents=True, exist_ok=False)
implementation = json.loads((experiment/'implementation.json').read_text())
for path, digest in implementation.items():
    if path != 'evaluation/evidence_controls.py':
        assert hashlib.sha256((root/path).read_bytes()).hexdigest() == digest
assert hashlib.sha256((experiment/'executed-driver.py').read_bytes()).hexdigest() == implementation['evaluation/evidence_controls.py']

# Two generic boundary checks, without a model or benchmark reference answers.
image = json.loads((experiment/'gate-controls/youtube-dl-12-buggy.json').read_text())['image_id']
edge_cases = [
    ('import-is-not-a-call', 'def target():\n    return 7\n', 1,
     '        value = 1\n        self.assertEqual(value, 2)\n'),
    ('adjacent-branch', 'def target(value):\n    if value > 0:\n        return 7\n    return 0\n', 3,
     '        self.assertEqual(target(0), 99)\n'),
]
edge_results = []
edge_dir = experiment/'generic-boundaries'
edge_dir.mkdir(exist_ok=False)
for name, source, line, body in edge_cases:
    finding = Finding(path='a.py', line=line, end_line=line, severity='medium', category='bug',
        title=name, explanation='Generic execution attribution control.', trigger='Controlled test input.',
        evidence='Test phase trace must reach the claimed location.', suggestion='Diagnostic only.',
        id=name, source='diagnostic', snippet=source)
    test = 'import unittest\nfrom a import target\nclass ReproductionTest(unittest.TestCase):\n    def test_reproduction(self):\n' + body
    attempt = DockerExecutor(image).execute({'a.py':source}, finding, test)
    verdict = execution_verdict(attempt, finding, {'a.py':source})
    assert verdict == 'unrelated_failure'
    (edge_dir/f'{name}.json').write_text(json.dumps(attempt,ensure_ascii=False,indent=2)+'\n')
    edge_results.append({'case':name,'verdict':verdict,'api_calls':0})

feedback = json.loads((experiment/'feedback-results.json').read_text())
gate = json.loads((experiment/'gate-controls/results.json').read_text())
presentations = []
for trial in feedback['trials']:
    original_path = experiment/trial['report']
    original = json.loads(original_path.read_text())
    view = deepcopy(original)
    item = view['findings'][0]
    view['run'].update(window_review_completed=False,scope_kind='fixed_candidate_diagnostic',
        options=view['diagnostic_options'],semantic_coverage_percent=0,reviewed_window_chunks=0,
        total_window_chunks=0,active_findings=int(item['status']=='reproduced'),candidate_findings=1,
        rejected_findings=0,severity_counts={item['severity']:1},status_counts={item['status']:1})
    view.update(coverage=[],excluded=[],stages=[],tool_reads=[])
    view['presentation_source_sha256'] = hashlib.sha256(original_path.read_bytes()).hexdigest()
    view['presentation_note'] = 'Offline presentation correction of inherited scope/options/counts; no model resampling or change to candidate, calls, tests, executions, trace or verdict.'
    for key in ['findings','calls','trace','evidence_artifacts']:
        assert view[key] == original[key]
    target = out/original_path.parent.name
    write_reports(view,target)
    presentations.append({'source':str(original_path),'source_sha256':view['presentation_source_sha256'],
        'derived_report':target.name+'/report.json'})

shutil.copytree(experiment/'gate-controls',out/'gate-controls')
shutil.copytree(edge_dir,out/'generic-boundaries')
for name in ['manifest.json','implementation.json','baseline-records.json','feedback-results.json',
             'feedback-model-config.json','executed-driver.py']:
    shutil.copy2(experiment/name,out/name)

summary = {
 'scope':'Fixed development examples; not end-to-end recall or independent precision.',
 'gate':{'saved_accepted_examples':13,'retained_by_new_gate':12,
         'known_invalid_example_rejected':'youtube-dl-12 / 9758e8ca5215',
         'fresh_docker_controls':gate['fresh_docker_controls'],'generic_boundaries':edge_results,
         'model_calls':0,'known_valid_example_preserved':'PySnooper-3 / 9261f543fc85'},
 'feedback':{'case':'tornado-4','repeats_per_variant':3,'model_calls':feedback['total_api_calls'],
     'off_valid_evidence':0,'on_valid_evidence':0,
     'on_terminal_statuses':dict(Counter(t['evidence_status'] for t in feedback['trials'] if t['feedback'])),
     'decision':'No demonstrated gain; keep max_repro_repairs=0 by default.'},
 'tests':{'pytest_passed':65,'ruff_F_E9':'passed','cli_help':'passed'},
 'implementation_note':'Core source hashes match the frozen experiment. Driver report-template metadata was corrected after sampling; executed driver and original reports remain preserved.',
 'presentation_derivations':presentations,
 'limitations':['One known wrong-branch acceptance was fixed; other accepted candidates remain unadjudicated.',
 'No new blind benchmark or candidate discovery improvement was measured.',
 'Runtime-only line tracing is conservative about import-time defects; downstream exceptions outside the target remain conservatively rejected.',
 'Contract/expected text is immutable during repair; assertion semantics and input validity still need audit.']}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
lines=['# Primuus 参考机制的首轮实现与对照（2026-10-15）','',
 '**保留证据判定修复；反馈修正没有显示有效收益，保持默认关闭。** 本轮没有重跑全量BugsInPy，也没有新的检出率结论。','',
 '## 已验证的修复','',
 '- 删除“同一个函数被调用就算触达目标”的兜底，改用候选位置的实际执行行或真实异常栈。',
 '- 测试阶段追踪与导入阶段分离，保存结构化异常帧；原有保存证据仍支持按可信旧日志复跑。',
 '- PySnooper-3原测试：新容器中缺陷版NameError、修复版通过，原有效证据保留。',
 '- youtube-dl-12原错误输入：两版本仍发生断言失败，但新判定均为unrelated_failure，不再进入正式证据。',
 '- 13个历史自动接受候选的旧执行记录重判，仅此1条被拦截，保留12条。后12条不因此获得真实性确认。',
 '- 两个通用Docker反例（只导入未调用、调用相邻分支）同样拒绝，0次模型调用。','',
 '## 一次反馈修正的对照','',
 '冻结此前tornado-4的候选、源码和原始测试计划，两条件都使用新执行判定，只改变是否允许一次反馈。运行前固定3组，顺序off/on、on/off、off/on；总模型调用上限24，实际5次现有DeepSeek调用。原始计划重放不计为本轮模型生成，不能作为端到端检出。','',
 '| 条件 | 次数 | 有效证据 | 新增模型调用 | 实际结果 |','|---|---:|---:|---:|---|',
 '| 关闭反馈 | 3 | 0/3 | 0 | 原测试复制计算，未调用目标 |',
 '| 开启一次反馈 | 3 | 0/3 | 5 | 一次仍违反测试结构；一次初始化断言失败；一次继续复制逻辑，目标调用未执行 |','',
 '新增反馈机制限制：只在未记录到候选所在函数调用时请求修正；测试通过、已调用目标却走错分支、依赖缺失都不重写测试。原contract全部字段与expected_behavior必须原样保留，修正后的测试仍需两次独立失败和契约核验；每个候选最多一次，受全局模型预算约束。原计划、回答、失败日志、每个版本测试及其源码/测试哈希均保留。文本约定不变不自动保证断言语义正确，仍需审核。','',
 '**决定：未满足有效证据增加的预定条件，默认max_repro_repairs仍为0。** 实验入口可以通过`--max-repro-repairs 1`明确启用，不能声称该机制已提高真实任务成功率。','',
 '## 检查与适用范围','',
 '65项项目测试通过，Ruff F/E9与改动文件格式检查通过，CLI参数入口通过。新增回归覆盖相邻分支、追踪器被替换时的真实异常栈、异常消息伪装路径、反馈时契约变更、预算耗尽、一次限制和测试通过不重写。旧“无关失败”测试夹具此前仍填写目标位置异常栈，本次修正为测试入口位置，另有明确的目标异常栈正例覆盖。','',
 '现有评分器、参考rubric、原始72次评测及分母未修改。候选发现流程、模型与上下文未改变。执行位置检查更严格仍不证明预期正确；新追踪对导入阶段缺陷较保守，目标文件外的下游异常仍可能无法归因。','',
 '对照运行后的展示修正：诊断报告原先沿用了旧窗口报告的范围、选项和计数字段。此目录的报告在离线呈现时修正这些元数据，候选、模型调用、测试、实际执行、Trace与判定保持一致。原始诊断报告和实际执行驱动完整保留在归档，source SHA256见summary.json；没有重新采样模型来替换失败结果。','',
 '## 资料','',
 '- [结构化结论](summary.json)、[运行前协议](manifest.json)、[执行时源码哈希](implementation.json)',
 '- [原始证据重判与新Docker对照](gate-controls/results.json)',
 '- [三组反馈开关记录](feedback-results.json)、[模型配置](feedback-model-config.json)',
 '- [首次反馈失败报告](trial-1-feedback-on/report.html)',
 '- [第二次反馈失败报告](trial-2-feedback-on/report.html)',
 '- [第三次反馈失败报告](trial-3-feedback-on/report.html)',
 '- [完整原始诊断归档](raw-results.zip)与[归档哈希](raw-manifest.json)','',
 '这是已查看过的开发样本上的机制验证。首轮结果支持一处确定性误接受修复，尚不支持真实缺陷检出率或全局精确率提升。','']
(out/'README.md').write_text('\n'.join(lines))
archive=out/'raw-results.zip';manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as packed:
    for p in sorted(experiment.rglob('*')):
        if p.is_file():
            name=p.relative_to(experiment).as_posix();packed.write(p,name)
            manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(archive) as packed:
    assert packed.testzip() is None
    assert all(hashlib.sha256(packed.read(k)).hexdigest()==v for k,v in manifest.items())
(out/'raw-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest},indent=2)+'\n')
print(json.dumps({'output':str(out),'archive_files':len(manifest),'archive_bytes':archive.stat().st_size,'feedback_calls':feedback['total_api_calls']},ensure_ascii=False))
