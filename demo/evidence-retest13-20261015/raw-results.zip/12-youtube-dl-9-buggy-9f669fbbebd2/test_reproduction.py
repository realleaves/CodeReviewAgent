import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        selector = ydl.build_format_selector('best')
        # formats 为空列表时，迭代 selector 不应抛出 IndexError
        result = list(selector([]))
        self.assertEqual(result, [])
