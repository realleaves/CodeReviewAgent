import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        for spec in [',', 'best,']:
            with self.assertRaises(SyntaxError):
                selector = ydl.build_format_selector(spec)
                list(selector([]))
