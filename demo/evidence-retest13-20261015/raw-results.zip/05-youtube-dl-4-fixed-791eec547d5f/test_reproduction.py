import unittest

from youtube_dl.jsinterp import JSInterpreter
from youtube_dl.utils import ExtractorError


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        interp = JSInterpreter('')
        # '²' 的 isdigit() 为 True，但 int('²') 抛 ValueError
        with self.assertRaises(ExtractorError):
            interp.interpret_expression('\u00b2', {}, 100)
