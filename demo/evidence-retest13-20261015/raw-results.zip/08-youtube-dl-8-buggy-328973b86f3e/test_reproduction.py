import unittest

from youtube_dl.YoutubeDL import YoutubeDL


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True})
        with self.assertRaises(SyntaxError):
            ydl.build_format_selector('/best')