import unittest

from tornado.httpclient import HTTPRequest
from tornado.websocket import WebSocketClientConnection


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        request = HTTPRequest("http://example.com/")
        with self.assertRaises(ValueError):
            WebSocketClientConnection(request)
