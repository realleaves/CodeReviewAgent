"""Frozen 13-record, zero-provider-call rerun of saved generated tests."""

import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time

from evaluation.bugsinpy_data import is_production
from src.repository import inventory, snapshot_digest
from src.reproduction import DockerExecutor, execution_verdict, validate_plan, contract_documents
from src.code_index import CodeIndex
from src.schemas import Finding, ReproductionPlan

ROOT = Path('/home/real/Desktop/Agent/CodeReviewAgent')
OUT = ROOT / 'outputs/evidence-retest13-20261015'
BASELINE = ROOT / 'outputs/primuus-controlled-20261015/baseline/src'


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze():
    paths = [*sorted((ROOT/'src').glob('*.py')), ROOT/'main.py']
    paths += list(sorted(BASELINE.glob('*.py')))
    return {str(p.relative_to(ROOT)): digest(p) for p in paths}


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    records = json.loads((ROOT/'outputs/primuus-controlled-20261015/baseline-records.json').read_text())
    assert len(records) == 13
    hashes = freeze()
    save(OUT/'manifest.json', {
        'status':'frozen_before_execution', 'api_calls':0,
        'source_sha256':hashes, 'input_records':records,
        'protocol':'Unchanged saved test and same image ID/source snapshot; old runner+old gate vs new runner+new gate. Original model audit frozen; no new inference.',
        'primary_runs_per_record_per_implementation':2,
        'counterpart_runs_per_record':1,
        'planned_primary_containers':52,'planned_counterpart_containers':13,
        'all_records_retained':True,
        'semantic_categories':['supported','unsupported_expectation','quality_only','invalid_trigger','inconclusive'],
        'semantic_review':'Codex source/contract/runtime adjudication; not independent human confirmation. Counterpart failure alone does not invalidate a different remaining defect.',
        'no_production_or_scoring_changes':True,
    })
    shutil.copy2(__file__, OUT/'retest.py')
    spec = importlib.util.spec_from_file_location('frozen_evidence_baseline', BASELINE/'__init__.py', submodule_search_locations=[str(BASELINE)])
    package = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = package
    spec.loader.exec_module(package)
    old = importlib.import_module('frozen_evidence_baseline.reproduction')
    completed = []
    for number, record in enumerate(records, 1):
        assert freeze() == hashes, 'Frozen implementation changed during retest.'
        report_path = Path(record['report'])
        report = json.loads(report_path.read_text())
        item = next(f for f in report['findings'] if f['id'] == record['finding_id'])
        finding = Finding.model_validate(item)
        evidence = item['reproduction']
        plan = ReproductionPlan.model_validate(evidence['plan'])
        repository = Path(record['snapshot'])
        files, _ = inventory(repository, evidence['scope'], evidence['max_file_bytes'])
        if evidence.get('production_only'):
            files = {p:s for p,s in files.items() if is_production(p)}
        assert snapshot_digest(files) == evidence['execution_snapshot_sha256']
        validate_plan(plan, CodeIndex(files, contract_documents(repository,evidence['scope'])))
        destination = OUT/f'{number:02d}-{record["case"]}-{record["variant"]}-{finding.id}'
        destination.mkdir(exist_ok=False)
        (destination/'test_reproduction.py').write_text(plan.test_code)
        save(destination/'original-evidence.json',{'finding':item,'source_report_sha256':digest(report_path)})
        save(destination/'target-source.json',{'path':finding.path,'source':files[finding.path]})
        image = evidence['attempts'][0]['image_id']
        executors = {'old':old.DockerExecutor(image),'new':DockerExecutor(image)}
        trials = []
        for repetition in [1,2]:
            for implementation in (['old','new'] if repetition==1 else ['new','old']):
                started = time.monotonic()
                attempt = executors[implementation].execute(files,finding,plan.test_code)
                save(destination/f'{implementation}-{repetition}.json',attempt)
                (destination/f'{implementation}-{repetition}.log').write_text(attempt['log'])
                execution = attempt.get('execution') or {}
                trials.append({'implementation':implementation,'repetition':repetition,
                    'old_gate':old.execution_verdict(attempt,finding,files),
                    'new_gate':execution_verdict(attempt,finding,files),
                    'tests_run':execution.get('tests_run'),
                    'failure_types':[o['exception_type'] for o in execution.get('observations',[])],
                    'messages':[o.get('message') for o in execution.get('observations',[])],
                    'image_id':attempt['image_id'],'seconds':round(time.monotonic()-started,3)})
        folder = ROOT/'outputs'/record['batch']
        case = next(c for c in json.loads((folder/'selection.json').read_text()) if c['id']==record['case'])
        work = 'bugsinpy-work' if 'original20' in record['batch'] else 'evidence-holdout-work'
        other_side = 'fixed' if record['variant']=='buggy' else 'buggy'
        counterpart_repo = ROOT/'outputs'/work/case['snapshot_paths'][other_side]
        counterpart_files, _ = inventory(counterpart_repo,evidence['scope'],evidence['max_file_bytes'])
        if evidence.get('production_only'):
            counterpart_files = {p:s for p,s in counterpart_files.items() if is_production(p)}
        counterpart = executors['new'].execute(counterpart_files,finding,plan.test_code)
        save(destination/'counterpart.json',counterpart)
        (destination/'counterpart.log').write_text(counterpart['log'])
        data = counterpart.get('execution') or {}
        result = {**record,'output':destination.relative_to(OUT).as_posix(),
            'test_sha256':hashlib.sha256(plan.test_code.encode()).hexdigest(),
            'snapshot_sha256':snapshot_digest(files),'trials':trials,
            'old_execution_gate_pass':all(t['old_gate']=='failure_observed' for t in trials if t['implementation']=='old'),
            'new_execution_gate_pass':all(t['new_gate']=='failure_observed' for t in trials if t['implementation']=='new'),
            'counterpart':{'variant':other_side,'snapshot_sha256':snapshot_digest(counterpart_files),
                'new_gate':execution_verdict(counterpart,finding,counterpart_files),
                'tests_run':data.get('tests_run'),'failures':data.get('failures'),'errors':data.get('errors'),
                'failure_types':[o['exception_type'] for o in data.get('observations',[])],
                'messages':[o.get('message') for o in data.get('observations',[])]}}
        completed.append(result)
        save(destination/'comparison.json',result)
        save(OUT/'results.json',{'records':completed,'api_calls':0,
            'primary_containers':len(completed)*4,'counterpart_containers':len(completed),
            'source_frozen':freeze()==hashes})
        print(json.dumps({'progress':f'{number}/13','case':record['case'],'variant':record['variant'],
            'finding_id':finding.id,'old_gate':result['old_execution_gate_pass'],
            'new_gate':result['new_execution_gate_pass'],'types':trials[-1]['failure_types']},ensure_ascii=False),flush=True)
    assert freeze()==hashes


if __name__=='__main__':
    main()
