import unittest

from youtube_dl.utils import dfxp2srt


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        dfxp = (
            '<?xml version="1.0" encoding="utf-8"?>'
            '<tt xmlns="http://www.w3.org/ns/ttml">'
            '<body><div>'
            '<p begin="0s" end="0s">hello</p>'
            '</div></body></tt>'
        )
        result = dfxp2srt(dfxp)
        self.assertIn('00:00:00,000 --> 00:00:00,000', result)
        self.assertIn('hello', result)
