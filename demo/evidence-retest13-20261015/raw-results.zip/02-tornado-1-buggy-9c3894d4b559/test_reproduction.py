import unittest

from tornado.websocket import _PerMessageDeflateCompressor


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        with self.assertRaises(ValueError) as ctx:
            _PerMessageDeflateCompressor(persistent=False, max_wbits=7)
        message = str(ctx.exception)
        self.assertNotIn("%r", message)
        self.assertNotIn("%d", message)
        self.assertIn("7", message)
        self.assertIn("15", message)
