import unittest
from youtube_dl.YoutubeDL import YoutubeDL
from youtube_dl.utils import ExtractorError

class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True, 'format': 'best[height>99999]'})
        info = {'id': 'local-audit', 'title': 'local-audit', 'extractor': 'local',
                'formats': [{'format_id': 'one', 'url': 'http://example.invalid/video.mp4',
                             'ext': 'mp4', 'height': 720, 'vcodec': 'h264', 'acodec': 'aac'}]}
        with self.assertRaises(ExtractorError) as caught:
            ydl.process_video_result(info, download=False)
        self.assertIn('requested format not available', str(caught.exception))
