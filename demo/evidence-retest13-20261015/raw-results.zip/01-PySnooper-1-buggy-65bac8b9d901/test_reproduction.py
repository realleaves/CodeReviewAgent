import os
import tempfile
import unittest

from pysnooper import tracer


class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        fd, path = tempfile.mkstemp()
        os.close(fd)
        try:
            class FakeCode(object):
                co_filename = path

            class FakeFrame(object):
                f_globals = {'__name__': 'empty_module'}
                f_code = FakeCode()

            tracer.source_cache.clear()
            result = tracer.get_source_from_frame(FakeFrame())
            self.assertIsNotNone(result)
        finally:
            os.remove(path)
