"""Evaluator-only caller check; never replaces an original Agent reproduction."""
import hashlib
import json
from pathlib import Path

from src.repository import inventory
from src.reproduction import DockerExecutor
from src.schemas import Finding
from evaluation.bugsinpy_data import is_production

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
results = json.loads((OUT / 'results.json').read_text())
record = results['records'][11]
finding = Finding.model_validate(json.loads((OUT / record['output'] / 'original-evidence.json').read_text())['finding'])
test = '''import unittest
from youtube_dl.YoutubeDL import YoutubeDL
from youtube_dl.utils import ExtractorError

class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        ydl = YoutubeDL({'quiet': True, 'format': 'best[height>99999]'})
        info = {'id': 'local-audit', 'title': 'local-audit', 'extractor': 'local',
                'formats': [{'format_id': 'one', 'url': 'http://example.invalid/video.mp4',
                             'ext': 'mp4', 'height': 720, 'vcodec': 'h264', 'acodec': 'aac'}]}
        with self.assertRaises(ExtractorError) as caught:
            ydl.process_video_result(info, download=False)
        self.assertIn('requested format not available', str(caught.exception))
'''
(OUT / 'audit-caller-test.py').write_text(test)
diagnostics = []
for side, path in [('buggy', record['snapshot']), ('fixed', str(ROOT / 'outputs/bugsinpy-work/snapshots/0019/A'))]:
    files, _ = inventory(Path(path), '.', 200000)
    files = {p: s for p, s in files.items() if is_production(p)}
    attempt = DockerExecutor(record['trials'][0]['image_id']).execute(files, finding, test)
    (OUT / ('audit-caller-' + side + '.json')).write_text(json.dumps(attempt, ensure_ascii=False, indent=2) + '\n')
    (OUT / ('audit-caller-' + side + '.log')).write_text(attempt['log'])
    observations = attempt['execution']['observations']
    diagnostics.append({'side': side, 'tests_run': attempt['execution']['tests_run'],
                        'exceptions': [o['exception_type'] for o in observations],
                        'messages': [o['message'] for o in observations]})
    print(side, diagnostics[-1], flush=True)
(OUT / 'audit-diagnostics.json').write_text(json.dumps({'purpose': 'Evaluator-only legal filter caller reachability, not Agent-generated evidence or reference-bug hit',
    'api_calls': 0, 'containers': 2, 'test_sha256': hashlib.sha256(test.encode()).hexdigest(), 'records': diagnostics}, ensure_ascii=False, indent=2) + '\n')
