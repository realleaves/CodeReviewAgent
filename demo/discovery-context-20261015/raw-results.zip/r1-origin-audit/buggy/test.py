from tornado.web import Application
from tornado.websocket import WebSocketHandler, websocket_connect
from tornado.httpclient import HTTPRequest
from tornado.testing import AsyncHTTPTestCase, gen_test

class EchoHandler(WebSocketHandler):
    def open(self):
        self.write_message("opened")
    def on_message(self, message):
        pass

class ReproductionTest(AsyncHTTPTestCase):
    def get_app(self):
        return Application([(r"/ws", EchoHandler)])
    @gen_test
    def test_lowercase_control(self):
        port = self.get_http_port()
        request = HTTPRequest(self.get_url("/ws").replace("http", "ws", 1),
            headers={"Host": "localhost:%s" % port,
                     "Origin": "http://localhost:%s" % port})
        connection = yield websocket_connect(request)
        self.assertEqual((yield connection.read_message()), "opened")
        connection.close()
    @gen_test
    def test_reproduction(self):
        port = self.get_http_port()
        request = HTTPRequest(self.get_url("/ws").replace("http", "ws", 1),
            headers={"Host": "LOCALHOST:%s" % port,
                     "Origin": "http://localhost:%s" % port})
        connection = yield websocket_connect(request)
        self.assertEqual((yield connection.read_message()), "opened")
        connection.close()
