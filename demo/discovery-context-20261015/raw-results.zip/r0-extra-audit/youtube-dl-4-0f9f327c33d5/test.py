import unittest
from youtube_dl.jsinterp import JSInterpreter
class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        values = [1,2,3,4]
        result = JSInterpreter('').interpret_expression('a.splice(1,2)', {'a': values},100)
        self.assertEqual(result,[2,3])
        self.assertEqual(values,[1,4])
