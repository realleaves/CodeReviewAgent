import unittest
from youtube_dl.YoutubeDL import YoutubeDL
class ReproductionTest(unittest.TestCase):
    def test_reproduction(self):
        with self.assertRaises(SyntaxError):
            YoutubeDL({'quiet': True}).build_format_selector('best[height<720')
