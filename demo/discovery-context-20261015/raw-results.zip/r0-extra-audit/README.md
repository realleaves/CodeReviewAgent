# 首轮额外候选的独立反例检查

两次评测侧Docker检查，0次模型调用，两个测试均实际执行1项并通过。

- youtube-dl-4/fixed/0f9f327c33d5声称splice(1,2)固定pop(index)只删一个元素。实际返回[2,3]，原数组变为[1,4]，符合该输入的预期；循环重复pop会删连续元素。原候选的具体示例被反驳。
- youtube-dl-8/buggy/d1114b5cda27声称缺少右方括号会把None送入过滤器而TypeError。实际build_format_selector('best[height<720')抛出SyntaxError，已有tokenize异常保护生效。原候选的具体行为声称被反驳。

这些是评测者编写的反例，不是Agent生成复现，不计新的参考缺陷命中，不替换任何原始候选或修改评分。其他额外问题仍需独立审查，不由此推算全局精确率。原始候选、测试、镜像与执行日志分别保存于子目录。
