# Final experiment state

All planned development and validation windows closed. No further provider calls planned.

436/600 reservations charged, including failures and the delivery-unknown request0365; 164 unused. Exactly two improvement rounds after legacy/callgraph. Four preselected new samples validated without retuning or altering the original rubric/scorer. Primary adoption conditions not met; default legacy, thinking disabled, max_output6000 retained. Candidate judgments are Codex-assisted and await human review. See demo/discovery-context-20261015/README.md and its standalone raw archive/verifier. No GitHub push.
