import hashlib,json,os,shutil,sys,zipfile,subprocess
from pathlib import Path
from importlib import metadata
from dotenv import dotenv_values
root=Path('/home/real/Desktop/Agent/CodeReviewAgent');exp=root/'outputs/discovery-goal-20261015';demo=root/'demo/discovery-context-20261015';support=exp/'audit-support'
shutil.copy2(__file__,support/'archive-driver.py');shutil.copy2(root/'evaluation/verify_discovery_run.py',support/'evaluation/verify_discovery_run.py');shutil.copy2(demo/'verify.py',support/'demo-verify.py');shutil.copy2(root/'requirements.txt',support/'requirements.txt')
versions={}
for name in ['hello-agents','openai','pydantic','ruff','bandit']:
 try:versions[name]=metadata.version(name)
 except metadata.PackageNotFoundError:versions[name]='not found'
(support/'environment.json').write_text(json.dumps({'python':sys.version,'packages':versions,'git_head':subprocess.run(['git','rev-parse','HEAD'],cwd=root,capture_output=True,text=True,check=True).stdout.strip(),'note':'Actual role inputs/candidate schemas match frozen discovery implementation; independent expectation-admission edits are not measured here.'},ensure_ascii=False,indent=2)+'\n')
secrets=[]
for p in [root/'.env',root.parent/'.env']:
 if p.is_file():
  v=dotenv_values(p).get('LLM_API_KEY')
  if v and len(v)>8:secrets.append(v.encode())
if os.getenv('LLM_API_KEY') and len(os.environ['LLM_API_KEY'])>8:secrets.append(os.environ['LLM_API_KEY'].encode())
secrets=list(set(secrets))
def selected():
 files=[]
 for p in exp.rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(exp)
  if rel.parts[0]=='holdout-work' and rel.as_posix() not in ['holdout-work/manifest.json','holdout-work/prepared.json']:continue
  if p.name=='budget.lock' or p.suffix=='.tmp' or '__pycache__' in rel.parts:continue
  files.append(p)
 return sorted(files)
leaks=[str(p.relative_to(exp)) for p in selected() if any(s in p.read_bytes() for s in secrets)]
assert not leaks,leaks
(support/'configured-key-scan.json').write_text(json.dumps({'configured_values_checked':len(secrets),'matching_files':leaks,'scope':'Configured LLM_API_KEY values only; values themselves are never recorded.'},ensure_ascii=False,indent=2)+'\n')
files={}
with zipfile.ZipFile(demo/'raw-results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in selected():
  name=p.relative_to(exp).as_posix();data=p.read_bytes();files[name]=hashlib.sha256(data).hexdigest();archive.writestr(name,data)
manifest={'archive_sha256':hashlib.sha256((demo/'raw-results.zip').read_bytes()).hexdigest(),'files':files,'excluded':'Full target Git cache/snapshots under holdout-work, __pycache__, temporary files and lock. Pinned snapshot metadata, actual model conversations and official test materials are included.'}
(demo/'raw-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'archive_bytes':(demo/'raw-results.zip').stat().st_size,'configured_key_matches':0},ensure_ascii=False))
