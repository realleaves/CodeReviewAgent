import collections,json,shutil,hashlib
from pathlib import Path
from datetime import datetime,timezone
from evaluation.discovery_experiment import save

root=Path('/home/real/Desktop/Agent/CodeReviewAgent');exp=root/'outputs/discovery-goal-20261015';demo=root/'demo/discovery-context-20261015'
phases=['r0-context','r1-thinking','r2-output-budget','v-holdout'];summary={};common={}
for name in phases:
 p=exp/name;manifest=json.load(open(p/'manifest.json'));result=json.load(open(p/'results.json'));assert result['status'] in ['sampled','sampled_with_interruption']
 groups=json.load(open(p/'groups.json'));decisions=json.load(open(p/'adjudications.json'));by_key={(d['case'],d['mode'],d['variant']):d for d in decisions};rows=result['records'];ops={}
 for arm in manifest['strategies']:
  x=[r for r in rows if r['strategy']==arm];calls=[c for r in x for c in r['calls']]
  ops[arm]={'windows':len(x),'completed_windows':sum(r['status']=='completed' for r in x),'reserved_attempts':sum(r['api_calls'] for r in x),'candidate_rows':sum(len(r['findings']) for r in x),'window_errors':dict(collections.Counter(r['error']['type'] for r in x if r['error'])),'call_errors':dict(collections.Counter(c.get('error_type','success') for c in calls)),'reported_prompt_tokens':sum(c.get('usage',{}).get('prompt_tokens',0) for c in calls),'reported_completion_tokens':sum(c.get('usage',{}).get('completion_tokens',0) for c in calls)}
 summary[name]={'arms':ops,'scores':json.load(open(p/'scores.json'))['metrics']};common[name]=[]
 for repetition in range(1,manifest['repetitions']+1):
  eligible=[]
  for arm in manifest['strategies']:
   eligible.append({g['case'] for g in groups if g['mode']==f'{arm}/rep{repetition}' and g['status']=='completed'} & {g['case'] for g in groups if g['mode']==f'{arm}/rep{repetition}' and g['variant']=='fixed' and g['status']=='completed'})
  # Require both versions completed for every arm.
  eligible=[]
  for arm in manifest['strategies']:
   eligible.append({g['case'] for g in groups if g['mode']==f'{arm}/rep{repetition}' and g['variant']=='buggy' and g['status']=='completed'} & {g['case'] for g in groups if g['mode']==f'{arm}/rep{repetition}' and g['variant']=='fixed' and g['status']=='completed'})
  shared=set.intersection(*eligible)
  common[name].append({'repetition':repetition,'cases':sorted(shared),'correctly_discriminated':{arm:sum(by_key[c,f'{arm}/rep{repetition}','buggy']['target_issue_detected'] and not by_key[c,f'{arm}/rep{repetition}','fixed']['target_issue_detected'] for c in shared) for arm in manifest['strategies']}})
metrics={'generated_at':datetime.now(timezone.utc).isoformat(),'budget':json.load(open(exp/'budget.json')),'windows':sum(sum(a['windows'] for a in p['arms'].values()) for p in summary.values()),'additional_improvement_rounds':2,'phase_summaries':summary,'common_eligible_pairs':common,'stage':'Candidate discovery only; does not replace historical 1/26 generated-proof result','additional_origin_issue':'Evaluator-supported separate behavior issue, human review pending; not a reference hit or Agent-generated proof','human_verified':False,'adoption':'Keep legacy context, thinking disabled, max output6000; no established discovery improvement','token_accounting':'Only returned usage is available. Requests without usage and the unknown response cannot be billed accurately from these records.','unknown_response_attempts_charged':[365]}
assert metrics['budget']['reserved']==436 and metrics['budget']['limit']==600 and metrics['windows']==260
save(exp/'metrics.json',metrics);save(demo/'metrics.json',metrics);shutil.copy2(exp/'audit.json',demo/'audit.json')
for short,name in [('r0','r0-context'),('r1','r1-thinking'),('r2','r2-output-budget'),('holdout','v-holdout')]:
 for suffix in ['scores','adjudications','operational-summary']:
  p=exp/name/(suffix+'.json')
  if p.exists():shutil.copy2(p,demo/(short+'-'+suffix+'.json'))
for name in ['r2-protocol.md']:
 shutil.copy2(exp/name,demo/name)
support=exp/'audit-support/evaluation';support.mkdir(parents=True,exist_ok=True)
for name in ['verify_discovery_run.py','bugsinpy_score.py','bugsinpy-rubric.json','discovery_score.py','discovery_experiment.py','discovery_holdout.py','discovery_extra_origin.py','bugsinpy_data.py','bugsinpy_review.py','bugsinpy_reproduce.py']:
 shutil.copy2(root/'evaluation'/name,support/name)
shutil.copy2(__file__,exp/'audit-support/finalize-data.py')
selected={w['case'] for w in json.load(open(exp/'r0-context/manifest.json'))['input_windows']}
historical=json.load(open(root/'demo/evidence-assessment-20261014/run-records.json'))
save(exp/'audit-support/development-run-records.json',[r for r in historical if r['case'] in selected and r['mode']=='evidence'])
rounds=json.load(open(exp/'rounds.json'));rounds['validation']={'status':'complete','kind':'Exploratory validation of separately reproduced extra-finding signal; no third tuning round','attempts':71,'samples':4,'windows':44,'decision':'No default adoption: disabled completed22/22 windows, enabled11/22. On each common eligible pair both detected1/1.','continuation':'Final2 windows resumed on2026-10-21 after confirming no process/pending request; no failed record retried.'};rounds['final']='No established reference discovery gain. Extra Host-case behavior issue separately supported. All experiments and unseen validation ended; retain defaults and deliver full records.';save(exp/'rounds.json',rounds)
(exp/'STATE.md').write_text('# Final experiment state\n\nAll planned development and validation windows closed. No further provider calls planned.\n\n436/600 reservations charged, including failures and the delivery-unknown request0365; 164 unused. Exactly two improvement rounds after legacy/callgraph. Four preselected new samples validated without retuning or altering the original rubric/scorer. Primary adoption conditions not met; default legacy, thinking disabled, max_output6000 retained. Candidate judgments are Codex-assisted and await human review. See demo/discovery-context-20261015/README.md and its standalone raw archive/verifier. No GitHub push.\n')
print(json.dumps({'budget':metrics['budget'],'common':common,'windows':metrics['windows']},ensure_ascii=False,indent=2))
