from contextlib import redirect_stdout
import io,json,shutil,time
from pathlib import Path
from evaluation.discovery_experiment import AttemptBudget,RecordedLLM,digest,save,now
from evaluation.bugsinpy_review import reviewer_files
from src.repository import snapshot_digest
from src.code_index import CodeIndex,Chunk,numbered
from src.agents import load_config,ReviewAgents

root=Path('/home/real/Desktop/Agent/CodeReviewAgent');experiment=root/'outputs/discovery-goal-20261015';phase=experiment/'v-holdout';manifest=json.load(open(phase/'manifest.json'));original=json.load(open(phase/'results.json'));assert len(original['records'])==42
assert all(digest(root/p)==h for p,h in manifest['source_sha256'].items())
assert not [p for p in phase.glob('windows/*/requests/*/request.json') if not (p.parent/'response.json').exists()]
load_config();budget=AttemptBudget(experiment)
case=next(c for c in json.load(open(experiment/'holdout-work/prepared.json')) if c['id']=='youtube-dl-15');window=manifest['input_windows'][-1];assert window['case']=='youtube-dl-15' and window['side']=='fixed'
files,_=reviewer_files(experiment/'holdout-work'/case['snapshot_paths']['fixed']);assert snapshot_digest(files)==manifest['snapshots_sha256']['youtube-dl-15/fixed']
shutil.copy2(phase/'results.json',phase/'results-checkpoint-42.json')
save(phase/'continuation-20261021.json',{'created_at':now(),'reason':'Original process handle missing and elevated process inspection found no runner. 42 saved records; zero unmatched requests. Final enabled window directory existed empty before any provider reservation.','saved_records_before':42,'reserved_before':budget.state()['reserved'],'only_pending_windows':['rep2-youtube-dl-15-fixed-1-enabled','rep2-youtube-dl-15-fixed-1-disabled'],'previous_failures_retried':False,'source_hashes_match_frozen_manifest':True,'configuration_samples_rubric_budgets_unchanged':True,'note':'Continuation on a later date is recorded as an environmental limitation; provider weights behind the same model alias cannot be independently pinned.'})
shutil.copy2(__file__,phase/'continuation-driver.py')
records=original['records']
for arm in ['enabled','disabled']:
 assert all(digest(root/p)==h for p,h in manifest['source_sha256'].items())
 label={k:window[k] for k in ['case','side','path','start','end']};label.update(strategy=arm,repetition=2)
 name='rep2-'+window['folder']+'-'+arm;destination=phase/'windows'/name
 if destination.exists():assert not list(destination.iterdir())
 else:destination.mkdir(parents=True)
 index=CodeIndex(files);index.production_only=True
 config=manifest['arms'][arm];llm=RecordedLLM(budget,phase.name,manifest['phase_call_limit'],destination,label);llm.thinking_mode=config['thinking_mode'];llm.max_tokens=config['max_output_tokens'];assert llm.model==manifest['model']['model'] and llm.temperature==manifest['model']['temperature']
 with redirect_stdout(io.StringIO()):agent=ReviewAgents(index,llm,config['context_strategy'])
 part=Chunk(window['path'],window['start'],window['end'],numbered(files[window['path']],window['start'],window['end']));save(destination/'initial-payload.json',agent.review_payload(part,[],evidence=True))
 began=time.monotonic();findings=[];error=None;status='completed'
 with (destination/'stdout.log').open('w') as stdout:
  try:
   with redirect_stdout(stdout):findings=agent.review(part,[],evidence=True)
  except Exception as exc:status='failed';error={'type':type(exc).__name__,'message':str(exc)[:300]}
  finally:llm.close()
 record={**label,'name':name,'status':status,'error':error,'api_calls':len(llm.calls),'calls':llm.calls,'findings':[f.model_dump() for f in findings],'trace':agent.trace,'tool_reads':index.reads,'elapsed_seconds':round(time.monotonic()-began,3),'folder':str(destination.relative_to(phase))}
 save(destination/'record.json',record);records.append(record);save(phase/'results.json',{'records':records,'status':'running','budget':budget.state()});print({'progress':str(len(records))+'/44',**label,'status':status,'calls':len(llm.calls),'global_used':budget.state()['reserved']},flush=True)
assert len(records)==44 and all(digest(root/p)==h for p,h in manifest['source_sha256'].items())
save(phase/'results.json',{'records':records,'status':'sampled','budget':budget.state(),'source_frozen':True,'semantic_adjudication':'pending','continuation':'Final two previously unstarted windows completed from identical frozen inputs; no failed record retried.'})
