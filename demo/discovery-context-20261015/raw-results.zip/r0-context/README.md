# 首轮：legacy 与 callgraph（真实 DeepSeek，2026-10-15）

冻结6个已漏检开发样本、两版本、两轮重复，共48组/72个窗口，99次实际请求尝试。使用现有deepseek-flash，thinking disabled，temperature 0.1，max_tokens 6000，timeout 45秒；每窗口最多3次，SDK自动重试关闭。

legacy：36窗口、33完整、60次请求、47条候选、220834输入tokens、20378输出tokens。
callgraph：36窗口、33完整、39次请求、39条候选、135572输入tokens、12343输出tokens。

两种策略两轮均未识别6个参考问题。首轮legacy有3/6对完整、callgraph有5/6对完整，共同完整3对；第二轮双方6/6完整，全部0命中、0同参考问题修复版告警。72个窗口中6个APIConnectionError，全部保留并计入预算，不把这些异常当作代码证据或隐藏为成功。

判读使用原始bugsinpy-rubric.json和未修改的score_pairs，由Codex对照源码/候选/触发条件完成，仍待人工复查。额外候选不自动算误报；47或39不是已证实缺陷数。此次仅运行发现阶段，没有生成新的复现证据，也不替换历史1/26。

结论：调用链上下文没有显示参考发现收益，不改默认legacy。较少的查阅轮次使实际调用和tokens下降；它仅作为下一轮更低成本的固定上下文条件，用相同样本比较推理模式。下一轮只变thinking disabled/enabled，候选上限、提示词、工具、源代码和输出上限相同。

原始记录：manifest.json，implementation/，windows/（每次请求/回答、初始输入、工具读取及候选），results.json，groups.json，adjudications.json，scores.json，operational-summary.json。全局总预算及追加日志位于上级budget.json、attempts.jsonl。
